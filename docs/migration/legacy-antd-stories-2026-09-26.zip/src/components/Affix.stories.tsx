import { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react-vite'
import { Affix, Button, Flex, Typography, theme } from 'antd'
import type { AffixProps } from 'antd'
import { Plus } from '../icons'

const meta: Meta<typeof Affix> = {
  component: Affix,
  title: 'Components/Affix',
  tags: ['ai-generated', 'needs-work'],
  args: { offsetTop: 0 },
  // `offsetTop` / `offsetBottom` / `target` / `onChange` descriptions are
  // antd's own JSDoc from affix/index.d.ts, copied as-is.
  argTypes: {
    offsetTop: { description: 'Triggered when the specified offset is reached from the top of the window', control: 'number' },
    offsetBottom: { description: 'Triggered when the specified offset is reached from the bottom of the window', control: false },
    target: { description: 'Set the element that Affix needs to listen to its scroll event, the value is a function that returns the corresponding DOM element', control: false },
    onChange: { description: 'Callback function triggered when fixed state changes', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Affix>

const ORDERS = Array.from({ length: 20 }, (_, i) => `Order #${1001 + i}`)

/**
 * Figma's Affix page has no component set, only an example: a header bar
 * pinned above a list that scrolls underneath it. `target` points Affix at
 * the list's own scroll container instead of the window, so the pinning
 * happens inside the Storybook canvas — antd's "Container to scroll" demo
 * pattern. The bar gets the container surface colour so rows don't show
 * through it, and a split line only once it's actually pinned (`onChange`),
 * so the pinned state is visible rather than implied.
 *
 * Affix measures the container on its own scroll events; scrolling the
 * whole Docs page while the bar is pinned can leave it briefly misplaced
 * until the list is scrolled again — the same limitation antd's demo has.
 */
function AffixDemo({ offsetTop }: Pick<AffixProps, 'offsetTop'>) {
  const { token } = theme.useToken()
  const [container, setContainer] = useState<HTMLDivElement | null>(null)
  const [affixed, setAffixed] = useState(false)
  return (
    <div
      ref={setContainer}
      style={{
        maxWidth: 480,
        height: 320,
        overflowY: 'auto',
        background: token.colorBgContainer,
        border: `${token.lineWidth}px ${token.lineType} ${token.colorBorderSecondary}`,
        borderRadius: token.borderRadiusLG,
      }}
    >
      <div style={{ padding: 16 }}>
        <Typography.Text type="secondary">
          Scroll the list — the header stays pinned to the top of this container.
        </Typography.Text>
      </div>
      <Affix target={() => container} offsetTop={offsetTop} onChange={(value) => setAffixed(Boolean(value))}>
        <Flex
          justify="space-between"
          align="center"
          style={{
            padding: '8px 16px',
            background: token.colorBgContainer,
            borderBottom: `${token.lineWidth}px ${token.lineType} ${affixed ? token.colorSplit : 'transparent'}`,
          }}
        >
          <Typography.Text strong>Orders</Typography.Text>
          <Button icon={<Plus />}>New order</Button>
        </Flex>
      </Affix>
      {ORDERS.map((order) => (
        <div
          key={order}
          style={{ padding: '12px 16px', borderTop: `${token.lineWidth}px ${token.lineType} ${token.colorSplit}` }}
        >
          {order}
        </div>
      ))}
    </div>
  )
}

export const Default: Story = {
  render: (args) => <AffixDemo offsetTop={args.offsetTop} />,
  parameters: { docs: { source: { code: '() => <AffixDemo offsetTop={0} />' } } },
}
