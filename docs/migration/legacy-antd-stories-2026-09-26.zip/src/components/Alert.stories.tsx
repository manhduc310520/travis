import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ReactNode } from 'react'
import { Alert, Button, Space, theme } from 'antd'
import { AlertCircle, CheckCircle, InfoCircle, X, XCircle } from '../icons'

/**
 * Figma's Alert instances use `x-circle-line`, `info-circle-line`,
 * `check-circle-line`, `alert-circle-line` — circular icons, not the
 * triangle/shield glyphs Ant Design defaults to. `showIcon` alone renders the
 * wrong shape; the icon must be passed explicitly per type.
 */
const ICONS = {
  error: <XCircle />,
  info: <InfoCircle />,
  success: <CheckCircle />,
  warning: <AlertCircle />,
} as const

const meta: Meta<typeof Alert> = {
  component: Alert,
  title: 'Components/Alert',
  tags: ['ai-generated', 'needs-work'],
  // Every story below uses a custom `render`, none set `args` — but the
  // Docs page's argTypes table only renders once at least one arg exists
  // (verified: it was silently empty without this). This default is never
  // seen since no story reads args directly; it exists purely so the
  // Controls table has something to display.
  args: { type: 'info', title: 'Info Text', showIcon: true },
  // `type`/`closable`/`title`/`description`/`showIcon` descriptions are
  // antd's own JSDoc from Alert.d.ts, copied as-is. `banner`/`icon` have no
  // JSDoc in antd — written from the API itself, not guessed.
  argTypes: {
    type: {
      description: 'Type of Alert styles.',
      control: 'select',
      options: ['success', 'info', 'warning', 'error'],
    },
    title: { description: 'Content of Alert.', control: 'text' },
    description: { description: 'Additional content of Alert.', control: 'text' },
    closable: { description: 'Whether Alert can be closed.', control: 'boolean' },
    showIcon: { description: 'Whether to show icon.', control: 'boolean' },
    banner: { description: 'Renders as a square-cornered banner meant to sit flush at the top of a page.', control: 'boolean' },
    icon: { description: 'Custom icon, only effective when showIcon is true.', control: false },
    variant: { description: 'Visual style: pastel background with a matching border, or a solid fill.', control: 'select', options: ['outlined', 'filled'] },
  },
}
export default meta
type Story = StoryObj<typeof Alert>

export const Types: Story = {
  args: {
    closable: false,
    banner: false,
    variant: "outlined"
  },

  render: () => (
    <Space orientation="vertical" style={{ width: '100%', maxWidth: 480 }}>
      <Alert type="success" title="Success Text" showIcon icon={ICONS.success} style={{ width: '100%' }} />
      <Alert type="info" title="Info Text" showIcon icon={ICONS.info} style={{ width: '100%' }} />
      <Alert type="warning" title="Warning Text" showIcon icon={ICONS.warning} style={{ width: '100%' }} />
      <Alert type="error" title="Error Text" showIcon icon={ICONS.error} style={{ width: '100%' }} />
    </Space>
  )
}

/** `variant="filled"` swaps the pastel background for the semantic color's solid text shade. */
export const Filled: Story = {
  args: {
    variant: "filled"
  },

  render: () => (
    <Space orientation="vertical" style={{ width: '100%', maxWidth: 480 }}>
      <Alert type="success" title="Success Text" showIcon icon={ICONS.success} variant="filled" style={{ width: '100%' }} />
      <Alert type="info" title="Info Text" showIcon icon={ICONS.info} variant="filled" style={{ width: '100%' }} />
      <Alert type="warning" title="Warning Text" showIcon icon={ICONS.warning} variant="filled" style={{ width: '100%' }} />
      <Alert type="error" title="Error Text" showIcon icon={ICONS.error} variant="filled" style={{ width: '100%' }} />
    </Space>
  )
}

export const WithDescription: Story = {
  render: () => (
    <Space orientation="vertical" style={{ width: '100%', maxWidth: 480 }}>
      <Alert
        type="success"
        title="Success Text"
        description="Detailed description and advice about successful copywriting."
        showIcon
        icon={ICONS.success}
        style={{ width: '100%' }}
      />
      <Alert
        type="info"
        title="Info Text"
        description="Additional description and information about copywriting."
        showIcon
        icon={ICONS.info}
        style={{ width: '100%' }}
      />
      <Alert
        type="warning"
        title="Warning Text"
        description="This is a warning notice about copywriting."
        showIcon
        icon={ICONS.warning}
        style={{ width: '100%' }}
      />
      <Alert
        type="error"
        title="Error Text"
        description="This is an error message about copywriting."
        showIcon
        icon={ICONS.error}
        style={{ width: '100%' }}
      />
    </Space>
  ),
}

export const Closable: Story = {
  args: { type: 'info', title: 'Closable Alert', showIcon: true, icon: ICONS.info, closable: true, style: { maxWidth: 480 } },
}

/** Figma's `Custom Actions` slot: a text action plus one or two buttons. */
export const WithActions: Story = {
  args: {
    type: 'error',
    showIcon: true,
    icon: ICONS.error,
    title: 'Error Text',
    closable: true,
    style: { maxWidth: 640 },
    action: (
      <Space size={8}>
        <Button size="small" type="primary">Accept</Button>
        <Button size="small" danger>Decline</Button>
      </Space>
    ),
  },
}

/** Small caption naming the Figma variant an example stands for. */
function Caption({ children }: { children: ReactNode }) {
  const { token } = theme.useToken()
  return <div style={{ fontSize: token.fontSizeSM, color: token.colorTextDescription, marginBottom: 4 }}>{children}</div>
}

/**
 * `Banner: True` in Figma is the same Alert with square corners, meant to sit
 * flush at the top of a page. Shown next to `Banner: False` — the default,
 * rounded card — because that pairing is exactly how the Figma component page
 * presents the variant.
 */
export const Banner: Story = {
  render: () => (
    <Space orientation="vertical" size={16} style={{ width: '100%', maxWidth: 480 }}>
      <div>
        <Caption>Banner: False</Caption>
        <Alert type="warning" title="Warning Text" showIcon icon={ICONS.warning} style={{ width: '100%' }} />
      </div>
      <div>
        <Caption>Banner: True</Caption>
        <Alert type="warning" title="Warning Text" showIcon icon={ICONS.warning} banner style={{ width: '100%' }} />
      </div>
    </Space>
  ),
}

/**
 * The two Figma `Custom Actions` examples that `WithActions` doesn't cover:
 * a success alert with no description and a single text action (the
 * "Undo" pattern), and an info alert with a description whose actions stack
 * vertically on the right.
 */
export const CustomActions: Story = {
  render: () => (
    <Space orientation="vertical" size={16} style={{ width: '100%', maxWidth: 640 }}>
      <Alert
        type="success"
        title="Success Text"
        showIcon
        icon={ICONS.success}
        closable
        action={<Button size="small" type="text">Undo</Button>}
        style={{ width: '100%' }}
      />
      <Alert
        type="info"
        title="Info Text"
        description="Info Description Info Description Info Description Info Description"
        showIcon
        icon={ICONS.info}
        closable
        action={
          <Space orientation="vertical" size={8}>
            <Button size="small" type="primary">Accept</Button>
            <Button size="small" danger>Decline</Button>
          </Space>
        }
        style={{ width: '100%' }}
      />
    </Space>
  ),
}

/**
 * Figma's two banner examples: the default (info) banner and the warning
 * banner. Both keep the circle icon — `banner` alone would fall back to
 * Ant Design's triangle glyph.
 */
export const BannerTypes: Story = {
  render: () => (
    <Space orientation="vertical" size={16} style={{ width: '100%', maxWidth: 640 }}>
      <Alert type="info" title="Info Text" showIcon icon={ICONS.info} banner closable style={{ width: '100%' }} />
      <Alert type="warning" title="Warning Text" showIcon icon={ICONS.warning} banner closable style={{ width: '100%' }} />
    </Space>
  ),
}

/**
 * Figma's `Close Text?` and `Close Icon?` toggles. antd 6 deprecates
 * `closeText`/`closeIcon` in favour of `closable.closeIcon`, which accepts
 * either a string (close text) or a node (custom icon). The icon is the same
 * `X` glyph the Modal/Drawer/Notification close buttons use; an icon-only
 * close button has no text, so `closable` also carries its `aria-label`.
 */
export const CloseTextAndIcon: Story = {
  render: () => (
    <Space orientation="vertical" size={16} style={{ width: '100%', maxWidth: 480 }}>
      <Alert type="info" title="Info Text" showIcon icon={ICONS.info} closable={{ closeIcon: 'Close Now' }} style={{ width: '100%' }} />
      <Alert type="info" title="Info Text" showIcon icon={ICONS.info} closable={{ closeIcon: <X size={12} />, 'aria-label': 'Close' }} style={{ width: '100%' }} />
    </Space>
  ),
}
