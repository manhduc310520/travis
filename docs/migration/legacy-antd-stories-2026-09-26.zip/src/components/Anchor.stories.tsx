import type { Meta, StoryObj } from '@storybook/react-vite'
import { useRef } from 'react'
import { Anchor, theme } from 'antd'

const meta: Meta<typeof Anchor> = {
  component: Anchor,
  title: 'Components/Anchor',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's Anchor.d.ts — written from the API surface.
  argTypes: {
    items: { description: 'The list of link targets to render; nest `children` for a second level.', control: false },
    direction: { description: 'Layout direction of the link list.', control: 'select', options: ['vertical', 'horizontal'] },
    affix: { description: 'Pins the anchor to the viewport while the page scrolls.', control: 'boolean' },
    getCurrentAnchor: { description: 'Overrides which link is highlighted, instead of deriving it from scroll position.', control: false },
    getContainer: { description: 'The scrolling element whose position drives the active link (defaults to window).', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Anchor>

/**
 * Figma `Direction=Vertical` with both item levels: `Level=1` links and the
 * indented `Level=2` links under them come from nesting `children`.
 * `affix` is off so the list stays in the story instead of sticking to the
 * top of the Docs page; `getCurrentAnchor` pins the active state the Figma
 * example shows (these targets don't exist, so scroll can't set it).
 */
export const Default: Story = {
  args: {
    affix: false,
    getCurrentAnchor: () => '#part-1',
    items: [
      { key: '1', href: '#part-1', title: 'Part 1' },
      {
        key: '2',
        href: '#part-2',
        title: 'Part 2',
        children: [
          { key: '2-1', href: '#part-2-1', title: 'Part 2.1' },
          { key: '2-2', href: '#part-2-2', title: 'Part 2.2' },
        ],
      },
      { key: '3', href: '#part-3', title: 'Part 3' },
    ],
  },
}

/** Figma `Direction=Horizontal`. Horizontal anchors are single-level — antd doesn't support nested `children` in this direction. */
export const Horizontal: Story = {
  args: {
    affix: false,
    direction: 'horizontal',
    getCurrentAnchor: () => '#part-1',
    items: [
      { key: '1', href: '#part-1', title: 'Part 1' },
      { key: '2', href: '#part-2', title: 'Part 2' },
      { key: '3', href: '#part-3', title: 'Part 3' },
      { key: '4', href: '#part-4', title: 'Part 4' },
    ],
  },
}

const SECTIONS = [
  { id: 'anchor-spy-overview', title: 'Overview' },
  { id: 'anchor-spy-menu', title: 'Menu' },
  { id: 'anchor-spy-menu-food', title: 'Food' },
  { id: 'anchor-spy-menu-drinks', title: 'Drinks' },
  { id: 'anchor-spy-hours', title: 'Opening hours' },
]

/**
 * The real behaviour behind the Figma active state: the highlighted link
 * follows the scroll position of `getContainer`. Scroll the panel or click a
 * link. `onClick` calls `preventDefault()` so clicks scroll without pushing
 * `#hash` entries into the Storybook URL. The panel is a named, focusable
 * region so keyboard users can reach and scroll it too.
 */
function ScrollSpyDemo() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { token } = theme.useToken()
  return (
    <div style={{ display: 'flex', gap: 24 }}>
      <Anchor
        affix={false}
        getContainer={() => containerRef.current ?? window}
        onClick={(e) => e.preventDefault()}
        items={[
          { key: 'overview', href: '#anchor-spy-overview', title: 'Overview' },
          {
            key: 'menu',
            href: '#anchor-spy-menu',
            title: 'Menu',
            children: [
              { key: 'food', href: '#anchor-spy-menu-food', title: 'Food' },
              { key: 'drinks', href: '#anchor-spy-menu-drinks', title: 'Drinks' },
            ],
          },
          { key: 'hours', href: '#anchor-spy-hours', title: 'Opening hours' },
        ]}
      />
      <div
        ref={containerRef}
        tabIndex={0}
        role="region"
        aria-label="Page sections"
        style={{
          flex: 1,
          height: 240,
          overflowY: 'auto',
          border: `1px solid ${token.colorBorderSecondary}`,
          borderRadius: token.borderRadiusLG,
        }}
      >
        {SECTIONS.map((section) => (
          <section
            key={section.id}
            id={section.id}
            style={{ minHeight: 240, padding: 16, borderBottom: `1px solid ${token.colorBorderSecondary}` }}
          >
            <div style={{ fontWeight: token.fontWeightStrong }}>{section.title}</div>
            <div style={{ color: token.colorTextSecondary }}>Section content</div>
          </section>
        ))}
      </div>
    </div>
  )
}

export const ScrollSpy: Story = {
  render: () => <ScrollSpyDemo />,
}
