import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ReactNode } from 'react'
import { AutoComplete, Empty, Flex, Input, Typography, theme } from 'antd'
import { SearchMd } from '../icons'

const meta: Meta<typeof AutoComplete> = {
  component: AutoComplete,
  title: 'Components/AutoComplete',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's auto-complete types — written from the API.
  argTypes: {
    options: { description: 'The list of suggestions shown while typing.', control: false },
    disabled: { description: 'Disables the input.', control: 'boolean' },
    size: { description: 'Control height: small, middle (the 32px default) or large.', control: 'select', options: ['small', 'middle', 'large'] },
    variant: {
      description: 'Visual style of the field.',
      control: 'select',
      options: ['outlined', 'filled', 'borderless', 'underlined'],
    },
    open: { description: 'Controls whether the suggestion menu is shown.', control: 'boolean' },
    notFoundContent: { description: 'Shown in the menu when there are no suggestions; without it the menu stays closed.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof AutoComplete>

const options = [{ value: 'Option 1' }, { value: 'Option 2' }, { value: 'Option 3' }]

/** None of these examples has a visible label, so every field is named for assistive tech. */
const FIELD_LABEL = 'Search options'

/**
 * The search button is icon-only. Untitled UI icons render `aria-hidden`, so
 * this copy of the global search icon is exposed as a named image — its name
 * becomes the button's accessible name.
 */
const namedSearchIcon = <SearchMd role="img" aria-hidden={false} aria-label="Search" />

/** Figma menu `Type: With Groups` — a group is an option with its own `options`. */
const groupedOptions = [
  { label: 'Group 1', options: [{ value: 'Option 1' }, { value: 'Option 2' }] },
  { label: 'Group 2', options: [{ value: 'Option 3' }, { value: 'Option 4' }] },
]

/** Secondary 12px caption naming the Figma variant an example stands for. */
function Caption({ children, width }: { children: ReactNode; width?: number }) {
  const { token } = theme.useToken()
  return (
    <Typography.Text type="secondary" style={{ fontSize: token.fontSizeSM, width, flexShrink: 0 }}>
      {children}
    </Typography.Text>
  )
}

/**
 * Menus shown open for display portal into this box instead of `document.body`
 * (see `inFrame`), and the box reserves room for them — so neighbouring
 * examples never overlap and the Docs page scrolls them with their field.
 */
function PopupFrame({ label, width = 280, height = 200, children }: { label: string; width?: number; height?: number; children: ReactNode }) {
  return (
    <Flex vertical gap={4} style={{ width }}>
      <Caption>{label}</Caption>
      <div data-popup-frame="" style={{ position: 'relative', height }}>
        {children}
      </div>
    </Flex>
  )
}
const inFrame = (node: HTMLElement) => node.closest<HTMLElement>('[data-popup-frame]') ?? document.body
/** Pins the placement: by default the menu flips when it would leave the viewport mid-scroll. */
const pinned = { overflow: { adjustX: false, adjustY: false } }

export const Default: Story = { args: { 'aria-label': FIELD_LABEL, options, placeholder: 'Input here', style: { width: 280 } } }
export const Disabled: Story = { args: { 'aria-label': FIELD_LABEL, options, disabled: true, placeholder: 'Disabled', style: { width: 280 } } }

/** Figma `Size[Small|Default|Large]`. `middle` is antd's name for the 32px default. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {(
        [
          ['small', 'Small'],
          ['middle', 'Default'],
          ['large', 'Large'],
        ] as const
      ).map(([size, label]) => (
        <Flex key={size} gap={16} align="center">
          <Caption width={96}>{label}</Caption>
          <AutoComplete aria-label={FIELD_LABEL} size={size} options={options} placeholder="Input here" style={{ width: 280 }} />
        </Flex>
      ))}
    </Flex>
  ),
}

/** Figma `Type[Default|Borderless]`. antd expresses both through `variant`. */
export const Borderless: Story = {
  render: () => (
    <Flex gap={16} wrap>
      <Flex vertical gap={4}>
        <Caption>Type: Default</Caption>
        <AutoComplete aria-label={FIELD_LABEL} options={options} placeholder="Input here" style={{ width: 280 }} />
      </Flex>
      <Flex vertical gap={4}>
        <Caption>Type: Borderless</Caption>
        <AutoComplete aria-label={FIELD_LABEL} variant="borderless" options={options} placeholder="Input here" style={{ width: 280 }} />
      </Flex>
    </Flex>
  ),
}

/** Figma examples "open" and "open borderless" (`Active: Yes`), rendered statically open. */
export const Open: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Type: Default, Active">
        <AutoComplete aria-label={FIELD_LABEL} open popupAlign={pinned} getPopupContainer={inFrame} options={options} placeholder="Input here" style={{ width: 280 }} />
      </PopupFrame>
      <PopupFrame label="Type: Borderless, Active">
        <AutoComplete aria-label={FIELD_LABEL} open variant="borderless" popupAlign={pinned} getPopupContainer={inFrame} options={options} placeholder="Input here" style={{ width: 280 }} />
      </PopupFrame>
    </Flex>
  ),
}

/**
 * Figma menu `Type[Default|With Groups|Empty]`. antd keeps the menu closed
 * when there are no options, unless `notFoundContent` gives it something to
 * show — that is what the Empty menu needs.
 */
export const MenuTypes: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Menu: Default">
        <AutoComplete aria-label={FIELD_LABEL} open popupAlign={pinned} getPopupContainer={inFrame} options={options} placeholder="Input here" style={{ width: 280 }} />
      </PopupFrame>
      <PopupFrame label="Menu: With Groups" height={240}>
        <AutoComplete aria-label={FIELD_LABEL} open popupAlign={pinned} getPopupContainer={inFrame} options={groupedOptions} placeholder="Input here" style={{ width: 280 }} />
      </PopupFrame>
      <PopupFrame label="Menu: Empty">
        <AutoComplete
          aria-label={FIELD_LABEL}
          open
          popupAlign={pinned}
          getPopupContainer={inFrame}
          options={[]}
          notFoundContent={<Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
          placeholder="Input here"
          style={{ width: 280 }}
        />
      </PopupFrame>
    </Flex>
  ),
}

/**
 * Figma `AutoComplete / With Button`: `Input.Search` as the custom input.
 * Without `enterButton` the search button is a Default button; with it, the
 * button turns Primary. `size` is left off — antd sizes a custom input itself.
 */
export const WithButton: Story = {
  render: () => (
    <Flex vertical gap={16}>
      <Flex vertical gap={4}>
        <Caption>Type: Button Default</Caption>
        <AutoComplete aria-label={FIELD_LABEL} options={options} style={{ width: 320 }}>
          <Input.Search placeholder="Input here" searchIcon={namedSearchIcon} />
        </AutoComplete>
      </Flex>
      <Flex vertical gap={4}>
        <Caption>Type: Button Primary</Caption>
        <AutoComplete aria-label={FIELD_LABEL} options={options} style={{ width: 320 }}>
          <Input.Search placeholder="Input here" enterButton searchIcon={namedSearchIcon} />
        </AutoComplete>
      </Flex>
    </Flex>
  ),
}

/** Figma "with button, open": the Primary search variant with its menu statically open. */
export const WithButtonOpen: Story = {
  render: () => (
    <PopupFrame label="Type: Button Primary, Active" width={320}>
      <AutoComplete aria-label={FIELD_LABEL} open popupAlign={pinned} getPopupContainer={inFrame} options={options} style={{ width: 320 }}>
        <Input.Search placeholder="Input here" enterButton searchIcon={namedSearchIcon} />
      </AutoComplete>
    </PopupFrame>
  ),
}
