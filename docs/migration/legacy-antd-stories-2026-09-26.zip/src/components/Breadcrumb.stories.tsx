import type { Meta, StoryObj } from '@storybook/react-vite'
import { Breadcrumb } from 'antd'
import { Building02, Home01, User01 } from '../icons'
const meta: Meta<typeof Breadcrumb> = {
  component: Breadcrumb,
  title: 'Components/Breadcrumb',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on `items` in antd's breadcrumb types — written from the API.
  argTypes: {
    items: { description: 'The trail of items, rendered left to right with separators between them.', control: false },
    separator: { description: 'Custom separator rendered between items (defaults to "/").', control: 'text' },
  },
}
export default meta
type Story = StoryObj<typeof Breadcrumb>

/**
 * Figma `Type=Basic`. The link `State` variants map onto the item kind: an
 * item with `href` renders as a link (`Default`, `Hover` on mouse-over); the
 * last item has no `href` and is the `Current` page.
 */
export const Default: Story = {
  args: {
    items: [
      { title: 'Home', href: '#' },
      { title: 'Application Center', href: '#' },
      { title: 'Application List', href: '#' },
      { title: 'An Application' },
    ],
  },
}

/**
 * Figma `Type=Icon`, both `Icon?`/`Label?` combinations: an icon-only home
 * link, then icon + label items. Put the icon and text side by side inside
 * `title` — antd spaces them itself. The icon-only link has no text, so its
 * item carries an `aria-label`, which antd puts on the `<a>`.
 */
export const WithIcon: Story = {
  args: {
    items: [
      { href: '#', title: <Home01 />, 'aria-label': 'Home' },
      {
        href: '#',
        title: (
          <>
            <User01 />
            <span>Application Center</span>
          </>
        ),
      },
      {
        title: (
          <>
            <Building02 />
            <span>Application List</span>
          </>
        ),
      },
    ],
  },
}

/**
 * Figma `Type=Dropdown`: an item with a `menu` gets a chevron and opens a
 * dropdown of sibling pages on hover. The chevron is the Untitled UI
 * `ChevronDown`, set globally via ConfigProvider's `breadcrumb.dropdownIcon`.
 */
export const WithDropdown: Story = {
  args: {
    items: [
      { title: 'Ant Design', href: '#' },
      { title: 'Component', href: '#' },
      {
        title: 'General',
        menu: {
          items: [
            { key: 'general', label: 'General' },
            { key: 'layout', label: 'Layout' },
            { key: 'navigation', label: 'Navigation' },
          ],
        },
      },
      { title: 'Button' },
    ],
  },
}
