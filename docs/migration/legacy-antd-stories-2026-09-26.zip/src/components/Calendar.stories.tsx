import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Badge, Calendar, Col, Radio, Row, Select, Typography, theme } from 'antd'
import type { BadgeProps, CalendarMode, CalendarProps } from 'antd'
import type { Dayjs } from 'dayjs'

const meta: Meta<typeof Calendar> = {
  component: Calendar,
  title: 'Components/Calendar',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's calendar types — written from the API.
  argTypes: {
    fullscreen: { description: 'Full grid layout (true) vs a compact single-column layout for narrow spaces.', control: 'boolean' },
    headerRender: { description: 'Replaces the built-in month/year header with a custom one.', control: false },
    mode: { description: 'Which panel is shown: days of a month, or months of a year.', control: 'select', options: ['month', 'year'] },
    showWeek: { description: 'Adds a week-number column to the month panel.', control: 'boolean' },
    cellRender: { description: 'Renders extra content inside each date/month cell, below its number.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Calendar>

/** From the Figma component's Code Connect example ("Calendar / Card", `Custom Header: True`). */
const renderCustomHeader: CalendarProps<Dayjs>['headerRender'] = ({ value, type, onChange, onTypeChange }) => {
  const months = Array.from({ length: 12 }, (_, i) => value.clone().month(i).format('MMM'))
  const year = value.year()

  return (
    <div style={{ padding: 8 }}>
      <Typography.Title level={4}>Custom header</Typography.Title>
      <Row gutter={8}>
        <Col>
          <Radio.Group size="small" onChange={(e) => onTypeChange(e.target.value)} value={type}>
            <Radio.Button value="month">Month</Radio.Button>
            <Radio.Button value="year">Year</Radio.Button>
          </Radio.Group>
        </Col>
        <Col>
          <Select
            size="small"
            value={year}
            onChange={(newYear: number) => onChange(value.clone().year(newYear))}
            options={Array.from({ length: 20 }, (_, i) => year - 10 + i).map((y) => ({
              value: y,
              label: y,
            }))}
          />
        </Col>
        <Col>
          <Select
            size="small"
            value={value.month()}
            onChange={(newMonth: number) => onChange(value.clone().month(newMonth))}
            options={months.map((m, i) => ({ value: i, label: m }))}
          />
        </Col>
      </Row>
    </div>
  )
}

type CalendarDemoProps = Omit<CalendarProps<Dayjs>, 'fullscreen' | 'mode' | 'headerRender'> & {
  /** Figma `Calendar / Card`: the compact `fullscreen={false}` calendar inside a bordered 8px surface. */
  card?: boolean
  /** Figma `Year: True` — starts on the year panel. */
  initialMode?: CalendarMode
  /** Figma `Custom Header: True`. */
  customHeader?: boolean
}

/**
 * `mode` has no uncontrolled `defaultMode` in antd, so the year variants keep
 * it in state and follow `onPanelChange` — otherwise the header's Month/Year
 * switch would be stuck on whatever the story passed in.
 */
function CalendarDemo({ card = false, initialMode = 'month', customHeader = false, ...rest }: CalendarDemoProps) {
  const { token } = theme.useToken()
  const [mode, setMode] = useState<CalendarMode>(initialMode)
  const calendar = (
    <Calendar
      {...rest}
      fullscreen={!card}
      mode={mode}
      onPanelChange={(_, next) => setMode(next)}
      headerRender={customHeader ? renderCustomHeader : undefined}
    />
  )
  if (!card) return calendar
  return (
    <div style={{ width: 300, border: `1px solid ${token.colorBorderSecondary}`, borderRadius: token.borderRadiusLG }}>
      {calendar}
    </div>
  )
}

const Caption = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
    {children}
  </Typography.Text>
)

/** Figma `Calendar / Basic`, `Year: False` — the full-width month panel. */
export const Default: Story = {}

export const Fullscreen: Story = { args: { fullscreen: true } }

/** Figma `Calendar / Basic`, `Year: True` — the full-width year panel (one cell per month). */
export const BasicYear: Story = {
  render: () => <CalendarDemo initialMode="year" />,
}

/** Figma `Calendar / Card` — `fullscreen={false}` inside a bordered card surface. */
export const Card: Story = {
  render: () => <CalendarDemo card />,
}

/** Figma `Calendar / Card`, `Year: True`. */
export const CardYear: Story = {
  render: () => <CalendarDemo card initialMode="year" />,
}

/** Figma `Calendar / Card`, `Custom Header: True` — from the component's Code Connect example. */
export const CustomHeader: Story = {
  render: () => <CalendarDemo card customHeader />,
}

/** Figma `Calendar / Card`, `Year: True` + `Custom Header: True`. */
export const CardYearCustomHeader: Story = {
  render: () => <CalendarDemo card customHeader initialMode="year" />,
}

/** Figma "show week" in both sizes: `Mini` (card) and `Full` (fullscreen). */
export const ShowWeek: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div>
        <Caption>Mini</Caption>
        <CalendarDemo card showWeek />
      </div>
      <div>
        <Caption>Full</Caption>
        <CalendarDemo showWeek />
      </div>
    </div>
  ),
}

type Notice = { type: NonNullable<BadgeProps['status']>; content: string }

// Keyed by day-of-month so the notices show up whichever month is on screen.
const NOTICES: Record<number, Notice[]> = {
  8: [
    { type: 'warning', content: 'This is warning event.' },
    { type: 'success', content: 'This is usual event.' },
  ],
  10: [
    { type: 'warning', content: 'This is warning event.' },
    { type: 'success', content: 'This is usual event.' },
    { type: 'error', content: 'This is error event.' },
  ],
  15: [
    { type: 'warning', content: 'This is warning event' },
    { type: 'success', content: 'This is very long usual event......' },
    { type: 'error', content: 'This is error event 1.' },
    { type: 'error', content: 'This is error event 2.' },
    { type: 'error', content: 'This is error event 3.' },
  ],
}

/**
 * Figma "cells with notice": `cellRender` adds status badges under a date and
 * a backlog count under a month. Status colour comes from `Badge` (semantic
 * success / warning / error), not from hand-picked hex.
 */
function NoticeDemo() {
  const cellRender: CalendarProps<Dayjs>['cellRender'] = (current, info) => {
    if (info.type === 'date') {
      const list = NOTICES[current.date()] ?? []
      return (
        <ul style={{ margin: 0, padding: 0, listStyle: 'none' }}>
          {list.map((item) => (
            <li key={item.content} style={{ overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>
              <Badge status={item.type} text={item.content} />
            </li>
          ))}
        </ul>
      )
    }
    if (info.type === 'month' && current.month() === 8) {
      return (
        <div>
          <Typography.Title level={4} style={{ margin: 0 }}>
            1394
          </Typography.Title>
          <Typography.Text type="secondary">Backlog number</Typography.Text>
        </div>
      )
    }
    return info.originNode
  }
  return <CalendarDemo cellRender={cellRender} />
}

export const NoticeCells: Story = {
  render: () => <NoticeDemo />,
}
