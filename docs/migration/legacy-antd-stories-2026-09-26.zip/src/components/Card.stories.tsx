import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Card, Button, Statistic, Space, Row, Col, Avatar, Typography, theme } from 'antd'
import type { CardProps } from 'antd'
import { Building02, DotsHorizontal, Edit01, Heart, Settings01, Share01 } from '../icons'

const meta: Meta<typeof Card> = {
  component: Card,
  title: 'Components/Card',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's card/Card.d.ts — written from the API.
  argTypes: {
    title: { description: 'Card title.', control: 'text' },
    extra: { description: 'Content rendered at the top-right, alongside the title.', control: false },
    size: { description: 'Card density.', control: 'select', options: ['default', 'small'] },
    loading: { description: 'Shows a skeleton placeholder instead of the children.', control: 'boolean' },
    variant: { description: 'Whether the card draws its own border.', control: 'select', options: ['outlined', 'borderless'] },
    hoverable: { description: 'Lifts the card with a shadow on hover.', control: 'boolean' },
    type: { description: "Set to 'inner' for a card nested inside another card's body.", control: 'select', options: [undefined, 'inner'] },
    actions: { description: 'A row of icon actions along the bottom edge.', control: false },
    cover: { description: 'Content rendered above the header, e.g. an image.', control: false },
    tabList: { description: 'Renders a tab strip in the header; pair with activeTabKey/onTabChange.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Card>

const cover = (color: string) => <div style={{ height: 120, background: color }} />

export const Default: Story = {
  args: { title: 'Card title', style: { maxWidth: 320 }, children: 'Card content' },
}
export const WithExtra: Story = {
  args: {
    title: 'Card title',
    extra: <Button type="link">More</Button>,
    style: { maxWidth: 320 },
    children: <Statistic value={112893} prefix="$" />,
  },
}
export const Small: Story = {
  args: { title: 'Small size card', size: 'small', style: { width: 280 }, children: 'Card content' },
}

/** Ant Design's own "No border" example: `variant="borderless"` removes the card's outline. */
export const NoBorder: Story = {
  args: { title: 'Card title', variant: 'borderless', style: { maxWidth: 320 }, children: 'Card content' },
}

/** No title, no extra — just a bordered container for content. */
export const Simple: Story = {
  args: { style: { maxWidth: 320 }, children: 'Card content' },
}

/** `Card.Meta` lays out an avatar, title and description as one unit, alongside `cover` and `actions`. */
export const CustomizedContent: Story = {
  render: () => (
    <Card
      style={{ maxWidth: 320 }}
      cover={cover('#95DE64')}
      actions={[<Settings01 key="setting" />, <Edit01 key="edit" />, <DotsHorizontal key="ellipsis" />]}
    >
      <Card.Meta
        avatar={<Avatar icon={<Building02 />} />}
        title="Card title"
        description="This is the description"
      />
    </Card>
  ),
}

/** Cards laid out in a responsive grid via `Row`/`Col`, each borderless. */
export const InColumn: Story = {
  render: () => (
    <Row gutter={16}>
      {[1, 2, 3].map((n) => (
        <Col span={8} key={n}>
          <Card title="Card title" variant="borderless">
            Card content
          </Card>
        </Col>
      ))}
    </Row>
  ),
}

export const Loading: Story = { args: { title: 'Card title', loading: true, style: { maxWidth: 320 } } }

/** `Card.Grid` divides one card's body into its own bordered, hoverable cells. */
export const GridCard: Story = {
  render: () => {
    const cell: React.CSSProperties = { width: '25%', textAlign: 'center' }
    return (
      <Card title="Card title" style={{ maxWidth: 480 }}>
        <Card.Grid style={cell}>Content</Card.Grid>
        <Card.Grid hoverable={false} style={cell}>
          Content
        </Card.Grid>
        <Card.Grid style={cell}>Content</Card.Grid>
        <Card.Grid style={cell}>Content</Card.Grid>
      </Card>
    )
  },
}

/** `type="inner"` flattens a nested card's header for use inside another card's body. */
export const Inner: Story = {
  render: () => (
    <Card title="Card title" style={{ maxWidth: 480 }}>
      <Card type="inner" title="Inner Card title" extra={<a href="#">More</a>}>
        Inner Card content
      </Card>
      <Card style={{ marginTop: 16 }} type="inner" title="Inner Card title" extra={<a href="#">More</a>}>
        Inner Card content
      </Card>
    </Card>
  ),
}

/** `tabList`/`activeTabKey`/`onTabChange` render a tab strip in the card's own header. */
function WithTabsDemo({ variant }: { variant?: CardProps['variant'] }) {
  const tabList = [
    { key: 'tab1', tab: 'Tab 1' },
    { key: 'tab2', tab: 'Tab 2' },
  ]
  const content: Record<string, React.ReactNode> = {
    tab1: <p>Content 1</p>,
    tab2: <p>Content 2</p>,
  }
  const [activeKey, setActiveKey] = useState('tab1')
  return (
    <Card
      style={{ maxWidth: 480 }}
      variant={variant}
      title="Card title"
      extra={<a href="#">More</a>}
      tabList={tabList}
      activeTabKey={activeKey}
      onTabChange={setActiveKey}
    >
      {content[activeKey]}
    </Card>
  )
}

export const WithTabs: Story = {
  render: () => <WithTabsDemo />,
}

/**
 * Figma `Card / Basic`, `Borderless: True` + `Tabs: True`. Shown on the
 * Layout background: a borderless card is told apart from the page by
 * surface tone, so on the story's container-coloured canvas it would vanish.
 */
function BorderlessWithTabsDemo() {
  const { token } = theme.useToken()
  return (
    <div style={{ background: token.colorBgLayout, padding: 24, borderRadius: token.borderRadiusLG }}>
      <WithTabsDemo variant="borderless" />
    </div>
  )
}

export const BorderlessWithTabs: Story = {
  render: () => <BorderlessWithTabsDemo />,
}

/**
 * Figma `Card / Grid`, `Columns: 4 | 3 | 2` — the three grid docs examples.
 * Each `Card.Grid` cell takes 1/n of the width; two rows per card show the
 * cell dividers in both directions.
 */
export const GridColumns: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24, maxWidth: 480 }}>
      {[4, 3, 2].map((columns) => (
        <div key={columns}>
          <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
            Columns: {columns}
          </Typography.Text>
          <Card title="Card title">
            {Array.from({ length: columns * 2 }, (_, i) => (
              <Card.Grid key={i} style={{ width: `${100 / columns}%`, textAlign: 'center' }}>
                Content
              </Card.Grid>
            ))}
          </Card>
        </div>
      ))}
    </div>
  ),
}

/**
 * Figma `Card / Advanced`, `Image: False`, for both types: Advanced (meta
 * with avatar + action row) and Simple (title + description only). The
 * with-image versions are `CustomizedContent` and
 * `SupportMoreContentConfiguration` above.
 */
export const WithoutImage: Story = {
  render: () => (
    <Space size="middle" align="start" wrap>
      <Card
        style={{ width: 300 }}
        actions={[<Settings01 key="setting" />, <Edit01 key="edit" />, <DotsHorizontal key="ellipsis" />]}
      >
        <Card.Meta avatar={<Avatar icon={<Building02 />} />} title="Card title" description="This is the description" />
      </Card>
      <Card hoverable style={{ width: 240 }}>
        <Card.Meta title="Card title" description="www.example.com" />
      </Card>
    </Space>
  ),
}

/** `hoverable` + `variant="borderless"` + `cover` + `Card.Meta`, combined. */
export const SupportMoreContentConfiguration: Story = {
  render: () => (
    <Card hoverable variant="borderless" style={{ width: 240 }} cover={cover('#69B1FF')}>
      <Card.Meta title="Card title" description="www.example.com" />
    </Card>
  ),
}

/**
 * antd's demo with its hard-coded colours swapped for theme tokens (the preset
 * palette for the decorative accents), so the tinted title keeps readable contrast.
 */
function CustomSemanticStylingDemo() {
  const { token } = theme.useToken()
  const actions = [
    <Heart key="heart" style={{ color: token.magenta7 }} />,
    <Share01 key="share" style={{ color: token.cyan7 }} />,
    <Edit01 key="edit" style={{ color: token.blue7 }} />,
  ]
  const title: React.CSSProperties = { fontSize: token.fontSize, fontWeight: token.fontWeightStrong }
  return (
    <Space size="middle">
      <Card
        title="Object styling"
        variant="borderless"
        actions={actions}
        styles={{ root: { boxShadow: token.boxShadowTertiary, borderRadius: token.borderRadiusLG }, title }}
      >
        <Card.Meta avatar={<Avatar icon={<Building02 />} />} title="Card Meta title" description="This is the description" />
      </Card>
      <Card
        title="Function styling"
        variant="outlined"
        actions={actions}
        styles={(info) =>
          info.props.variant === 'outlined'
            ? {
                root: { borderColor: token.purple6, boxShadow: token.boxShadowTertiary, borderRadius: token.borderRadiusLG },
                title: { ...title, color: token.purple7 },
              }
            : {}
        }
      >
        <Card.Meta avatar={<Avatar icon={<Building02 />} />} title="Card Meta title" description="This is the description" />
      </Card>
    </Space>
  )
}

/** `classNames`/`styles` target individual semantic parts (root/header/body/title/...) without CSS overrides. */
export const CustomSemanticStyling: Story = {
  render: () => <CustomSemanticStylingDemo />,
}
