import type { Meta, StoryObj } from '@storybook/react-vite'
import { Carousel, Typography } from 'antd'

const meta: Meta<typeof Carousel> = {
  component: Carousel,
  title: 'Components/Carousel',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's carousel/index.d.ts — written from the API.
  // `dotPosition` is deprecated in antd 6 in favour of `dotPlacement`, which
  // is also the Figma property name (`Dot Placement`).
  argTypes: {
    dotPlacement: { description: 'Where the pagination dots sit. `start`/`end` also switch the carousel to vertical sliding.', control: 'select', options: ['bottom', 'top', 'start', 'end'] },
    arrows: { description: 'Shows previous/next arrow buttons over the slides.', control: 'boolean' },
    autoplay: { description: 'Advances slides automatically.', control: 'boolean' },
    effect: { description: 'Transition between slides.', control: 'select', options: ['scrollx', 'fade'] },
    dots: { description: 'Whether to show the pagination dots.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Carousel>

// Slide fills are demo content (stand-ins for images), not UI chrome.
const slide = (label: string, bg: string) => (
  <div key={label} style={{ height: 160, background: bg, color: '#fff', display: 'grid', placeItems: 'center' }}>
    {label}
  </div>
)

const slides = [slide('Slide 1', '#003EB3'), slide('Slide 2', '#0958D9'), slide('Slide 3', '#1677FF'), slide('Slide 4', '#4096FF')]

export const Default: Story = {
  args: { dotPlacement: 'bottom', arrows: false },
  render: (args) => (
    <div style={{ maxWidth: 480 }}>
      <Carousel {...args}>{slides}</Carousel>
    </div>
  ),
}

/**
 * Figma `Dot Placement: Bottom | Top | Start | End`, the four docs examples,
 * side by side. Start/End make antd slide vertically (`vertical` follows the
 * placement unless set explicitly).
 */
export const DotPlacement: Story = {
  render: () => (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24, maxWidth: 984 }}>
      {(['bottom', 'top', 'start', 'end'] as const).map((placement) => (
        <div key={placement}>
          <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
            Dot Placement: {placement}
          </Typography.Text>
          <Carousel dotPlacement={placement}>{slides}</Carousel>
        </div>
      ))}
    </div>
  ),
}

/** Figma `Arrows: True` — previous/next buttons over the slides, dots kept. */
export const Arrows: Story = {
  render: () => (
    <div style={{ maxWidth: 480 }}>
      <Carousel arrows infinite={false}>
        {slides}
      </Carousel>
    </div>
  ),
}
