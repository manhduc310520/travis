import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ReactNode } from 'react'
import { Cascader, Flex, Typography, theme } from 'antd'

const meta: Meta<typeof Cascader> = {
  component: Cascader,
  title: 'Components/Cascader',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's cascader types — written from the API.
  argTypes: {
    options: { description: 'The nested list of selectable options.', control: false },
    multiple: { description: 'Allows selecting more than one leaf/branch at once.', control: 'boolean' },
    size: { description: 'Control height: small, middle (the 32px default) or large.', control: 'select', options: ['small', 'middle', 'large'] },
    placement: {
      description: 'Where the menu opens relative to the field.',
      control: 'select',
      options: ['bottomLeft', 'bottomRight', 'topLeft', 'topRight'],
    },
    open: { description: 'Controls whether the menu is shown.', control: 'boolean' },
    disabled: { description: 'Disables the cascader.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Cascader>

const options = [
  { value: 'option-1', label: 'Option 1', children: [{ value: 'option-1-1', label: 'Option 1-1' }, { value: 'option-1-2', label: 'Option 1-2' }] },
  { value: 'option-2', label: 'Option 2', children: [{ value: 'option-2-1', label: 'Option 2-1' }] },
]

/** Figma's menu item `disabled` state: one branch can't be opened or picked. */
const optionsWithDisabled = [
  ...options,
  { value: 'option-3', label: 'Option 3', disabled: true, children: [{ value: 'option-3-1', label: 'Option 3-1' }] },
]

/** None of these examples has a visible label, so every field is named for assistive tech. */
const FIELD_LABEL = 'Option'

/** Opening on an existing value expands its path, so the menu shows both columns as Figma draws it. */
const openPath = ['option-1', 'option-1-1']

/** Secondary 12px caption naming the Figma variant an example stands for. */
function Caption({ children, width }: { children: ReactNode; width?: number }) {
  const { token } = theme.useToken()
  return (
    <Typography.Text type="secondary" style={{ fontSize: token.fontSizeSM, width, flexShrink: 0 }}>
      {children}
    </Typography.Text>
  )
}

/**
 * Menus shown open for display portal into this box instead of `document.body`
 * (see `inFrame`), and the box reserves room for them — so neighbouring
 * examples never overlap and the Docs page scrolls them with their field.
 * `top*` placements sit the field at the bottom of the box, `*Right` at its
 * right edge, leaving the menu room on the side it opens toward.
 */
function PopupFrame({
  label,
  placement = 'bottomLeft',
  width = 280,
  height = 260,
  children,
}: {
  label: string
  placement?: 'bottomLeft' | 'bottomRight' | 'topLeft' | 'topRight'
  width?: number
  height?: number
  children: ReactNode
}) {
  return (
    <Flex vertical gap={4} style={{ width }}>
      <Caption>{label}</Caption>
      <Flex
        data-popup-frame=""
        align={placement.startsWith('top') ? 'flex-end' : 'flex-start'}
        justify={placement.endsWith('Right') ? 'flex-end' : 'flex-start'}
        style={{ position: 'relative', height }}
      >
        {children}
      </Flex>
    </Flex>
  )
}
const inFrame = (node: HTMLElement) => node.closest<HTMLElement>('[data-popup-frame]') ?? document.body
/** Pins the placement: by default the menu flips when it would leave the viewport, so a "Top" example could open downward mid-scroll. */
const pinned = { overflow: { adjustX: false, adjustY: false } }

export const Default: Story = { args: { 'aria-label': FIELD_LABEL, options, placeholder: 'Please select', style: { width: 280 } } }
export const Multiple: Story = { args: { 'aria-label': FIELD_LABEL, options, multiple: true, placeholder: 'Please select', style: { maxWidth: 320 } } }

/** Figma `Size[Small|Default|Large]`. `middle` is antd's name for the 32px default. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {(
        [
          ['small', 'Small'],
          ['middle', 'Default'],
          ['large', 'Large'],
        ] as const
      ).map(([size, label]) => (
        <Flex key={size} gap={16} align="center">
          <Caption width={96}>{label}</Caption>
          <Cascader aria-label={FIELD_LABEL} size={size} options={options} placeholder="Please select" style={{ width: 240 }} />
        </Flex>
      ))}
    </Flex>
  ),
}

/** Figma examples: open at `Placement[Bottom Left|Bottom Right|Top Right|Top Left]`, rendered statically open. */
export const Placements: Story = {
  render: () => (
    <Flex vertical gap={24}>
      <Flex gap={48} wrap>
        <PopupFrame label="Placement: Top Left" placement="topLeft">
          <Cascader aria-label={FIELD_LABEL} open placement="topLeft" popupAlign={pinned} getPopupContainer={inFrame} options={options} defaultValue={openPath} style={{ width: 200 }} />
        </PopupFrame>
        <PopupFrame label="Placement: Top Right" placement="topRight">
          <Cascader aria-label={FIELD_LABEL} open placement="topRight" popupAlign={pinned} getPopupContainer={inFrame} options={options} defaultValue={openPath} style={{ width: 200 }} />
        </PopupFrame>
      </Flex>
      <Flex gap={48} wrap>
        <PopupFrame label="Placement: Bottom Left">
          <Cascader aria-label={FIELD_LABEL} open placement="bottomLeft" popupAlign={pinned} getPopupContainer={inFrame} options={options} defaultValue={openPath} style={{ width: 200 }} />
        </PopupFrame>
        <PopupFrame label="Placement: Bottom Right" placement="bottomRight">
          <Cascader aria-label={FIELD_LABEL} open placement="bottomRight" popupAlign={pinned} getPopupContainer={inFrame} options={options} defaultValue={openPath} style={{ width: 200 }} />
        </PopupFrame>
      </Flex>
    </Flex>
  ),
}

/**
 * Figma menu item `Type[Default|Checkbox]` plus the disabled item, open side
 * by side. `multiple` is what switches the items to checkboxes.
 */
export const MenuItemTypes: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Item: Default (with disabled)">
        <Cascader aria-label={FIELD_LABEL} open popupAlign={pinned} getPopupContainer={inFrame} options={optionsWithDisabled} defaultValue={openPath} style={{ width: 200 }} />
      </PopupFrame>
      <PopupFrame label="Item: Checkbox (with disabled)" width={320}>
        <Cascader
          aria-label={FIELD_LABEL}
          open
          multiple
          popupAlign={pinned}
          getPopupContainer={inFrame}
          options={optionsWithDisabled}
          defaultValue={[openPath]}
          style={{ width: 240 }}
        />
      </PopupFrame>
    </Flex>
  ),
}

export const Disabled: Story = { args: { 'aria-label': FIELD_LABEL, options, disabled: true, placeholder: 'Please select', style: { width: 280 } } }
