import type { Meta, StoryObj } from '@storybook/react-vite'
import { Collapse, Typography } from 'antd'
import type { CollapseProps } from 'antd'
import { Settings01 } from '../icons'

const meta: Meta<typeof Collapse> = {
  component: Collapse,
  title: 'Components/Collapse',
  tags: ['ai-generated', 'needs-work'],
  // `accordion`'s only JSDoc in antd's Collapse.d.ts is Chinese-only
  // ("手风琴效果" — accordion effect); described here in English from the
  // verified behavior instead of machine-translating that comment.
  // The rest have no JSDoc at all — written from the API.
  argTypes: {
    items: { description: 'The list of panels.', control: false },
    defaultActiveKey: { description: 'Key(s) expanded on initial render (uncontrolled).', control: false },
    accordion: { description: 'Only one panel can be open at a time; opening one closes the others.', control: 'boolean' },
    bordered: { description: 'Figma `Type: Basic` (true) vs `Type: Borderless` (false).', control: 'boolean' },
    ghost: { description: 'Figma `Type: Ghost` — no border and a transparent background.', control: 'boolean' },
    size: { description: 'Figma `Size`: Small / Default (medium) / Large.', control: 'select', options: ['small', 'medium', 'large'] },
    // antd 6 renamed `expandIconPosition` to `expandIconPlacement` and its
    // values to logical `start`/`end` (Figma's Left/Right).
    expandIconPlacement: { description: 'Figma `Expand Icon Placement`: Left = `start`, Right = `end`.', control: 'select', options: ['start', 'end'] },
  },
}
export default meta
type Story = StoryObj<typeof Collapse>

const items: NonNullable<CollapseProps['items']> = [
  { key: '1', label: 'This is panel header 1', children: <p>Content of panel 1</p> },
  { key: '2', label: 'This is panel header 2', children: <p>Content of panel 2</p> },
  { key: '3', label: 'This is panel header 3', children: <p>Content of panel 3</p> },
]

const Caption = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
    {children}
  </Typography.Text>
)

/** Figma `Type: Basic` — the first docs example. */
export const Default: Story = { args: { items, defaultActiveKey: ['1'], style: { maxWidth: 480 } } }
export const Accordion: Story = { args: { items, accordion: true, style: { maxWidth: 480 } } }

/** Figma `Type: Borderless` — `bordered={false}` drops the outer border, panels keep their dividers. */
export const Borderless: Story = { args: { items, bordered: false, defaultActiveKey: ['1'], style: { maxWidth: 480 } } }

/** Figma `Type: Ghost` — no border, no fill: the panels sit directly on the parent surface. */
export const Ghost: Story = { args: { items, ghost: true, defaultActiveKey: ['1'], style: { maxWidth: 480 } } }

/** Figma `Size: Small | Default | Large`. antd 6 calls the default size `medium`. */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24, maxWidth: 480 }}>
      {(['small', 'medium', 'large'] as const).map((size) => (
        <div key={size}>
          <Caption>Size: {size === 'medium' ? 'default (medium)' : size}</Caption>
          <Collapse size={size} items={[{ key: '1', label: 'This is panel header', children: <p>Content of panel</p> }]} />
        </div>
      ))}
    </div>
  ),
}

/** Figma item `Expand Icon Placement: Right` — antd 6 `expandIconPlacement="end"`. */
export const ExpandIconRight: Story = {
  args: { items, expandIconPlacement: 'end', defaultActiveKey: ['1'], style: { maxWidth: 480 } },
}

/** Figma item `Disabled` — `collapsible: 'disabled'` greys the header out and blocks toggling. */
export const DisabledItem: Story = {
  args: {
    items: [
      { key: '1', label: 'This panel can be toggled', children: <p>Content of panel 1</p> },
      { key: '2', label: 'This panel is disabled', collapsible: 'disabled', children: <p>Content of panel 2</p> },
    ],
    style: { maxWidth: 480 },
  },
}

/**
 * Figma item `Extra Node: True` — a node at the far end of the header. The
 * click is stopped so using the extra action doesn't also toggle the panel.
 */
export const ExtraNode: Story = {
  args: {
    items: items.map((item) => ({
      ...item,
      extra: <Settings01 onClick={(e) => e.stopPropagation()} style={{ cursor: 'pointer' }} />,
    })),
    defaultActiveKey: ['1'],
    style: { maxWidth: 480 },
  },
}
