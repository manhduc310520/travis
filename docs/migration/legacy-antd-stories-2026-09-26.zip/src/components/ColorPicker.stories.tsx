import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ReactNode } from 'react'
import { ColorPicker, Flex, Typography, theme } from 'antd'

const meta: Meta<typeof ColorPicker> = {
  component: ColorPicker,
  title: 'Components/ColorPicker',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's color-picker types — written from the API.
  argTypes: {
    disabled: { description: 'Disables the color picker.', control: 'boolean' },
    showText: { description: 'Shows the hex value as text next to the swatch.', control: 'boolean' },
    size: { description: 'Trigger size: small, middle (the 32px default) or large.', control: 'select', options: ['small', 'middle', 'large'] },
    open: { description: 'Controls whether the picker panel is shown.', control: 'boolean' },
    allowClear: { description: 'Adds a clear button to the panel that empties the value.', control: 'boolean' },
    presets: { description: 'Groups of ready-made colors listed under the picker.', control: false },
    mode: {
      description: "'single', 'gradient', or both — both adds a switch between them at the top of the panel.",
      control: false,
    },
  },
}
export default meta
type Story = StoryObj<typeof ColorPicker>

const VALUE = '#003EB3'
/** The Blue brand's header gradient (`colorHeaderBgStart` → `colorHeaderBgEnd`), a gradient the product already uses. */
const GRADIENT = [
  { color: '#003EB3', percent: 0 },
  { color: '#0958D9', percent: 100 },
]

/** Secondary 12px caption naming the Figma variant an example stands for. */
function Caption({ children, width }: { children: ReactNode; width?: number }) {
  const { token } = theme.useToken()
  return (
    <Typography.Text type="secondary" style={{ fontSize: token.fontSizeSM, width, flexShrink: 0 }}>
      {children}
    </Typography.Text>
  )
}

/**
 * Panels shown open for display portal into this box instead of
 * `document.body` (see `inFrame`), and the box reserves room for them — so
 * neighbouring examples never overlap and the Docs page scrolls them with
 * their trigger.
 */
function PopupFrame({ label, height = 360, children }: { label: string; height?: number; children: ReactNode }) {
  return (
    <Flex vertical gap={4} style={{ width: 280 }}>
      <Caption>{label}</Caption>
      <div data-popup-frame="" style={{ position: 'relative', height }}>
        {children}
      </div>
    </Flex>
  )
}
const inFrame = (node: HTMLElement) => node.closest<HTMLElement>('[data-popup-frame]') ?? document.body

export const Default: Story = { args: { defaultValue: VALUE } }
export const WithText: Story = { args: { defaultValue: VALUE, showText: true } }
export const Disabled: Story = {
  render: () => (
    <Flex gap={16}>
      <ColorPicker defaultValue={VALUE} disabled />
      <ColorPicker defaultValue={VALUE} disabled showText />
    </Flex>
  ),
}

/** Figma trigger `Size[Small|Medium|Large]` × `Show Text`. `middle` is antd's name for Medium. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {(
        [
          ['small', 'Small'],
          ['middle', 'Medium'],
          ['large', 'Large'],
        ] as const
      ).map(([size, label]) => (
        <Flex key={size} gap={16} align="center">
          <Caption width={96}>{label}</Caption>
          <ColorPicker size={size} defaultValue={VALUE} />
          <ColorPicker size={size} defaultValue={VALUE} showText />
        </Flex>
      ))}
    </Flex>
  ),
}

/**
 * Figma "open" example (trigger `State: Active`), rendered statically open.
 * `autoAdjustOverflow={false}` keeps the panel below its trigger instead of
 * flipping when the Docs page scrolls it near the viewport edge.
 */
export const Open: Story = {
  render: () => (
    <PopupFrame label="State: Active">
      <ColorPicker open autoAdjustOverflow={false} getPopupContainer={inFrame} defaultValue={VALUE} showText />
    </PopupFrame>
  ),
}

/**
 * Figma popup `Presets?`. The swatches are the theme's own palette — the
 * semantic colors plus the preset hues — read from the active theme, so they
 * follow the Brand toolbar instead of restating hex values.
 */
function PresetsDemo() {
  const { token } = theme.useToken()
  return (
    <PopupFrame label="Presets" height={480}>
      <ColorPicker
        open
        autoAdjustOverflow={false}
        getPopupContainer={inFrame}
        defaultValue={token.colorPrimary}
        presets={[
          { label: 'Semantic', colors: [token.colorPrimary, token.colorSuccess, token.colorWarning, token.colorError] },
          {
            label: 'Palette',
            colors: [token.blue, token.purple, token.cyan, token.green, token.magenta, token.red, token.orange, token.gold],
          },
          { label: 'Recent', colors: [], defaultOpen: false },
        ]}
      />
    </PopupFrame>
  )
}

export const Presets: Story = {
  render: () => <PresetsDemo />,
}

/** Figma popup `Allow Clear?`: a clear control in the panel header; clearing leaves the trigger showing an empty swatch. */
export const AllowClear: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Allow Clear">
        <ColorPicker open allowClear autoAdjustOverflow={false} getPopupContainer={inFrame} defaultValue={VALUE} />
      </PopupFrame>
      <Flex vertical gap={4}>
        <Caption>Cleared</Caption>
        <ColorPicker allowClear defaultValue={null} />
      </Flex>
    </Flex>
  ),
}

/**
 * Figma popup `Gradient` and `Segmented?`. `mode="gradient"` alone gives the
 * gradient editor; allowing both modes adds the Single / Gradient segmented
 * switch at the top of the panel.
 */
export const Gradient: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Gradient" height={420}>
        <ColorPicker open mode="gradient" autoAdjustOverflow={false} getPopupContainer={inFrame} defaultValue={GRADIENT} />
      </PopupFrame>
      <PopupFrame label="Gradient + Segmented" height={420}>
        <ColorPicker open mode={['single', 'gradient']} autoAdjustOverflow={false} getPopupContainer={inFrame} defaultValue={GRADIENT} />
      </PopupFrame>
    </Flex>
  ),
}
