import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ReactNode } from 'react'
import { DatePicker, Flex, Typography, theme, type DatePickerProps, type GetProps } from 'antd'
import dayjs, { type Dayjs } from 'dayjs'
import { Bell01 } from '../icons'

const meta: Meta<typeof DatePicker> = {
  component: DatePicker,
  title: 'Components/DatePicker',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc found on these in antd's generated picker types — written
  // from the API surface.
  argTypes: {
    picker: {
      description: 'Granularity of the picker panel.',
      control: 'select',
      options: ['date', 'week', 'month', 'quarter', 'year'],
    },
    disabled: { description: 'Disables the input.', control: 'boolean' },
    status: { description: 'Validation state — colors the border and focus ring.', control: 'select', options: ['', 'warning', 'error'] },
    size: { description: 'Control height: small, middle (the 32px default) or large.', control: 'select', options: ['small', 'middle', 'large'] },
    variant: {
      description: 'Visual style of the field.',
      control: 'select',
      options: ['outlined', 'filled', 'borderless', 'underlined'],
    },
    showTime: { description: 'Adds hour/minute/second columns to the date panel.', control: 'boolean' },
    multiple: { description: 'Lets the user pick several dates; each shows as a tag in the field.', control: 'boolean' },
    presets: { description: 'Shortcut values listed beside the panel.', control: false },
    prefix: { description: 'Content rendered before the value, inside the field.', control: false },
    open: { description: 'Controls whether the panel is shown.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof DatePicker>
type RangePickerProps = GetProps<typeof DatePicker.RangePicker>

const { RangePicker } = DatePicker

// Fixed dates, not `dayjs()`: an open panel on "today" would change the
// visual snapshot every day.
const DAY = dayjs('2026-03-12')
const DAY_TIME = dayjs('2026-03-12T13:30:00')
const RANGE: [Dayjs, Dayjs] = [dayjs('2026-03-09'), dayjs('2026-03-18')]

// Presets stay relative to the moment they're clicked — only the labels are drawn.
const presets: DatePickerProps['presets'] = [
  { label: 'Yesterday', value: () => dayjs().subtract(1, 'day') },
  { label: 'Last week', value: () => dayjs().subtract(1, 'week') },
  { label: 'Last month', value: () => dayjs().subtract(1, 'month') },
]
const rangePresets: RangePickerProps['presets'] = [
  { label: 'Last 7 days', value: () => [dayjs().subtract(7, 'day'), dayjs()] },
  { label: 'Last 14 days', value: () => [dayjs().subtract(14, 'day'), dayjs()] },
  { label: 'Last 30 days', value: () => [dayjs().subtract(30, 'day'), dayjs()] },
  { label: 'Last 90 days', value: () => [dayjs().subtract(90, 'day'), dayjs()] },
]

const VARIANTS = ['outlined', 'filled', 'borderless', 'underlined'] as const
const SIZES = [
  { size: 'small', label: 'Small' },
  { size: 'middle', label: 'Default' },
  { size: 'large', label: 'Large' },
] as const
const title = (s: string) => s[0].toUpperCase() + s.slice(1)

/** Secondary 12px caption naming the Figma variant an example stands for. */
function Caption({ children, width }: { children: ReactNode; width?: number }) {
  const { token } = theme.useToken()
  return (
    <Typography.Text type="secondary" style={{ fontSize: token.fontSizeSM, width, flexShrink: 0 }}>
      {children}
    </Typography.Text>
  )
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Flex gap={16} align="center" wrap>
      <Caption width={96}>{label}</Caption>
      {children}
    </Flex>
  )
}

/**
 * Panels shown open for display portal into this box instead of
 * `document.body` (see `inFrame`), and the box reserves room for them — so
 * neighbouring examples never overlap and the Docs page scrolls them with
 * their field.
 */
function PopupFrame({ label, width, height = 400, children }: { label: string; width: number; height?: number; children: ReactNode }) {
  return (
    <Flex vertical gap={4} style={{ width }}>
      <Caption>{label}</Caption>
      <div data-popup-frame="" style={{ position: 'relative', height }}>
        {children}
      </div>
    </Flex>
  )
}
const inFrame = (node: HTMLElement) => node.closest<HTMLElement>('[data-popup-frame]') ?? document.body
/** Pins the placement: by default the panel flips when it would leave the viewport mid-scroll. */
const pinned = { overflow: { adjustX: false, adjustY: false } }

export const Default: Story = { args: { placeholder: 'Select date' } }
export const Range: Story = { render: () => <RangePicker /> }
export const Month: Story = { args: { picker: 'month', placeholder: 'Select month' } }
export const Disabled: Story = { args: { disabled: true } }
export const Invalid: Story = { args: { status: 'error', placeholder: 'Select date' } }

/** Figma menu `Type[Day|Date and Time|Month|Year]` × `Range`, closed and interactive. */
export const PickerTypes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      <Row label="Day">
        <DatePicker />
        <RangePicker />
      </Row>
      <Row label="Date and Time">
        <DatePicker showTime />
        <RangePicker showTime />
      </Row>
      <Row label="Month">
        <DatePicker picker="month" />
        <RangePicker picker="month" />
      </Row>
      <Row label="Year">
        <DatePicker picker="year" />
        <RangePicker picker="year" />
      </Row>
    </Flex>
  ),
}

/** Figma `Size[Small|Default|Large]`, single and range. `middle` is antd's name for the 32px default. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {SIZES.map(({ size, label }) => (
        <Row key={size} label={label}>
          <DatePicker size={size} />
          <RangePicker size={size} />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma's four input sets — Outlined / Filled / Borderless / Underlined — single and range. */
export const Variants: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {VARIANTS.map((variant) => (
        <Row key={variant} label={title(variant)}>
          <DatePicker variant={variant} />
          <RangePicker variant={variant} />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma `Status[Warning|Error]` on every input set, single and range. */
export const Status: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {VARIANTS.map((variant) => (
        <Row key={variant} label={title(variant)}>
          <DatePicker variant={variant} status="error" placeholder="Error" />
          <DatePicker variant={variant} status="warning" placeholder="Warning" />
          <RangePicker variant={variant} status="error" />
          <RangePicker variant={variant} status="warning" />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma `Multiple`: several separate dates in one field, each shown as a tag. */
export const Multiple: Story = {
  render: () => (
    <DatePicker multiple maxTagCount="responsive" defaultValue={[dayjs('2026-03-09'), DAY, dayjs('2026-03-18')]} style={{ width: 320 }} />
  ),
}

/** Figma's prefix slot: an icon or a short text label inside the field, before the value. */
export const WithPrefix: Story = {
  render: () => (
    <Flex gap={16} wrap>
      <DatePicker prefix={<Bell01 />} placeholder="Reminder date" />
      <RangePicker prefix="Period" />
    </Flex>
  ),
}

/** Figma "open" example for each menu `Type`, rendered statically open on a fixed month. */
export const Open: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Type: Day" width={296}>
        <DatePicker open popupAlign={pinned} getPopupContainer={inFrame} defaultValue={DAY} />
      </PopupFrame>
      <PopupFrame label="Type: Date and Time" width={480}>
        <DatePicker open showTime popupAlign={pinned} getPopupContainer={inFrame} defaultValue={DAY_TIME} />
      </PopupFrame>
      <PopupFrame label="Type: Month" width={296}>
        <DatePicker open picker="month" popupAlign={pinned} getPopupContainer={inFrame} defaultValue={DAY} />
      </PopupFrame>
      <PopupFrame label="Type: Year" width={296}>
        <DatePicker open picker="year" popupAlign={pinned} getPopupContainer={inFrame} defaultValue={DAY} />
      </PopupFrame>
    </Flex>
  ),
}

/** Figma menu `Range: True`, rendered statically open: two months side by side. */
export const OpenRange: Story = {
  render: () => (
    <PopupFrame label="Type: Day, Range" width={600}>
      <RangePicker open popupAlign={pinned} getPopupContainer={inFrame} defaultValue={RANGE} />
    </PopupFrame>
  ),
}

/** Figma menu `Preset: True`: shortcut values listed beside the panel, single and range, statically open. */
export const Presets: Story = {
  render: () => (
    <Flex vertical gap={24}>
      <PopupFrame label="Preset, single" width={420}>
        <DatePicker open presets={presets} popupAlign={pinned} getPopupContainer={inFrame} defaultValue={DAY} />
      </PopupFrame>
      <PopupFrame label="Preset, range" width={720}>
        <RangePicker open presets={rangePresets} popupAlign={pinned} getPopupContainer={inFrame} defaultValue={RANGE} />
      </PopupFrame>
    </Flex>
  ),
}
