import type { Meta, StoryObj } from '@storybook/react-vite'
import { Badge, Descriptions, Typography } from 'antd'
import type { DescriptionsProps } from 'antd'

const meta: Meta<typeof Descriptions> = {
  component: Descriptions,
  title: 'Components/Descriptions',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's descriptions/index.d.ts — written from the API.
  argTypes: {
    title: { description: 'Title shown above the list.', control: 'text' },
    bordered: { description: 'Draws borders around each label/value cell.', control: 'boolean' },
    column: { description: 'Number of label/value pairs per row.', control: 'number' },
    layout: { description: 'Label position relative to its value.', control: 'select', options: ['horizontal', 'vertical'] },
    // antd 6 deprecates `default` in favour of `medium` (Figma `Size: Medium`).
    size: { description: 'Cell padding density — Figma `Size: Large | Medium | Small`.', control: 'select', options: ['large', 'medium', 'small'] },
  },
}
export default meta
type Story = StoryObj<typeof Descriptions>

const items = [
  { key: '1', label: 'UserName', children: 'John Brown' },
  { key: '2', label: 'Telephone', children: '555-0100' },
  { key: '3', label: 'Live', children: 'New York' },
  { key: '4', label: 'Address', children: 'No. 1 Lake Park' },
]

/**
 * The Figma bordered example's items: plain label/content cells plus one
 * status cell. The status is a `Badge`, so its dot uses the semantic
 * `processing` colour rather than a hand-picked one.
 */
const borderedItems: DescriptionsProps['items'] = [
  { key: 'product', label: 'Product', children: 'Cloud Database' },
  { key: 'billing', label: 'Billing Mode', children: 'Prepaid' },
  { key: 'renewal', label: 'Automatic Renewal', children: 'YES' },
  { key: 'order', label: 'Order time', children: '2018-04-24 18:00:00' },
  { key: 'usage', label: 'Usage Time', span: 2, children: '2019-04-24 18:00:00' },
  { key: 'status', label: 'Status', span: 3, children: <Badge status="processing" text="Running" /> },
  { key: 'negotiated', label: 'Negotiated Amount', children: '$80.00' },
  { key: 'discount', label: 'Discount', children: '$20.00' },
  { key: 'official', label: 'Official Receipts', children: '$60.00' },
]

/** Figma "basic" example — no borders. */
export const Default: Story = { args: { title: 'User Info', items } }
export const Bordered: Story = { args: { title: 'User Info', bordered: true, items, column: 2 } }
export const Vertical: Story = { args: { layout: 'vertical', bordered: true, items, column: 2 } }

/** Figma `Size: Large | Medium | Small`, bordered — the three bordered docs examples. */
export const BorderedSizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
      {(['large', 'medium', 'small'] as const).map((size) => (
        <div key={size}>
          <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
            Size: {size}
          </Typography.Text>
          <Descriptions title="User Info" bordered size={size} items={borderedItems} />
        </div>
      ))}
    </div>
  ),
}

/** Figma bordered item with status content — a `Badge` inside the value cell. */
export const WithStatus: Story = {
  args: { title: 'User Info', bordered: true, items: borderedItems },
}
