import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Button, Drawer, Form, Input, Radio, Space, Typography, theme } from 'antd'
import type { DrawerProps } from 'antd'

const meta: Meta<typeof Drawer> = {
  component: Drawer,
  title: 'Components/Drawer',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's drawer types — written from the API.
  argTypes: {
    open: { description: 'Whether the drawer is visible.', control: 'boolean' },
    title: { description: 'Header title.', control: 'text' },
    placement: { description: 'Edge the drawer slides in from.', control: 'select', options: ['right', 'top', 'bottom', 'left'] },
    size: { description: "Width (left/right) or height (top/bottom): 'default', 'large', or a number.", control: 'number' },
    closable: { description: 'Whether the header shows a close button.', control: 'boolean' },
    extra: { description: 'Actions rendered on the right of the header.', control: false },
    footer: { description: 'Content pinned to the bottom of the drawer (e.g. action buttons).', control: false },
    getContainer: { description: 'Where the drawer mounts. `false` renders it inline inside its parent.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Drawer>

/**
 * Every open drawer here is rendered with `getContainer={false}`, which makes
 * antd position it (and its mask) absolutely inside the nearest positioned
 * ancestor instead of fixed to the viewport — so several drawers can sit on
 * one Docs page without covering it.
 */
function Stage({ height = 420, children }: { height?: number; children: React.ReactNode }) {
  const { token } = theme.useToken()
  return (
    <div
      style={{
        position: 'relative',
        height,
        overflow: 'hidden',
        isolation: 'isolate',
        border: `${token.lineWidth}px ${token.lineType} ${token.colorBorderSecondary}`,
        borderRadius: token.borderRadiusLG,
      }}
    >
      {children}
    </div>
  )
}

/**
 * The Form.Item has no `name`, so its label isn't tied to the input by id —
 * `aria-label` repeats it (an id would clash, several drawers share this body).
 */
const body = (
  <Form layout="vertical">
    <Form.Item label="Name">
      <Input aria-label="Name" placeholder="Please input" />
    </Form.Item>
  </Form>
)

export const Open: Story = {
  args: {
    open: true,
    title: 'Basic Drawer',
    placement: 'right',
    getContainer: false,
    size: 320,
    children: (
      <Form layout="vertical">
        <Form.Item label="Name">
          <Input aria-label="Name" />
        </Form.Item>
      </Form>
    ),
  },
  decorators: [
    (Story) => (
      <div style={{ position: 'relative', height: 420, overflow: 'hidden' }}>
        <Story />
      </div>
    ),
  ],
}

/**
 * Figma's four examples — `Placement` Right / Top / Bottom / Left. `size` is
 * the width for left/right and the height for top/bottom.
 */
export const Placements: Story = {
  render: () => {
    const placements: { placement: NonNullable<DrawerProps['placement']>; size: number }[] = [
      { placement: 'right', size: 280 },
      { placement: 'top', size: 160 },
      { placement: 'bottom', size: 160 },
      { placement: 'left', size: 280 },
    ]
    return (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: 16 }}>
        {placements.map(({ placement, size }) => (
          <Stage key={placement} height={360}>
            <Drawer open getContainer={false} placement={placement} size={size} title={`Drawer ${placement}`}>
              <Typography.Text>Some contents...</Typography.Text>
            </Drawer>
          </Stage>
        ))}
      </div>
    )
  },
}

/**
 * Figma's `Button Outline?` + `Button Primary?` toggles: a default and a
 * primary button in the header's `extra` slot, next to the title — antd's own
 * "Extra actions" pattern. The drawer is its own surface, so its one primary
 * action lives here.
 */
export const ExtraActions: Story = {
  render: () => (
    <Stage>
      <Drawer
        open
        getContainer={false}
        size={360}
        title="Create a new account"
        extra={
          <Space size={8}>
            <Button>Cancel</Button>
            <Button type="primary">OK</Button>
          </Space>
        }
      >
        {body}
      </Drawer>
    </Stage>
  ),
}

/**
 * Figma's `Footer?` toggle: the same actions pinned to the bottom of the
 * drawer instead of the header. `footer` is a free slot — alignment is up to
 * the content.
 */
export const WithFooter: Story = {
  render: () => (
    <Stage>
      <Drawer
        open
        getContainer={false}
        size={360}
        title="Create a new account"
        footer={
          <Space size={8} style={{ width: '100%', justifyContent: 'flex-end' }}>
            <Button>Cancel</Button>
            <Button type="primary">Submit</Button>
          </Space>
        }
      >
        {body}
      </Drawer>
    </Stage>
  ),
}

/** Figma's `Close Icon?` = false: `closable={false}` drops the header close button. */
export const WithoutCloseIcon: Story = {
  render: () => (
    <Stage height={320}>
      <Drawer open getContainer={false} size={320} title="Basic Drawer" closable={false}>
        <Typography.Text>Some contents...</Typography.Text>
      </Drawer>
    </Stage>
  ),
}

/** Interactive: pick a placement, then open a real (viewport-fixed) drawer. */
function InteractiveDemo() {
  const [open, setOpen] = useState(false)
  const [placement, setPlacement] = useState<NonNullable<DrawerProps['placement']>>('right')
  return (
    <>
      <Space size={16}>
        <Radio.Group value={placement} onChange={(e) => setPlacement(e.target.value)}>
          <Radio value="top">top</Radio>
          <Radio value="right">right</Radio>
          <Radio value="bottom">bottom</Radio>
          <Radio value="left">left</Radio>
        </Radio.Group>
        <Button type="primary" onClick={() => setOpen(true)}>
          Open
        </Button>
      </Space>
      <Drawer
        open={open}
        placement={placement}
        title="Basic Drawer"
        onClose={() => setOpen(false)}
        footer={
          <Space size={8} style={{ width: '100%', justifyContent: 'flex-end' }}>
            <Button onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="primary" onClick={() => setOpen(false)}>
              Submit
            </Button>
          </Space>
        }
      >
        {body}
      </Drawer>
    </>
  )
}

export const Interactive: Story = {
  render: () => <InteractiveDemo />,
}
