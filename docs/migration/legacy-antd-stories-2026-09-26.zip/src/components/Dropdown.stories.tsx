import type { Meta, StoryObj } from '@storybook/react-vite'
import { cloneElement, type CSSProperties, type ReactElement, type ReactNode } from 'react'
import { Dropdown, Button, Divider, Space, theme } from 'antd'
import type { DropdownProps, MenuProps } from 'antd'
import { ChevronDown, DotsHorizontal, Edit01, Eye, Plus, Printer, Share01, Trash01 } from '../icons'

const meta: Meta<typeof Dropdown> = {
  component: Dropdown,
  title: 'Components/Dropdown',
  tags: ['ai-generated', 'needs-work'],
  // `Default` spreads these args onto its Dropdown, so the Controls panel is
  // live there. No JSDoc on these in antd's dropdown.d.ts — written from the API.
  args: { placement: 'bottomLeft', arrow: false, trigger: ['hover'] },
  argTypes: {
    menu: { description: 'Menu rendered in the popup — the same `items` API as Menu.', control: false },
    placement: {
      description: 'Where the popup opens relative to the trigger.',
      control: 'select',
      options: ['bottomLeft', 'bottom', 'bottomRight', 'topLeft', 'top', 'topRight'],
    },
    arrow: { description: 'Draws an arrow pointing from the popup to the trigger.', control: 'boolean' },
    trigger: { description: 'Which interactions open the popup.', control: 'check', options: ['hover', 'click', 'contextMenu'] },
    open: { description: 'Controlled open state.', control: 'boolean' },
    disabled: { description: 'Prevents the popup from opening.', control: 'boolean' },
    popupRender: { description: 'Wraps the menu so extra content (e.g. a footer button) can sit alongside it.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Dropdown>

const items: MenuProps['items'] = [
  { key: 'view', icon: <Eye />, label: 'View' },
  { key: 'edit', icon: <Edit01 />, label: 'Edit' },
  { type: 'divider' },
  { key: 'delete', icon: <Trash01 />, label: 'Delete', danger: true },
]

type Placement = NonNullable<DropdownProps['placement']>
// Figma's six `Placement` values (`Bottom`/`Top` are antd's `bottom`/`top`).
const PLACEMENTS: Placement[] = ['topLeft', 'top', 'topRight', 'bottomLeft', 'bottom', 'bottomRight']

/**
 * Statically-open galleries render each popup into its own grid cell rather
 * than `document.body`, so it moves with the story when the Docs page
 * reflows instead of staying where it was first measured.
 */
const inCell = (trigger: HTMLElement) => trigger.closest<HTMLElement>('[data-popup-cell]') ?? document.body

/** Parks the trigger on the side opposite the popup, so every popup opens into its own cell. */
function cellStyle(placement: Placement | 'closed'): CSSProperties {
  return {
    position: 'relative',
    display: 'flex',
    height: 200,
    alignItems: placement === 'closed' ? 'center' : placement.startsWith('top') ? 'flex-end' : 'flex-start',
    justifyContent: placement.endsWith('Left') ? 'flex-start' : placement.endsWith('Right') ? 'flex-end' : 'center',
  }
}

function PlacementGrid<T extends Placement | 'closed'>({ cells, render }: { cells: T[]; render: (p: T) => ReactNode }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(200px, 1fr))', gap: 24, maxWidth: 760 }}>
      {cells.map((p) => (
        <div key={p} data-popup-cell style={cellStyle(p)}>
          {render(p)}
        </div>
      ))}
    </div>
  )
}

/** Figma `Type=Button Basic`, `Open Menu=No` — hover to open. Controls are live here. */
export const Default: Story = {
  render: (args) => (
    <div style={{ minHeight: 200 }}>
      <Dropdown {...args} menu={{ items }}>
        <Button>
          <Space>Hover me<ChevronDown /></Space>
        </Button>
      </Dropdown>
    </div>
  ),
}

export const OpenByDefault: Story = {
  render: () => (
    <div data-popup-cell style={{ position: 'relative', height: 200 }}>
      <Dropdown menu={{ items }} open getPopupContainer={inCell}>
        <Button>Actions</Button>
      </Dropdown>
    </div>
  ),
}

/** Figma `Type=Basic Inline`, `Open Menu=No`: a text trigger instead of a button — hover to open. */
export const BasicInline: Story = {
  render: () => (
    <div style={{ minHeight: 200 }}>
      <Dropdown menu={{ items }}>
        <a href="#" onClick={(e) => e.preventDefault()}>
          <Space size={4}>Hover me<ChevronDown /></Space>
        </a>
      </Dropdown>
    </div>
  ),
}

/**
 * Figma `Type=Basic Inline`, `Open Menu=Yes` at all six placements, held open.
 * `autoAdjustOverflow={false}` stops antd flipping a popup that nears the
 * canvas edge, so each one shows exactly the placement it is labelled with.
 */
export const InlinePlacements: Story = {
  render: () => (
    <PlacementGrid
      cells={PLACEMENTS}
      render={(p) => (
        <Dropdown menu={{ items }} placement={p} open autoAdjustOverflow={false} getPopupContainer={inCell}>
          <a href="#" onClick={(e) => e.preventDefault()}>
            <Space size={4}>{p}<ChevronDown /></Space>
          </a>
        </Dropdown>
      )}
    />
  ),
}

/** Figma `Type=Button Basic`, `Open Menu=Yes` at all six placements, held open. */
export const ButtonPlacements: Story = {
  render: () => (
    <PlacementGrid
      cells={PLACEMENTS}
      render={(p) => (
        <Dropdown menu={{ items }} placement={p} open autoAdjustOverflow={false} getPopupContainer={inCell}>
          <Button>
            <Space>{p}<ChevronDown /></Space>
          </Button>
        </Dropdown>
      )}
    />
  ),
}

/**
 * Figma `Type=Button Twofold`: closed, then open at `Bottom Right` and
 * `Top Left`. `Dropdown.Button` is deprecated in antd v6 — its replacement is
 * `Space.Compact` + `Button` + a `Dropdown` around the icon button, which is
 * what this renders. The icon is antd's own default for the split button
 * (ellipsis), drawn with Untitled UI's `DotsHorizontal`.
 */
export const SplitButton: Story = {
  render: () => (
    <PlacementGrid
      cells={['closed', 'bottomRight', 'topLeft']}
      render={(p) => (
        <Space.Compact>
          <Button>Dropdown</Button>
          {p === 'closed' ? (
            <Dropdown menu={{ items }} placement="bottomRight">
              <Button icon={<DotsHorizontal />} aria-label="More actions" />
            </Dropdown>
          ) : (
            <Dropdown menu={{ items }} placement={p} open autoAdjustOverflow={false} getPopupContainer={inCell}>
              <Button icon={<DotsHorizontal />} aria-label="More actions" />
            </Dropdown>
          )}
        </Space.Compact>
      )}
    />
  ),
}

/**
 * Figma `Dropdown Menu` item variants in one menu: group title, `Icon?`,
 * `Extra?` (right-aligned shortcut text), `State=Selected` (via
 * `selectable` + `defaultSelectedKeys`), `State=Disabled`, `Submenu?`
 * (hover "Share" to open it) and `Danger`. `State=Hover` is the live
 * mouse-over state.
 */
export const MenuItemStates: Story = {
  render: () => {
    const stateItems: MenuProps['items'] = [
      {
        type: 'group',
        label: 'Group title',
        children: [
          { key: 'view', icon: <Eye />, label: 'View', extra: 'Ctrl+V' },
          { key: 'edit', icon: <Edit01 />, label: 'Edit', extra: 'Ctrl+E' },
          { key: 'print', icon: <Printer />, label: 'Print', disabled: true },
        ],
      },
      { type: 'divider' },
      {
        key: 'share',
        icon: <Share01 />,
        label: 'Share',
        children: [
          { key: 'share-link', label: 'Copy link' },
          { key: 'share-mail', label: 'Send by email' },
        ],
      },
      { type: 'divider' },
      { key: 'delete', icon: <Trash01 />, label: 'Delete', danger: true },
    ]
    return (
      <div data-popup-cell style={{ position: 'relative', height: 300 }}>
        <Dropdown
          menu={{ items: stateItems, selectable: true, defaultSelectedKeys: ['edit'] }}
          open
          getPopupContainer={inCell}
        >
          <Button>
            <Space>Actions<ChevronDown /></Space>
          </Button>
        </Dropdown>
      </div>
    )
  },
}

/**
 * Figma `Dropdown Menu` `Arrow`: `arrow` draws a pointer from the menu to the
 * trigger, shown at the three bottom alignments. (`arrow={{ pointAtCenter: true }}`
 * would instead aim it at the trigger's centre.)
 */
export const WithArrow: Story = {
  render: () => (
    <PlacementGrid
      cells={['bottomLeft', 'bottom', 'bottomRight']}
      render={(p) => (
        <Dropdown menu={{ items }} placement={p} arrow open autoAdjustOverflow={false} getPopupContainer={inCell}>
          <Button>{p}</Button>
        </Dropdown>
      )}
    />
  ),
}

/**
 * Figma `Dropdown Menu` `Button?`: an action button under the menu items.
 * antd has no prop for it — `popupRender` wraps the menu, and the wrapper
 * takes over the elevated surface (background, radius, shadow) from the menu.
 */
function WithFooterButtonDemo() {
  const { token } = theme.useToken()
  return (
    <div data-popup-cell style={{ position: 'relative', height: 240 }}>
      <Dropdown
        menu={{ items }}
        open
        getPopupContainer={inCell}
        popupRender={(menu) => (
          <div style={{ background: token.colorBgElevated, borderRadius: token.borderRadiusLG, boxShadow: token.boxShadowSecondary }}>
            {cloneElement(menu as ReactElement<{ style?: CSSProperties }>, { style: { boxShadow: 'none' } })}
            <Divider style={{ margin: 0 }} />
            <div style={{ padding: token.paddingXS }}>
              <Button block icon={<Plus />}>Add action</Button>
            </div>
          </div>
        )}
      >
        <Button>
          <Space>Actions<ChevronDown /></Space>
        </Button>
      </Dropdown>
    </div>
  )
}

export const WithFooterButton: Story = {
  render: () => <WithFooterButtonDemo />,
}
