import type { Meta, StoryObj } from '@storybook/react-vite'
import { useContext } from 'react'
import { Empty, Button, ConfigProvider, Typography } from 'antd'

const meta: Meta<typeof Empty> = {
  component: Empty,
  title: 'Components/Empty',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's empty/index.d.ts — written from the API.
  argTypes: {
    description: { description: 'Text shown under the image.', control: 'text' },
    image: { description: 'The illustration — a URL, node, or one of Empty.PRESENTED_IMAGE_*.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Empty>

const Caption = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
    {children}
  </Typography.Text>
)

/** Figma `Empty / Image`, `Image: 1` — antd's default illustration (`PRESENTED_IMAGE_DEFAULT`). */
export const Default: Story = { args: { description: 'No data' } }

export const WithAction: Story = {
  args: {
    description: 'Try changing your filters or search terms',
    children: <Button type="primary">Clear search and filters</Button>,
  },
}

/** Figma `Empty / Image`, `Image: 2` — the flat, simple illustration (`PRESENTED_IMAGE_SIMPLE`). */
export const Simple: Story = { args: { image: Empty.PRESENTED_IMAGE_SIMPLE, description: 'No data' } }

/** The two Figma `Empty / Image` options next to each other. */
export const Images: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 48, flexWrap: 'wrap' }}>
      <div>
        <Caption>Image: 1</Caption>
        <Empty description="No data" />
      </div>
      <div>
        <Caption>Image: 2 (simple)</Caption>
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No data" />
      </div>
    </div>
  ),
}

/**
 * Figma `Empty`, `Size: MD | SM`. Empty has no `size` prop: antd renders MD
 * (the `-normal` class) for the simple image — what Table and List show —
 * and SM by adding `<prefix>-empty-small`, which is exactly what its own
 * default empty state does inside Select / TreeSelect / Cascader / Transfer /
 * Mentions dropdowns. The prefix is read from ConfigProvider, as antd does,
 * rather than hardcoding `ant-`.
 */
function SizesDemo() {
  const { getPrefixCls } = useContext(ConfigProvider.ConfigContext)
  return (
    <div style={{ display: 'flex', gap: 48, flexWrap: 'wrap', alignItems: 'flex-start' }}>
      <div>
        <Caption>Size: MD</Caption>
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No data" />
      </div>
      <div>
        <Caption>Size: SM</Caption>
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No data" className={`${getPrefixCls('empty')}-small`} />
      </div>
    </div>
  )
}

export const Sizes: Story = {
  render: () => <SizesDemo />,
}
