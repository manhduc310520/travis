import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Flex, FloatButton, Typography } from 'antd'
import type { FloatButtonGroupProps } from 'antd'
import { Edit01, HelpCircle, Menu02, Plus, Share01 } from '../icons'

const meta: Meta<typeof FloatButton> = {
  component: FloatButton,
  title: 'Components/FloatButton',
  tags: ['ai-generated', 'needs-work'],
  // Every story uses a custom `render`, none set `args` — the Docs page's
  // argTypes table only renders once at least one arg exists.
  args: { type: 'default' },
  // No JSDoc found on these in antd's float-button types — written from the API.
  argTypes: {
    type: { description: 'Visual style of the button.', control: 'select', options: ['default', 'primary'] },
    icon: { description: 'Icon shown inside the button.', control: false },
    shape: { description: 'Outline of the button.', control: 'select', options: ['circle', 'square'] },
    content: { description: 'Short text under the icon (formerly `description`); best on the square shape.', control: 'text' },
    tooltip: { description: 'Tooltip text, or full Tooltip props.', control: 'text' },
    badge: { description: 'Badge in the top-right corner, e.g. { dot: true } or { count: 5 }.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof FloatButton>

/**
 * A FloatButton (and FloatButton.Group) is `position: fixed` to the viewport's
 * bottom-right corner by default. Resetting it to `relative` with
 * `inset: auto` drops it back into normal flow, so the gallery stories below
 * can lay several out side by side.
 */
const INLINE: React.CSSProperties = { position: 'relative', inset: 'auto' }

/** Small caption naming the Figma variant each example shows. */
const Label = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ fontSize: 12 }}>
    {children}
  </Typography.Text>
)

/** One gallery cell: the Figma variant name above the rendered example. */
const Cell = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <Flex vertical gap={8} align="flex-start">
    <Label>{label}</Label>
    {children}
  </Flex>
)

/** Icon-only, like most examples below — with no text to read, each button carries an `aria-label`. */
export const Default: Story = {
  render: () => (
    <div style={{ height: 240, position: 'relative' }}>
      <FloatButton aria-label="Help" icon={<HelpCircle />} style={{ position: 'absolute', right: 24, bottom: 24 }} />
    </div>
  ),
}

export const PrimaryType: Story = {
  render: () => (
    <div style={{ height: 240, position: 'relative' }}>
      <FloatButton type="primary" aria-label="Add" icon={<Plus />} style={{ position: 'absolute', right: 24, bottom: 24 }} />
    </div>
  ),
}

/** Figma `Type` = Default / Primary × `Shape` = Square / Circle. */
export const TypesAndShapes: Story = {
  render: () => (
    <Flex gap={32} wrap>
      <Cell label="Default · Square">
        <FloatButton shape="square" aria-label="Help" icon={<HelpCircle />} style={INLINE} />
      </Cell>
      <Cell label="Default · Circle">
        <FloatButton shape="circle" aria-label="Help" icon={<HelpCircle />} style={INLINE} />
      </Cell>
      <Cell label="Primary · Square">
        <FloatButton type="primary" shape="square" aria-label="Add" icon={<Plus />} style={INLINE} />
      </Cell>
      <Cell label="Primary · Circle">
        <FloatButton type="primary" shape="circle" aria-label="Add" icon={<Plus />} style={INLINE} />
      </Cell>
    </Flex>
  ),
}

/**
 * Figma `Badge` = Dot / Small on each type and shape — the "(+Badge)"
 * examples. Small is a count badge at `size: 'small'`.
 */
export const Badges: Story = {
  render: () => (
    <Flex vertical gap={24}>
      {(['default', 'primary'] as const).map((type) => (
        <Flex key={type} gap={32} wrap>
          {(['square', 'circle'] as const).map((shape) => (
            <Flex key={shape} gap={32}>
              <Cell label={`${type} · ${shape} · Dot`}>
                <FloatButton type={type} shape={shape} aria-label="Help" icon={<HelpCircle />} badge={{ dot: true }} style={INLINE} />
              </Cell>
              <Cell label={`${type} · ${shape} · Small`}>
                <FloatButton type={type} shape={shape} aria-label="Help (5)" icon={<HelpCircle />} badge={{ count: 5, size: 'small' }} style={INLINE} />
              </Cell>
            </Flex>
          ))}
        </Flex>
      ))}
    </Flex>
  ),
}

/**
 * Figma `Description?` + `Icon?`: `content` adds a short label under the
 * icon (antd 6 renamed `description` to `content`). It fits the square shape;
 * without an icon the label stands alone.
 */
export const WithDescription: Story = {
  render: () => (
    <Flex gap={32} wrap>
      <Cell label="Icon + description">
        <FloatButton shape="square" icon={<HelpCircle />} content="HELP" style={INLINE} />
      </Cell>
      <Cell label="Description only">
        <FloatButton shape="square" content="HELP" style={INLINE} />
      </Cell>
      <Cell label="Primary · Icon + description">
        <FloatButton type="primary" shape="square" icon={<Plus />} content="ADD" style={INLINE} />
      </Cell>
    </Flex>
  ),
}

/**
 * Figma `Tooltip?`: `tooltip` takes a string or full Tooltip props. The first
 * shows on hover; the second is pinned open to show the Figma variant.
 */
export const WithTooltip: Story = {
  render: () => (
    <Flex gap={96} wrap style={{ paddingInlineStart: 96, paddingBlock: 16 }}>
      <Cell label="Hover">
        <FloatButton aria-label="Help info" icon={<HelpCircle />} tooltip="Help info" style={INLINE} />
      </Cell>
      <Cell label="Open">
        <FloatButton aria-label="Help info" icon={<HelpCircle />} tooltip={{ title: 'Help info', open: true }} style={INLINE} />
      </Cell>
    </Flex>
  ),
}

/**
 * Figma `FloatButton Group` Type = Square / Circle × Direction = Vertical /
 * Horizontal. A square group joins its buttons into one bar; a circle group
 * spaces them apart. antd lays the list out along `placement` even outside
 * menu mode: top/bottom stack vertically, left/right run horizontally.
 */
export const Group: Story = {
  render: () => (
    <Flex gap={48} wrap align="flex-start">
      <Cell label="Square · Vertical">
        <FloatButton.Group shape="square" style={INLINE}>
          <FloatButton aria-label="Help" icon={<HelpCircle />} />
          <FloatButton aria-label="Edit" icon={<Edit01 />} />
          <FloatButton aria-label="Share" icon={<Share01 />} />
        </FloatButton.Group>
      </Cell>
      <Cell label="Circle · Vertical">
        <FloatButton.Group shape="circle" style={INLINE}>
          <FloatButton aria-label="Help" icon={<HelpCircle />} />
          <FloatButton aria-label="Edit" icon={<Edit01 />} />
          <FloatButton aria-label="Share" icon={<Share01 />} />
        </FloatButton.Group>
      </Cell>
      <Cell label="Square · Horizontal">
        <FloatButton.Group shape="square" placement="right" style={INLINE}>
          <FloatButton aria-label="Help" icon={<HelpCircle />} />
          <FloatButton aria-label="Edit" icon={<Edit01 />} />
          <FloatButton aria-label="Share" icon={<Share01 />} />
        </FloatButton.Group>
      </Cell>
      <Cell label="Circle · Horizontal">
        <FloatButton.Group shape="circle" placement="right" style={INLINE}>
          <FloatButton aria-label="Help" icon={<HelpCircle />} />
          <FloatButton aria-label="Edit" icon={<Edit01 />} />
          <FloatButton aria-label="Share" icon={<Share01 />} />
        </FloatButton.Group>
      </Cell>
    </Flex>
  ),
}

/**
 * Figma `FloatButton Menu` Open = Yes/No × Placement: a `trigger="click"`
 * group whose trigger expands the list. Controlled `open` so the Figma "open
 * top" and "open right" examples render expanded; click a trigger to toggle.
 * When open, the trigger swaps to the close icon from the global icon config,
 * so its `aria-label` follows the same state.
 */
function MenuExample({ placement, defaultOpen }: { placement: NonNullable<FloatButtonGroupProps['placement']>; defaultOpen: boolean }) {
  const [open, setOpen] = useState(defaultOpen)
  const vertical = placement === 'top' || placement === 'bottom'
  return (
    <Flex
      align={placement === 'bottom' ? 'flex-start' : 'flex-end'}
      style={{ width: vertical ? 64 : 240, height: vertical ? 220 : 64 }}
    >
      <FloatButton.Group
        trigger="click"
        type="primary"
        placement={placement}
        open={open}
        onOpenChange={setOpen}
        aria-label={open ? 'Close menu' : 'Open menu'}
        icon={<Menu02 />}
        style={INLINE}
      >
        <FloatButton aria-label="Help" icon={<HelpCircle />} />
        <FloatButton aria-label="Edit" icon={<Edit01 />} />
        <FloatButton aria-label="Share" icon={<Share01 />} />
      </FloatButton.Group>
    </Flex>
  )
}

export const Menu: Story = {
  render: () => (
    <Flex gap={48} wrap align="flex-end">
      <Cell label="Closed">
        <MenuExample placement="top" defaultOpen={false} />
      </Cell>
      <Cell label="Open · Top">
        <MenuExample placement="top" defaultOpen />
      </Cell>
      <Cell label="Open · Right">
        <MenuExample placement="right" defaultOpen />
      </Cell>
    </Flex>
  ),
}
