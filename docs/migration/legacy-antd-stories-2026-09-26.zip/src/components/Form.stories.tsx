import { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react-vite'
import { expect } from 'storybook/test'
import {
  Form, Input, InputNumber, Select, Button, Switch, Checkbox, Radio, Segmented, Tag,
  DatePicker, TimePicker, Slider, Rate, Upload, TreeSelect, Space, Flex,
} from 'antd'
import type { FormProps, UploadFile } from 'antd'
import { HelpCircle, InfoCircle, Plus, UploadCloud01, User01 } from '../icons'

const meta: Meta<typeof Form> = {
  component: Form,
  title: 'Components/Form',
  tags: ['ai-generated', 'needs-work'],
  // Every story uses a custom `render` and none set `args` — the Docs
  // page's argTypes table only renders once at least one arg exists.
  args: { layout: 'vertical' },
  // No JSDoc on `layout` in antd's form/Form.d.ts. Field-level props
  // (`rules`, `validateStatus`, `help`) belong to `Form.Item`, a different
  // component from the one documented here, so they aren't listed as
  // argTypes on this meta.
  argTypes: {
    layout: {
      description: 'Position of labels relative to their fields.',
      control: 'select',
      options: ['horizontal', 'vertical', 'inline'],
    },
  },
}
export default meta
type Story = StoryObj<typeof Form>

/**
 * The Name / Select / Switch / Submit set every plain-vertical-form story
 * below shares — `Vertical`, `Disabled` and `Size` all render the exact same
 * fields, only the surrounding `Form` props change, so this is the one place
 * that set is defined rather than three copies of it drifting apart.
 */
function DemoFields() {
  return (
    <>
      <Form.Item label="Name" name="name" rules={[{ required: true }]}>
        <Input placeholder="Please input" />
      </Form.Item>
      <Form.Item label="Select" name="select">
        <Select placeholder="Please select" options={[{ value: 'option-1', label: 'Option 1' }, { value: 'option-2', label: 'Option 2' }]} />
      </Form.Item>
      <Form.Item label="Switch" name="switch" valuePropName="checked">
        <Switch defaultChecked />
      </Form.Item>
      <Button type="primary">Submit</Button>
    </>
  )
}
DemoFields.displayName = 'DemoFields'

export const Vertical: Story = {
  render: () => (
    <Form layout="vertical" style={{ maxWidth: 420 }}>
      <DemoFields />
    </Form>
  ),
  parameters: { docs: { source: { code: '() => (\n  <Form layout="vertical">\n    <DemoFields />\n  </Form>\n)' } } },
  play: async ({ canvas }) => {
    await expect(canvas.getByLabelText('Name')).toBeVisible()
  },
}

/**
 * Adapted from antd's own `disabled.tsx` demo — trimmed from its full
 * kitchen-sink control list down to `DemoFields`, since the point here is
 * the `disabled` prop cascading to every field at once, not re-demonstrating
 * every control type Form can wrap.
 */
function DisabledDemo() {
  const [disabled, setDisabled] = useState(true)
  return (
    <>
      <Checkbox checked={disabled} onChange={(e) => setDisabled(e.target.checked)} style={{ marginBottom: 16 }}>
        Form disabled
      </Checkbox>
      <Form layout="vertical" disabled={disabled} style={{ maxWidth: 420 }}>
        <DemoFields />
      </Form>
    </>
  )
}
DisabledDemo.displayName = 'DisabledDemo'

export const Disabled: Story = {
  render: () => <DisabledDemo />,
  parameters: { docs: { source: { code: '() => <DisabledDemo />' } } },
}

/**
 * Adapted from antd's `variant.tsx` demo — `Form`'s own `variant` prop
 * cascades to every field inside it, so switching the Segmented control
 * re-themes the whole form at once. Trimmed the field list to Input /
 * InputNumber / Select, enough to show the variant applies across control
 * types without repeating every one Form supports.
 */
function VariantsDemo() {
  const [form] = Form.useForm()
  const variant = Form.useWatch('variant', form)
  return (
    <Form form={form} layout="vertical" variant={variant || 'outlined'} initialValues={{ variant: 'outlined' }} style={{ maxWidth: 420 }}>
      <Form.Item label="Form variant" name="variant">
        <Segmented options={['outlined', 'filled', 'borderless', 'underlined']} />
      </Form.Item>
      <Form.Item label="Input" name="input">
        <Input placeholder="Please input" />
      </Form.Item>
      <Form.Item label="InputNumber" name="inputNumber">
        <InputNumber style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="Select" name="select">
        <Select placeholder="Please select" options={[{ value: 'option-1', label: 'Option 1' }, { value: 'option-2', label: 'Option 2' }]} />
      </Form.Item>
      <Button type="primary">Submit</Button>
    </Form>
  )
}
VariantsDemo.displayName = 'VariantsDemo'

export const Variants: Story = {
  render: () => <VariantsDemo />,
  parameters: { docs: { source: { code: '() => <VariantsDemo />' } } },
}

/**
 * Adapted from antd's `required-mark.tsx` demo. `requiredMark` defaults to
 * `true` — a red asterisk *before* the label — which is already the
 * behavior every other story here relies on; this just makes the other two
 * built-in options (and a fully custom render) visible and switchable.
 * Swapped the demo's own `InfoCircleOutlined` (from `@ant-design/icons`,
 * a package this project doesn't depend on — see `src/icons.tsx`'s own
 * header comment) for this project's `InfoCircle`.
 */
type RequiredMarkValue = boolean | 'optional' | 'customize'

const customizeRequiredMark = (label: React.ReactNode, { required }: { required: boolean }) => (
  <>
    {required ? <Tag color="error">Required</Tag> : <Tag color="warning">Optional</Tag>}
    {label}
  </>
)

function RequiredMarkDemo() {
  const [form] = Form.useForm()
  const [requiredMark, setRequiredMark] = useState<RequiredMarkValue>(true)

  const onValuesChange: FormProps<any>['onValuesChange'] = ({ requiredMarkValue }) => {
    setRequiredMark(requiredMarkValue)
  }

  return (
    <Form
      form={form}
      layout="vertical"
      initialValues={{ requiredMarkValue: requiredMark }}
      onValuesChange={onValuesChange}
      requiredMark={requiredMark === 'customize' ? customizeRequiredMark : requiredMark}
      style={{ maxWidth: 420 }}
    >
      <Form.Item label="Required Mark" name="requiredMarkValue">
        <Radio.Group>
          <Radio.Button value>Default</Radio.Button>
          <Radio.Button value="optional">Optional</Radio.Button>
          <Radio.Button value={false}>Hidden</Radio.Button>
          <Radio.Button value="customize">Customize</Radio.Button>
        </Radio.Group>
      </Form.Item>
      <Form.Item label="Field A" required tooltip="This is a required field">
        <Input placeholder="Please input" />
      </Form.Item>
      <Form.Item label="Field B" tooltip={{ title: 'Tooltip with a custom icon', icon: <InfoCircle size={14} /> }}>
        <Input placeholder="Please input" />
      </Form.Item>
      <Button type="primary">Submit</Button>
    </Form>
  )
}
RequiredMarkDemo.displayName = 'RequiredMarkDemo'

export const RequiredMark: Story = {
  render: () => <RequiredMarkDemo />,
  parameters: { docs: { source: { code: '() => <RequiredMarkDemo />' } } },
}

/**
 * Adapted from antd's `size.tsx` demo. Note `medium`, not `middle` — this
 * project is on Ant Design v6, where `middle` is deprecated in favor of
 * `medium` (verified against `SizeContext.d.ts`, not guessed).
 */
function SizeDemo() {
  const [size, setSize] = useState<'small' | 'medium' | 'large'>('medium')
  const onValuesChange: FormProps<any>['onValuesChange'] = (changed) => {
    if (changed.size) setSize(changed.size)
  }
  return (
    <Form layout="vertical" size={size} initialValues={{ size }} onValuesChange={onValuesChange} style={{ maxWidth: 420 }}>
      <Form.Item label="Form Size" name="size">
        <Radio.Group>
          <Radio.Button value="small">Small</Radio.Button>
          <Radio.Button value="medium">Medium</Radio.Button>
          <Radio.Button value="large">Large</Radio.Button>
        </Radio.Group>
      </Form.Item>
      <DemoFields />
    </Form>
  )
}
SizeDemo.displayName = 'SizeDemo'

export const Size: Story = {
  render: () => <SizeDemo />,
  parameters: { docs: { source: { code: '() => <SizeDemo />' } } },
}

/**
 * Adapted from antd's `validate-static.tsx` demo — trimmed from its ~25
 * fields covering every control type down to one field per status, since
 * the point is the four `validateStatus` values themselves (plus the
 * `hasFeedback` icon two of them add), not re-demonstrating every control.
 * The items have no `name`, so no id ties each label to its input — the
 * inputs repeat their label as `aria-label`.
 */
export const ValidateStatus: Story = {
  render: () => (
    <Form layout="vertical" style={{ maxWidth: 420 }}>
      <Form.Item label="Error" validateStatus="error" help="Should be a combination of numbers & letters">
        <Input aria-label="Error" placeholder="Unavailable choice" />
      </Form.Item>
      <Form.Item label="Warning" validateStatus="warning" help="This value looks unusual">
        <Input aria-label="Warning" defaultValue="abc@" />
      </Form.Item>
      <Form.Item label="Validating" hasFeedback validateStatus="validating" help="The information is being validated…">
        <Input aria-label="Validating" placeholder="Checking…" />
      </Form.Item>
      <Form.Item label="Success" hasFeedback validateStatus="success">
        <Input aria-label="Success" defaultValue="Looks good" />
      </Form.Item>
    </Form>
  ),
}

const SELECT_OPTIONS = [{ value: 'option-1', label: 'Option 1' }, { value: 'option-2', label: 'Option 2' }]

/**
 * Figma `Form / Basic`, `Layout: Horizontal`. Labels sit in a fixed column
 * (`labelCol`) and fields fill the rest (`wrapperCol`); `label={null}` on the
 * button row indents it to the field column without drawing an empty label.
 * Its own field list rather than `DemoFields`, whose bare Submit button is
 * laid out for the vertical form only.
 */
export const Horizontal: Story = {
  render: () => (
    <Form name="basic-horizontal" layout="horizontal" labelCol={{ span: 6 }} wrapperCol={{ span: 18 }} style={{ maxWidth: 560 }}>
      <Form.Item label="Name" name="name" rules={[{ required: true }]}>
        <Input placeholder="Please input" />
      </Form.Item>
      <Form.Item label="Select" name="select">
        <Select placeholder="Please select" options={SELECT_OPTIONS} />
      </Form.Item>
      <Form.Item label="Switch" name="switch" valuePropName="checked" initialValue>
        <Switch />
      </Form.Item>
      <Form.Item label={null}>
        <Button type="primary" htmlType="submit">Submit</Button>
      </Form.Item>
    </Form>
  ),
}

/** Figma `Form / Basic`, `Layout: Inline`: label + field pairs on one row, wrapping when narrow. */
export const Inline: Story = {
  render: () => (
    <Form name="basic-inline" layout="inline">
      <Form.Item label="Name" name="name">
        <Input placeholder="Please input" />
      </Form.Item>
      <Form.Item label="Select" name="select">
        <Select placeholder="Please select" options={SELECT_OPTIONS} style={{ width: 160 }} />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit">Submit</Button>
      </Form.Item>
    </Form>
  ),
}

/** Upload inside a Form.Item: the field value is the file list, not the change event. */
const normFile = (e: UploadFile[] | { fileList: UploadFile[] }) => (Array.isArray(e) ? e : e.fileList)

const ORDER_TYPES = [
  { value: 'dine-in', label: 'Dine in' },
  { value: 'takeaway', label: 'Takeaway' },
  { value: 'delivery', label: 'Delivery' },
]

const STORE_TREE = [
  { title: 'North region', value: 'north', children: [{ title: 'Store A', value: 'store-a' }, { title: 'Store B', value: 'store-b' }] },
  { title: 'South region', value: 'south', children: [{ title: 'Store C', value: 'store-c' }, { title: 'Store D', value: 'store-d' }] },
]

/**
 * One Form.Item per field type the Figma `Form` page defines, in its order:
 * Text, Password, Phone, Textarea, Select, DatePicker, InputNumber, Switch,
 * Currency, Slider, Rate, Drag and Drop, Radio Buttons, Radio Group,
 * Checkbox Group, TimePicker, Upload Picture, Tree Select. Shared by the
 * vertical and horizontal item stories — the Figma docs frame shows the same
 * list in both layouts.
 *
 * Label marks follow Figma's `Mark` property: Text / Password / Phone are
 * required (asterisk), the rest carry none; Select shows the `Tooltip?`
 * icon, using the project's `HelpCircle` instead of antd's default glyph.
 * Phone uses `Space.Compact` for its country-code select — `addonBefore` is
 * deprecated in v6 — with nested `noStyle` items so both parts stay fields.
 * The "Phone" label can only point at one control, so the code select carries
 * its own `aria-label`; the Slider's handle is a `div`, which a `<label>` can't
 * name, so it takes `ariaLabelForHandle`.
 */
function FieldTypes() {
  return (
    <>
      <Form.Item label="Text" name="text" rules={[{ required: true }]}>
        <Input placeholder="Please input" />
      </Form.Item>
      <Form.Item label="Password" name="password" rules={[{ required: true }]}>
        <Input.Password placeholder="Please input" />
      </Form.Item>
      <Form.Item label="Phone" required>
        <Space.Compact block>
          <Form.Item name="phonePrefix" noStyle initialValue="+84">
            <Select
              aria-label="Country code"
              style={{ width: 80 }}
              options={[{ value: '+84', label: '+84' }, { value: '+1', label: '+1' }, { value: '+65', label: '+65' }]}
            />
          </Form.Item>
          <Form.Item name="phone" noStyle rules={[{ required: true }]}>
            <Input placeholder="Phone number" />
          </Form.Item>
        </Space.Compact>
      </Form.Item>
      <Form.Item label="Textarea" name="textarea">
        <Input.TextArea rows={3} placeholder="Please input" />
      </Form.Item>
      <Form.Item label="Select" name="select" tooltip={{ title: 'Pick one option', icon: <HelpCircle size={14} /> }}>
        <Select placeholder="Please select" options={SELECT_OPTIONS} />
      </Form.Item>
      <Form.Item label="Date" name="date">
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="Number" name="number">
        <InputNumber min={0} placeholder="Please input" style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="Switch" name="switch" valuePropName="checked">
        <Switch />
      </Form.Item>
      <Form.Item label="Currency" name="currency">
        <InputNumber<number>
          prefix="$"
          suffix="USD"
          min={0}
          placeholder="0"
          formatter={(value) => `${value ?? ''}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
          parser={(value) => value?.replace(/,/g, '') as unknown as number}
          style={{ width: '100%' }}
        />
      </Form.Item>
      <Form.Item label="Slider" name="slider" initialValue={40}>
        <Slider ariaLabelForHandle="Slider" marks={{ 0: '0', 50: '50', 100: '100' }} />
      </Form.Item>
      <Form.Item label="Rate" name="rate">
        <Rate allowHalf />
      </Form.Item>
      <Form.Item label="Drag and drop" name="dragger" valuePropName="fileList" getValueFromEvent={normFile}>
        <Upload.Dragger beforeUpload={() => false}>
          <p><UploadCloud01 size={32} /></p>
          <p className="ant-upload-text">Click or drag file to this area to upload</p>
          <p className="ant-upload-hint">Support for a single or bulk upload.</p>
        </Upload.Dragger>
      </Form.Item>
      <Form.Item label="Radio buttons" name="radioButtons" initialValue="dine-in">
        <Radio.Group optionType="button" options={ORDER_TYPES} />
      </Form.Item>
      <Form.Item label="Radio group" name="radioGroup" initialValue="dine-in">
        <Radio.Group options={ORDER_TYPES} />
      </Form.Item>
      <Form.Item label="Checkbox group" name="checkboxGroup" initialValue={['cash']}>
        <Checkbox.Group
          options={[{ value: 'cash', label: 'Cash' }, { value: 'card', label: 'Card' }, { value: 'e-wallet', label: 'E-wallet' }]}
        />
      </Form.Item>
      <Form.Item label="Time" name="time">
        <TimePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="Picture upload" name="pictures" valuePropName="fileList" getValueFromEvent={normFile}>
        <Upload listType="picture-card" beforeUpload={() => false}>
          <Flex vertical align="center" gap={8}>
            <Plus />
            <span>Upload</span>
          </Flex>
        </Upload>
      </Form.Item>
      <Form.Item label="Tree select" name="treeSelect">
        <TreeSelect treeData={STORE_TREE} placeholder="Please select" treeDefaultExpandAll />
      </Form.Item>
    </>
  )
}
FieldTypes.displayName = 'FieldTypes'

/** Figma's "vertical items" example: every field type, label above field. */
export const FieldTypesVertical: Story = {
  render: () => (
    <Form name="field-types-vertical" layout="vertical" style={{ maxWidth: 480 }}>
      <FieldTypes />
      <Space>
        <Button type="primary" htmlType="submit">Submit</Button>
        <Button htmlType="reset">Reset</Button>
      </Space>
    </Form>
  ),
  parameters: { docs: { source: { code: '() => (\n  <Form layout="vertical">\n    <FieldTypes />\n  </Form>\n)' } } },
}

/** Figma's "horizontal items" example: the same field list, label column on the left. */
export const FieldTypesHorizontal: Story = {
  render: () => (
    <Form name="field-types-horizontal" layout="horizontal" labelCol={{ span: 6 }} wrapperCol={{ span: 18 }} style={{ maxWidth: 640 }}>
      <FieldTypes />
      <Form.Item label={null}>
        <Space>
          <Button type="primary" htmlType="submit">Submit</Button>
          <Button htmlType="reset">Reset</Button>
        </Space>
      </Form.Item>
    </Form>
  ),
  parameters: {
    docs: { source: { code: '() => (\n  <Form layout="horizontal" labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>\n    <FieldTypes />\n  </Form>\n)' } },
  },
}

/**
 * Figma `Form / Login`, `MD | SM` — read here as the form's control size
 * (medium / small), switched with the toggle. One form at a time rather than
 * both side by side, so the canvas never shows two primary buttons at once.
 * The project icon set has no lock glyph, so only the username field carries
 * a prefix icon; the password field keeps its eye toggle.
 */
function LoginDemo() {
  const [size, setSize] = useState<'medium' | 'small'>('medium')
  return (
    <Flex vertical gap={16} style={{ maxWidth: 360 }}>
      <div>
        <Segmented<'medium' | 'small'>
          value={size}
          onChange={setSize}
          options={[{ value: 'medium', label: 'MD' }, { value: 'small', label: 'SM' }]}
        />
      </div>
      <Form name="login" size={size} initialValues={{ remember: true }}>
        <Form.Item name="username" rules={[{ required: true, message: 'Please input your username' }]}>
          <Input prefix={<User01 />} placeholder="Username" />
        </Form.Item>
        <Form.Item name="password" rules={[{ required: true, message: 'Please input your password' }]}>
          <Input.Password placeholder="Password" />
        </Form.Item>
        <Form.Item>
          <Flex justify="space-between" align="center">
            <Form.Item name="remember" valuePropName="checked" noStyle>
              <Checkbox>Remember me</Checkbox>
            </Form.Item>
            <a href="#">Forgot password</a>
          </Flex>
        </Form.Item>
        <Form.Item>
          <Button block type="primary" htmlType="submit">Log in</Button>
        </Form.Item>
        <Flex justify="center" gap={4}>
          <span>No account yet?</span>
          <a href="#">Register now</a>
        </Flex>
      </Form>
    </Flex>
  )
}
LoginDemo.displayName = 'LoginDemo'

export const Login: Story = {
  render: () => <LoginDemo />,
  parameters: { docs: { source: { code: '() => <LoginDemo />' } } },
}

/** Figma's "inline login" example: the login fields on one row via `layout="inline"`. */
export const InlineLogin: Story = {
  render: () => (
    <Form name="login-inline" layout="inline">
      <Form.Item name="username" rules={[{ required: true, message: 'Please input your username' }]}>
        <Input prefix={<User01 />} placeholder="Username" />
      </Form.Item>
      <Form.Item name="password" rules={[{ required: true, message: 'Please input your password' }]}>
        <Input.Password placeholder="Password" />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit">Log in</Button>
      </Form.Item>
    </Form>
  ),
}
