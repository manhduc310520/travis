import type { Meta, StoryObj } from '@storybook/react-vite'
import { Image, Space, Typography } from 'antd'
import { Eye } from '../icons'

const meta: Meta<typeof Image> = {
  component: Image,
  title: 'Components/Image',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's image types — written from the API.
  argTypes: {
    width: { description: 'Width of the rendered image, in pixels.', control: 'number' },
    height: { description: 'Height of the rendered image, in pixels.', control: 'number' },
    fallback: { description: 'Image URL shown if `src` fails to load.', control: 'text' },
    preview: { description: 'Click-to-preview overlay, or false to disable it. `cover` sets what shows on hover.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Image>

/**
 * Inline SVG "photos" as data URIs — no network requests, so every story
 * renders offline and identically in visual tests. The fills are picture
 * content, not UI colour, so they don't go through theme tokens.
 */
const photo = (sky: string, ground: string, w = 400, h = 300) =>
  `data:image/svg+xml;utf8,${encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">` +
      `<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${sky}"/><stop offset="1" stop-color="${ground}"/></linearGradient></defs>` +
      `<rect width="${w}" height="${h}" fill="url(#g)"/>` +
      `<circle cx="${w * 0.75}" cy="${h * 0.3}" r="${h * 0.1}" fill="#fff" fill-opacity="0.85"/>` +
      `<path d="M0 ${h} L${w * 0.3} ${h * 0.5} L${w * 0.55} ${h * 0.8} L${w * 0.75} ${h * 0.6} L${w} ${h} Z" fill="#000" fill-opacity="0.25"/>` +
      `</svg>`,
  )}`

const PHOTOS = {
  dawn: photo('#FFD8BF', '#FA541C'),
  sea: photo('#BAE0FF', '#0958D9'),
  forest: photo('#D9F7BE', '#389E0D'),
}

/**
 * Alt text for each photo. rc-image also reuses `alt` as the `aria-label` of
 * the click-to-preview wrapper (a `role="button"`), so it names both.
 */
const ALT = {
  dawn: 'Sun over hills in orange dawn tones',
  sea: 'Sun over hills in blue sea tones',
  forest: 'Sun over hills in green forest tones',
}

/** Neutral "image failed" tile used as the `fallback` source. */
const FALLBACK = `data:image/svg+xml;utf8,${encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300">' +
    '<rect width="400" height="300" fill="#F5F5F5"/>' +
    '<rect x="170" y="120" width="60" height="48" rx="4" fill="none" stroke="#BFBFBF" stroke-width="4"/>' +
    '<path d="M174 164 L192 144 L204 156 L214 146 L226 164 Z" fill="#BFBFBF"/>' +
    '<text x="200" y="196" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#8C8C8C">Image failed to load</text>' +
    '</svg>',
)}`

/** A data URI that can't decode — fails locally without touching the network. */
const BROKEN_SRC = 'data:image/png;base64,broken'

const Caption = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
    {children}
  </Typography.Text>
)

/** Figma `Image`, `Error State: Default` — the resting image; click opens the preview. */
export const Default: Story = {
  args: {
    width: 200,
    src: PHOTOS.dawn,
    alt: ALT.dawn,
  },
}

/**
 * Figma `Image`, `Error State: Hover` — the preview mask. antd 6's default
 * cover is only the dim overlay, so the eye + "Preview" label is passed as
 * `preview.cover`. Hover the image to see it.
 */
export const HoverMask: Story = {
  args: {
    width: 200,
    src: PHOTOS.dawn,
    alt: ALT.dawn,
    preview: {
      cover: (
        <Space size={4}>
          <Eye />
          Preview
        </Space>
      ),
    },
  },
}

/**
 * Figma `Image Preview`, `Breakpoint: Desktop` — click the image to open the
 * full-screen preview with its zoom / rotate / flip toolbar.
 */
export const PreviewDesktop: Story = {
  args: { width: 200, src: PHOTOS.sea, alt: ALT.sea },
}

/**
 * Figma `Image Preview`, `Breakpoint: Mobile` — the same preview, opened at a
 * phone-sized viewport (Storybook's `mobile2`, 414px). Click the image.
 */
export const PreviewMobile: Story = {
  args: { width: 200, src: PHOTOS.sea, alt: ALT.sea },
  globals: { viewport: { value: 'mobile2', isRotated: false } },
}

/** From the Figma component's Code Connect example. */
export const PreviewGroup: Story = {
  render: () => (
    <Image.PreviewGroup
      items={(['dawn', 'sea', 'forest'] as const).map((key) => ({ src: PHOTOS[key], alt: ALT[key] }))}
    >
      <Image width={200} src={PHOTOS.dawn} alt={ALT.dawn} />
    </Image.PreviewGroup>
  ),
}

/** `fallback` replaces a `src` that fails to load; `alt` says what the fallback tile shows. */
export const Fallback: Story = {
  args: {
    src: BROKEN_SRC,
    alt: 'Image failed to load',
    fallback: FALLBACK,
    width: 200,
  },
}

/**
 * Figma "fixed ratio images": the frame keeps its ratio and the picture is
 * cropped to fill it (`object-fit: cover`) instead of being squashed.
 * Every edge lands on the 4px grid.
 */
export const FixedRatio: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-end' }}>
      {[
        { label: '1:1', width: 160, height: 160 },
        { label: '4:3', width: 160, height: 120 },
        { label: '16:9', width: 192, height: 108 },
        { label: '3:4', width: 120, height: 160 },
      ].map(({ label, width, height }) => (
        <div key={label}>
          <Caption>{label}</Caption>
          <Image width={width} height={height} src={PHOTOS.forest} alt={`${ALT.forest}, ${label} crop`} styles={{ image: { objectFit: 'cover' } }} />
        </div>
      ))}
    </div>
  ),
}
