import type { ReactNode } from 'react'
import type { Meta, StoryObj } from '@storybook/react-vite'
import { Flex, InputNumber, Select, Space, Typography } from 'antd'
import { Settings01 } from '../icons'

const meta: Meta<typeof InputNumber> = {
  component: InputNumber,
  title: 'Components/InputNumber',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's input-number types — written from the API.
  argTypes: {
    min: { description: 'Lowest value the input will accept.', control: 'number' },
    step: { description: 'Amount added/removed per arrow-key press or spinner click.', control: 'number' },
    disabled: { description: 'Disables the input.', control: 'boolean' },
    status: { description: 'Validation state — colors the border and focus ring.', control: 'select', options: ['', 'warning', 'error'] },
    size: { description: 'Control height: small, medium (default, 32px) or large.', control: 'select', options: ['small', 'medium', 'large'] },
    variant: { description: 'Field chrome: full border, grey fill, no border, or bottom border only.', control: 'select', options: ['outlined', 'filled', 'borderless', 'underlined'] },
    mode: { description: "'spinner' swaps the stacked up/down arrows for − / + buttons on either side of the value.", control: 'select', options: ['input', 'spinner'] },
    prefix: { description: 'Content inside the field, before the value (unit, currency sign, icon).', control: 'text' },
    suffix: { description: 'Content inside the field, after the value.', control: 'text' },
  },
}
export default meta
type Story = StoryObj<typeof InputNumber>

/** Caption above each control, matching how the Figma docs frame labels every example. */
function Labeled({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Flex vertical gap={4}>
      <Typography.Text type="secondary">{label}</Typography.Text>
      {children}
    </Flex>
  )
}

export const Default: Story = { args: { defaultValue: 45000, min: 0, step: 1000, 'aria-label': 'Amount' } }

/**
 * Figma `Pre Post Tab`, post tab only. `addonAfter` is deprecated in AntD v6 —
 * its own type comment says to wrap the addon in `Space.Compact` instead.
 * `Space.Addon` is v6's cell for that: it draws the grey tab from theme
 * tokens, so it follows brand and dark mode (a hand-styled span with a
 * hardcoded `#fafafa` did not).
 */
export const WithSuffix: Story = {
  render: () => (
    <Space.Compact>
      <InputNumber defaultValue={45000} min={0} aria-label="Amount in dollars" />
      <Space.Addon>$</Space.Addon>
    </Space.Compact>
  ),
}
export const Disabled: Story = { args: { defaultValue: 45000, disabled: true, 'aria-label': 'Amount' } }
export const Invalid: Story = { args: { defaultValue: -1, status: 'error', 'aria-label': 'Amount' } }

/**
 * Figma `Basic` set, `Size` property. The `Hover` state from the same set is
 * interactive only — hover any field here to see it.
 */
export const Sizes: Story = {
  render: () => (
    <Flex gap={24} align="start" wrap>
      <Labeled label="Small">
        <InputNumber size="small" defaultValue={3} min={0} aria-label="Quantity, small" />
      </Labeled>
      <Labeled label="Medium (default)">
        <InputNumber defaultValue={3} min={0} aria-label="Quantity, medium" />
      </Labeled>
      <Labeled label="Large">
        <InputNumber size="large" defaultValue={3} min={0} aria-label="Quantity, large" />
      </Labeled>
    </Flex>
  ),
}

/** Figma `Prefix Suffix` set × `Status`: default / error / warning. */
export const PrefixSuffix: Story = {
  render: () => (
    <Flex vertical gap={16} style={{ maxWidth: 240 }}>
      <Labeled label="Default">
        <InputNumber prefix="$" suffix="USD" defaultValue={1200} min={0} aria-label="Price in USD, default" style={{ width: '100%' }} />
      </Labeled>
      <Labeled label="Error">
        <InputNumber prefix="$" suffix="USD" defaultValue={1200} min={0} status="error" aria-label="Price in USD, error" style={{ width: '100%' }} />
      </Labeled>
      <Labeled label="Warning">
        <InputNumber prefix="$" suffix="USD" defaultValue={1200} min={0} status="warning" aria-label="Price in USD, warning" style={{ width: '100%' }} />
      </Labeled>
    </Flex>
  ),
}

/**
 * Figma `Pre Post Tab` set — the three docs examples (pre + post, post only,
 * pre only) plus the set's `Type: Icon` and `Type: Select` tabs. All built
 * with `Space.Compact`: `Space.Addon` for text / icon tabs, a plain `Select`
 * for select tabs (the deprecated `addonBefore` / `addonAfter` props are not
 * used — see `WithSuffix`).
 */
export const PrePostTab: Story = {
  render: () => (
    <Flex vertical gap={16}>
      <Labeled label="Pre + post tab">
        <Space.Compact>
          <Space.Addon>+</Space.Addon>
          <InputNumber defaultValue={100} aria-label="Amount, pre + post tab" />
          <Space.Addon>$</Space.Addon>
        </Space.Compact>
      </Labeled>
      <Labeled label="Post tab only">
        <Space.Compact>
          <InputNumber defaultValue={100} aria-label="Amount, post tab only" />
          <Space.Addon>$</Space.Addon>
        </Space.Compact>
      </Labeled>
      <Labeled label="Pre tab only">
        <Space.Compact>
          <Space.Addon>+</Space.Addon>
          <InputNumber defaultValue={100} aria-label="Amount, pre tab only" />
        </Space.Compact>
      </Labeled>
      <Labeled label="Icon tab">
        <Space.Compact>
          <InputNumber defaultValue={100} aria-label="Amount, icon tab" />
          <Space.Addon>
            <Settings01 />
          </Space.Addon>
        </Space.Compact>
      </Labeled>
      <Labeled label="Select tabs">
        <Space.Compact>
          <Select
            defaultValue="add"
            aria-label="Operation"
            options={[{ value: 'add', label: '+' }, { value: 'minus', label: '−' }]}
            style={{ width: 64 }}
          />
          <InputNumber defaultValue={100} aria-label="Amount, select tabs" />
          <Select
            defaultValue="USD"
            aria-label="Currency"
            options={[{ value: 'USD', label: 'USD' }, { value: 'EUR', label: 'EUR' }, { value: 'GBP', label: 'GBP' }]}
            style={{ width: 80 }}
          />
        </Space.Compact>
      </Labeled>
    </Flex>
  ),
}

/** Figma's `Basic` (outlined), `Filled`, `Borderless` and `Underlined` sets, side by side. */
export const Variants: Story = {
  render: () => (
    <Flex vertical gap={16} style={{ maxWidth: 240 }}>
      <Labeled label="Outlined (default)">
        <InputNumber variant="outlined" placeholder="Please input" style={{ width: '100%' }} />
      </Labeled>
      <Labeled label="Filled">
        <InputNumber variant="filled" placeholder="Please input" style={{ width: '100%' }} />
      </Labeled>
      <Labeled label="Borderless">
        <InputNumber variant="borderless" placeholder="Please input" style={{ width: '100%' }} />
      </Labeled>
      <Labeled label="Underlined">
        <InputNumber variant="underlined" placeholder="Please input" style={{ width: '100%' }} />
      </Labeled>
    </Flex>
  ),
}

/** Figma `Filled` set × `Status`: default / error / warning. */
export const FilledStatus: Story = {
  render: () => (
    <Flex vertical gap={16} style={{ maxWidth: 240 }}>
      <Labeled label="Default">
        <InputNumber variant="filled" defaultValue={10} aria-label="Quantity, default" style={{ width: '100%' }} />
      </Labeled>
      <Labeled label="Error">
        <InputNumber variant="filled" defaultValue={10} status="error" aria-label="Quantity, error" style={{ width: '100%' }} />
      </Labeled>
      <Labeled label="Warning">
        <InputNumber variant="filled" defaultValue={10} status="warning" aria-label="Quantity, warning" style={{ width: '100%' }} />
      </Labeled>
    </Flex>
  ),
}

/**
 * Figma `Spinner` set, `Type: Outlined | Filled`. antd's `mode="spinner"`
 * moves the step controls out of the stacked arrow column into − / +
 * buttons that flank the value; `variant` supplies the outlined / filled look.
 */
export const Spinner: Story = {
  render: () => (
    <Flex vertical gap={16}>
      <Labeled label="Spinner, outlined">
        <InputNumber mode="spinner" variant="outlined" defaultValue={1} min={0} aria-label="Quantity, outlined" style={{ width: 160 }} />
      </Labeled>
      <Labeled label="Spinner, filled">
        <InputNumber mode="spinner" variant="filled" defaultValue={1} min={0} aria-label="Quantity, filled" style={{ width: 160 }} />
      </Labeled>
    </Flex>
  ),
}
