import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ReactNode } from 'react'
import { expect, screen } from 'storybook/test'
import { Flex, Mentions, Typography, theme } from 'antd'

const meta: Meta<typeof Mentions> = {
  component: Mentions,
  title: 'Components/Mentions',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's mentions types — written from the API.
  argTypes: {
    options: { description: 'The list of people/values suggested after typing @.', control: false },
    size: { description: 'Control height: small, middle (the 32px default) or large.', control: 'select', options: ['small', 'middle', 'large'] },
    placement: { description: 'Whether the suggestion list opens above or below the caret.', control: 'select', options: ['bottom', 'top'] },
  },
}
export default meta
type Story = StoryObj<typeof Mentions>

const options = [
  { value: 'john', label: 'john' },
  { value: 'jane', label: 'jane' },
  { value: 'alex', label: 'alex' },
]

/** Secondary 12px caption naming the Figma variant an example stands for. */
function Caption({ children, width }: { children: ReactNode; width?: number }) {
  const { token } = theme.useToken()
  return (
    <Typography.Text type="secondary" style={{ fontSize: token.fontSizeSM, width, flexShrink: 0 }}>
      {children}
    </Typography.Text>
  )
}

export const Default: Story = {
  args: {
    placeholder: 'Input @ to mention people',
    style: { maxWidth: 320 },
    options,
  },
}

/** Figma `Size[Small|Default|Large]`. `middle` is antd's name for the 32px default. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {(
        [
          ['small', 'Small'],
          ['middle', 'Default'],
          ['large', 'Large'],
        ] as const
      ).map(([size, label]) => (
        <Flex key={size} gap={16} align="center">
          <Caption width={96}>{label}</Caption>
          <Mentions size={size} options={options} placeholder="Input @ to mention people" style={{ width: 320 }} />
        </Flex>
      ))}
    </Flex>
  ),
}

/*
 * Figma's open examples. Mentions has no `open` prop — the list only appears
 * while the field is focused and the text before the caret starts with `@` —
 * so these stories type `@` in a play function instead. Only one list can
 * be open at a time (blurring a field closes its list), hence one story per
 * example rather than a side-by-side grid. The wrapper reserves room on the
 * side the list opens toward. On the Docs page play functions don't run, so
 * these show closed there; open each story's own canvas to see the list.
 */
const LIST_ROOM = 160

const openOnAt: Story['play'] = async ({ canvas, userEvent }) => {
  await userEvent.type(canvas.getByRole('textbox'), '@')
  // The list portals to document.body, outside the story canvas.
  await expect(await screen.findByRole('menuitem', { name: 'jane' })).toBeInTheDocument()
}

const openArgs = { options, placeholder: 'Input @ to mention people', style: { width: 320 } }

const renderOpen: Story['render'] = (args) => (
  <div style={args.placement === 'top' ? { paddingTop: LIST_ROOM } : { paddingBottom: LIST_ROOM }}>
    <Mentions {...args} />
  </div>
)

/** Figma "open bottom" (`State: Focused`, `Placement: Bottom`). */
export const OpenBottom: Story = {
  args: { ...openArgs, placement: 'bottom' },
  render: renderOpen,
  play: openOnAt,
}

/** Figma "open top" (`Placement: Top`). */
export const OpenTop: Story = {
  args: { ...openArgs, placement: 'top' },
  render: renderOpen,
  play: openOnAt,
}

/** Figma "large open". */
export const OpenLarge: Story = {
  args: { ...openArgs, size: 'large' },
  render: renderOpen,
  play: openOnAt,
}

/** Figma "small open". */
export const OpenSmall: Story = {
  args: { ...openArgs, size: 'small' },
  render: renderOpen,
  play: openOnAt,
}
