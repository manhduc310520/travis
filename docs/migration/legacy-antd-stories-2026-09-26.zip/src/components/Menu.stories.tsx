import type { Meta, StoryObj } from '@storybook/react-vite'
import { Menu } from 'antd'
import type { MenuProps } from 'antd'
import { AlertCircle, Building02, Mail01, PieChart01, Settings01, Users01 } from '../icons'
const meta: Meta<typeof Menu> = {
  component: Menu,
  title: 'Components/Menu',
  tags: ['ai-generated', 'needs-work'],
  // Every story uses a custom `render`, none set `args` — the Docs page's
  // argTypes table only renders once at least one arg exists. No JSDoc on
  // these in antd's menu types — written from the API.
  args: { mode: 'inline' },
  argTypes: {
    mode: { description: 'Layout direction of the menu.', control: 'select', options: ['vertical', 'horizontal', 'inline'] },
    theme: { description: 'Light or dark surface for the whole menu.', control: 'select', options: ['light', 'dark'] },
    items: { description: 'The list of menu items, nestable via `children`.', control: false },
    inlineCollapsed: { description: 'Collapses to icon-only width (mode="inline" only).', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Menu>

type MenuItem = NonNullable<MenuProps['items']>[number]

// Figma's Menu examples: icon items, one submenu holding a group title, and
// plain items.
const items: MenuItem[] = [
  { key: 'home', icon: <PieChart01 />, label: 'Navigation One' },
  {
    key: 'restaurants', icon: <Building02 />, label: 'Navigation Two',
    children: [
      {
        type: 'group', key: 'group', label: 'Item Group',
        children: [
          { key: 'list', label: 'Option 1' },
          { key: 'payment', label: 'Option 2' },
        ],
      },
      { key: 'area', label: 'Option 3' },
    ],
  },
  { key: 'staff', icon: <Users01 />, label: 'Navigation Three' },
  { key: 'devices', icon: <Settings01 />, label: 'Navigation Four' },
]

/** Figma `Mode=Inline`, `Theme=Light`: submenus expand in place. */
export const Inline: Story = {
  render: () => (
    <Menu mode="inline" defaultSelectedKeys={['list']} defaultOpenKeys={['restaurants']} items={items} style={{ width: 240 }} />
  ),
}

export const Horizontal: Story = {
  render: () => <Menu mode="horizontal" defaultSelectedKeys={['home']} items={items.slice(0, 3)} />,
}

/**
 * Figma `Collapsed=Yes` — covers both the `Mode=Inline` and `Mode=Vertical`
 * collapsed examples. antd only collapses through `inlineCollapsed` on an
 * inline menu (it warns when set on `mode="vertical"`), and a collapsed menu
 * always switches its submenus to vertical fly-outs, so the two Figma
 * variants are the same component in code. Hover an icon for its label,
 * or the building icon for its submenu.
 */
export const Collapsed: Story = {
  render: () => <Menu mode="inline" inlineCollapsed defaultSelectedKeys={['home']} items={items} style={{ width: 80 }} />,
}

/** Figma `Mode=Vertical`: submenus open as fly-outs to the right on hover instead of expanding in place. */
export const Vertical: Story = {
  render: () => <Menu mode="vertical" defaultSelectedKeys={['home']} items={items} style={{ width: 240 }} />,
}

/** Figma `Theme=Dark`, `Mode=Inline`. */
export const DarkInline: Story = {
  render: () => (
    <Menu
      theme="dark"
      mode="inline"
      defaultSelectedKeys={['list']}
      defaultOpenKeys={['restaurants']}
      items={items}
      style={{ width: 240 }}
    />
  ),
}

/** Figma `Theme=Dark`, `Mode=Vertical`. */
export const DarkVertical: Story = {
  render: () => <Menu theme="dark" mode="vertical" defaultSelectedKeys={['home']} items={items} style={{ width: 240 }} />,
}

/** Figma `Theme=Dark`, `Collapsed=Yes` (inline and vertical collapsed are one component — see `Collapsed`). */
export const DarkCollapsed: Story = {
  render: () => (
    <Menu theme="dark" mode="inline" inlineCollapsed defaultSelectedKeys={['home']} items={items} style={{ width: 80 }} />
  ),
}

/**
 * Every Figma menu-item variant in one menu: icon, submenu, group title,
 * divider, `disabled`, and `Status=Error` — which is antd's `danger` item.
 */
export const ItemTypes: Story = {
  render: () => (
    <Menu
      mode="inline"
      defaultSelectedKeys={['inbox']}
      defaultOpenKeys={['restaurants']}
      style={{ width: 240 }}
      items={[
        { key: 'inbox', icon: <Mail01 />, label: 'Selected item' },
        {
          key: 'restaurants', icon: <Building02 />, label: 'Submenu',
          children: [
            {
              type: 'group', key: 'group', label: 'Group title',
              children: [
                { key: 'option-1', label: 'Option 1' },
                { key: 'option-2', label: 'Option 2' },
              ],
            },
          ],
        },
        { key: 'staff', icon: <Users01 />, label: 'Default item' },
        { key: 'devices', icon: <Settings01 />, label: 'Disabled item', disabled: true },
        { type: 'divider' },
        { key: 'error', icon: <AlertCircle />, label: 'Error item', danger: true },
      ]}
    />
  ),
}
