import type { Meta, StoryObj } from '@storybook/react-vite'
import { Button, Space, message } from 'antd'
import { AlertCircle, CheckCircle, InfoCircle, XCircle } from '../icons'

/**
 * `message` has no component of its own — it is a function API
 * (`message.useMessage()` / `message.info()`…). For an always-visible preview
 * this uses `message._InternalPanelDoNotUseOrYouWillBeFired`, the static
 * panel exported in antd 6.6.5's typings that antd's own docs use to render a
 * notice inline: same markup and styles as a live message, minus the portal
 * and the auto-dismiss timer.
 */
const MessagePanel = message._InternalPanelDoNotUseOrYouWillBeFired

/**
 * Same circle icons as the Alert stories (Figma `info-circle-line`,
 * `check-circle-line`, `x-circle-line`, `alert-circle-line`). antd keeps its
 * type colour class on the icon wrapper even for a custom icon, so these pick
 * up the semantic colour on their own. `loading` keeps antd's own spinning
 * indicator — no animated equivalent exists in the icon set.
 */
const ICONS = {
  info: <InfoCircle />,
  success: <CheckCircle />,
  error: <XCircle />,
  warning: <AlertCircle />,
} as const

type NoticeType = keyof typeof ICONS | 'loading'
const iconFor = (type?: NoticeType) => (type && type !== 'loading' ? ICONS[type] : undefined)

/**
 * Figma's `Message` Type values mapped to antd's `type`. Figma "Normal" is
 * antd's `info` — the plain notice antd's docs call "Normal prompt".
 */
const TYPES = [
  { figma: 'Normal', type: 'info', content: 'This is a normal message' },
  { figma: 'Success', type: 'success', content: 'This is a success message' },
  { figma: 'Error', type: 'error', content: 'This is an error message' },
  { figma: 'Warning', type: 'warning', content: 'This is a warning message' },
  { figma: 'Loading', type: 'loading', content: 'Action in progress...' },
] as const

const meta: Meta<typeof MessagePanel> = {
  component: MessagePanel,
  title: 'Components/Message',
  tags: ['ai-generated', 'needs-work'],
  args: { type: 'info', content: 'This is a normal message' },
  // `type`'s description is antd's own JSDoc from message/interface.d.ts
  // (ArgsProps.type), copied as-is. The rest have none — written from the API.
  argTypes: {
    type: {
      description: "The type of message notification, which can be 'info', 'success', 'error', 'warning' or 'loading'",
      control: 'select',
      options: ['info', 'success', 'error', 'warning', 'loading'],
    },
    content: { description: 'The content of the message notification, receiving component or string', control: 'text' },
    icon: { description: 'Custom icon; replaces the one implied by `type`. Stories pass the circle icon matching `type`.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof MessagePanel>

/** A single message, driven by Controls. The icon follows the selected `type`. */
export const Default: Story = {
  render: (args) => <MessagePanel {...args} icon={iconFor(args.type)} />,
}

/** Figma's five `Message` types — Normal, Success, Error, Warning, Loading — rendered statically. */
export const Types: Story = {
  render: () => (
    <Space orientation="vertical" size={16} align="start">
      {TYPES.map(({ type, content }) => (
        <MessagePanel key={type} type={type} content={content} icon={iconFor(type)} />
      ))}
    </Space>
  ),
}

/**
 * The real thing: each button opens a live message at the top of the page
 * through `message.useMessage()`. The hook (not the bare `message.info()`
 * static) keeps messages inside the theme's `ConfigProvider`.
 */
function TriggersDemo() {
  const [messageApi, contextHolder] = message.useMessage()
  return (
    <>
      {contextHolder}
      <Space size={8} wrap>
        {TYPES.map(({ figma, type, content }) => (
          <Button
            key={type}
            onClick={() => messageApi.open({ type, content, icon: iconFor(type) })}
          >
            {figma}
          </Button>
        ))}
      </Space>
    </>
  )
}

export const Triggers: Story = {
  render: () => <TriggersDemo />,
}
