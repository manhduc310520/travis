import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Button, ConfigProvider, Form, Input, Modal, Space, Typography, theme } from 'antd'
import type { ModalProps } from 'antd'
import { antdIconDefaults } from '../theme/antdIcons'
import { AlertCircle, CheckCircle, InfoCircle, XCircle } from '../icons'

const meta: Meta<typeof Modal> = {
  component: Modal,
  title: 'Components/Modal',
  tags: ['ai-generated', 'needs-work'],
  // `open`/`confirmLoading`/`width`/`okText`/`cancelText` descriptions are
  // antd's own JSDoc from modal/interface.d.ts, copied as-is.
  argTypes: {
    open: { description: 'Whether the modal dialog is visible or not.', control: 'boolean' },
    confirmLoading: { description: 'Whether to apply loading visual effect for the OK button or not.', control: 'boolean' },
    width: { description: 'Width of the modal dialog.', control: 'number' },
    okText: { description: 'Text of the OK button.', control: 'text' },
    cancelText: { description: 'Text of the Cancel button.', control: 'text' },
    okButtonProps: { description: 'Props passed through to the OK button (e.g. { danger: true }).', control: false },
    footer: { description: 'Footer content. `null` hides it; a function receives the default OK/Cancel buttons to rearrange.', control: false },
    mask: { description: 'Whether to show the dimmed overlay behind the dialog.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Modal>

// ─── Containment ────────────────────────────────────────────────────────────

/**
 * An open Modal's wrap and mask are `position: fixed`, so even with
 * `getContainer={false}` they would cover the whole Docs page. Switching both
 * to `absolute` pins them to the `Stage` box instead. It also keeps antd from
 * trapping focus: rc-dialog only locks focus when the wrap's computed
 * position is `fixed`, so a page full of open modals stays usable.
 */
const CONTAINED: ModalProps['styles'] = {
  wrapper: { position: 'absolute' },
  mask: { position: 'absolute' },
}

function Stage({ height = 400, children }: { height?: number; children: React.ReactNode }) {
  const { token } = theme.useToken()
  return (
    <div
      style={{
        position: 'relative',
        height,
        overflow: 'hidden',
        isolation: 'isolate',
        border: `${token.lineWidth}px ${token.lineType} ${token.colorBorderSecondary}`,
        borderRadius: token.borderRadiusLG,
      }}
    >
      {children}
    </div>
  )
}

// ─── Status icons ───────────────────────────────────────────────────────────

type Status = 'info' | 'success' | 'error' | 'warning'

/**
 * Same circle icons as the Alert stories (`x-circle-line`, `info-circle-line`,
 * `check-circle-line`, `alert-circle-line` in Figma) instead of antd's filled
 * glyphs. antd only sizes and colours `.anticon` children of the confirm body,
 * so the Untitled UI svg takes its size (`fontHeight`), colour and gap
 * (`marginSM`) straight from the same tokens antd's confirm style uses.
 */
const STATUS_ICONS = { error: XCircle, info: InfoCircle, success: CheckCircle, warning: AlertCircle } as const

function StatusIcon({ status }: { status: Status }) {
  const { token } = theme.useToken()
  const colors: Record<Status, string> = {
    error: token.colorError,
    info: token.colorInfo,
    success: token.colorSuccess,
    warning: token.colorWarning,
  }
  const Icon = STATUS_ICONS[status]
  // antd's `fontHeight` (not on the public GlobalToken type), derived the same way.
  const size = Math.round(token.fontSize * token.lineHeight)
  return <Icon size={size} style={{ flex: 'none', color: colors[status], marginInlineEnd: token.marginSM }} />
}

/**
 * `ConfigProvider`'s `modal.infoIcon` / `successIcon` / `errorIcon` /
 * `warningIcon` feed every information and confirm dialog below it — both the
 * static panels and the ones opened through `Modal.useModal()`. The project's
 * global `antdIconDefaults` doesn't set these four yet, so this story file
 * supplies them locally (keeping the global close icon).
 */
function StatusIcons({ children }: { children: React.ReactNode }) {
  return (
    <ConfigProvider
      modal={{
        ...antdIconDefaults.modal,
        infoIcon: <StatusIcon status="info" />,
        successIcon: <StatusIcon status="success" />,
        errorIcon: <StatusIcon status="error" />,
        warningIcon: <StatusIcon status="warning" />,
      }}
    >
      {children}
    </ConfigProvider>
  )
}

/**
 * The static panel antd's own docs use to preview a dialog inline. With `type`
 * set it renders exactly the markup `Modal.info()` / `Modal.confirm()` produce
 * — no mask, no portal, no focus handling — so all four statuses can sit side
 * by side. `children` becomes the dialog's content.
 */
const StaticPanel = Modal._InternalPanelDoNotUseOrYouWillBeFired

// ─── Basic ──────────────────────────────────────────────────────────────────

/** Figma `Modal / Basic` Type=Slot: arbitrary content (here a form) in the body. */
export const Open: Story = {
  args: {
    open: true,
    title: 'Basic Modal',
    okText: 'OK',
    cancelText: 'Cancel',
    getContainer: false,
    styles: CONTAINED,
    children: (
      <Form layout="vertical">
        <Form.Item label="Name">
          <Input placeholder="Please input" />
        </Form.Item>
      </Form>
    ),
  },
  decorators: [
    (Story) => (
      <Stage height={420}>
        <Story />
      </Stage>
    ),
  ],
}

/** Figma `Modal / Basic` Type=Text: plain paragraphs in the body. */
export const BasicText: Story = {
  render: () => (
    <Stage height={360}>
      <Modal open getContainer={false} styles={CONTAINED} title="Basic Modal" okText="OK" cancelText="Cancel">
        <Typography.Paragraph>Some contents...</Typography.Paragraph>
        <Typography.Paragraph>Some contents...</Typography.Paragraph>
        <Typography.Paragraph style={{ marginBottom: 0 }}>Some contents...</Typography.Paragraph>
      </Modal>
    </Stage>
  ),
}

export const Confirm: Story = {
  args: {
    open: true,
    title: 'Are you sure delete this task?',
    okText: 'Delete',
    okButtonProps: { danger: true },
    cancelText: 'Cancel',
    getContainer: false,
    styles: CONTAINED,
    children: <p>This action cannot be undone.</p>,
  },
  decorators: [
    (Story) => (
      <Stage height={360}>
        <Story />
      </Stage>
    ),
  ],
}

/**
 * Custom footer: `footer` replaces the default OK/Cancel pair. Still one
 * primary action per dialog — the extra action is a default button.
 */
export const CustomFooter: Story = {
  render: () => (
    <Stage height={360}>
      <Modal
        open
        getContainer={false}
        styles={CONTAINED}
        title="Title"
        footer={
          <Space size={8}>
            <Button>Return</Button>
            <Button>Save draft</Button>
            <Button type="primary">Submit</Button>
          </Space>
        }
      >
        <Typography.Paragraph>Some contents...</Typography.Paragraph>
        <Typography.Paragraph style={{ marginBottom: 0 }}>Some contents...</Typography.Paragraph>
      </Modal>
    </Stage>
  ),
}

/**
 * Figma's "with overlay" example: the dialog over a page, dimmed by the mask
 * (`rgba(0,0,0,0.45)` — antd's `colorBgMask`). Page content is drawn behind it
 * so the overlay is visible.
 */
export const WithOverlay: Story = {
  render: () => (
    <Stage height={400}>
      <div style={{ padding: 24 }}>
        <Typography.Title level={4}>Page title</Typography.Title>
        <Typography.Paragraph>
          Page content sits underneath the modal. The mask dims it and blocks interaction until the dialog is closed.
        </Typography.Paragraph>
        <Space size={8}>
          <Button>Secondary</Button>
          <Button>Another action</Button>
        </Space>
      </div>
      <Modal open getContainer={false} styles={CONTAINED} title="Basic Modal" okText="OK" cancelText="Cancel">
        <Typography.Paragraph style={{ marginBottom: 0 }}>Some contents...</Typography.Paragraph>
      </Modal>
    </Stage>
  ),
}

// ─── Information & confirmation ─────────────────────────────────────────────

const INFO_EXAMPLES: { status: Status; title: string; content: string }[] = [
  { status: 'info', title: 'This is a notification message', content: 'Some messages... some messages...' },
  { status: 'success', title: 'This is a success message', content: 'Some messages... some messages...' },
  { status: 'error', title: 'This is an error message', content: 'Some messages... some messages...' },
  { status: 'warning', title: 'This is a warning message', content: 'Some messages... some messages...' },
]

/**
 * Figma `Modal / Information` Status=Info / Success / Error / Warning, rendered
 * statically. These are what `Modal.info()` / `.success()` / `.error()` /
 * `.warning()` open — see `InformationTriggers` for the live versions.
 */
export const Information: Story = {
  render: () => (
    <StatusIcons>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(416px, 1fr))', gap: 16 }}>
        {INFO_EXAMPLES.map(({ status, title, content }) => (
          <StaticPanel key={status} type={status} title={title} style={{ width: '100%' }}>
            {content}
          </StaticPanel>
        ))}
      </div>
    </StatusIcons>
  ),
}

/**
 * Live information dialogs. `Modal.useModal()` is used rather than the bare
 * `Modal.info()` static so the dialogs inherit the theme and icon config from
 * the surrounding `ConfigProvider` (the static functions render outside it).
 */
function InformationTriggersDemo() {
  const [modal, contextHolder] = Modal.useModal()
  return (
    <>
      {contextHolder}
      <Space size={8} wrap>
        {INFO_EXAMPLES.map(({ status, title, content }) => (
          <Button key={status} onClick={() => modal[status]({ title, content })}>
            {status[0].toUpperCase() + status.slice(1)}
          </Button>
        ))}
      </Space>
    </>
  )
}

export const InformationTriggers: Story = {
  render: () => (
    <StatusIcons>
      <InformationTriggersDemo />
    </StatusIcons>
  ),
}

/**
 * Figma's "confirmation" example — `Modal.confirm()`: warning icon, title,
 * content, and a Cancel + OK pair. Static render on the left, a live trigger
 * on the right.
 */
function ConfirmationDemo() {
  const [modal, contextHolder] = Modal.useModal()
  return (
    <>
      {contextHolder}
      <Space size={24} align="start" wrap>
        <StaticPanel type="confirm" title="Do you want to delete these items?" style={{ width: 416 }}>
          When clicked the OK button, this dialog will be closed after 1 second.
        </StaticPanel>
        <Button
          onClick={() =>
            modal.confirm({
              title: 'Do you want to delete these items?',
              content: 'When clicked the OK button, this dialog will be closed after 1 second.',
              onOk: () => new Promise((resolve) => setTimeout(resolve, 1000)),
            })
          }
        >
          Confirm
        </Button>
      </Space>
    </>
  )
}

export const Confirmation: Story = {
  render: () => (
    <StatusIcons>
      <ConfirmationDemo />
    </StatusIcons>
  ),
}

// ─── Interactive ────────────────────────────────────────────────────────────

/** A real, viewport-level modal opened from a button — the everyday usage. */
function InteractiveDemo() {
  const [open, setOpen] = useState(false)
  return (
    <>
      <Button type="primary" onClick={() => setOpen(true)}>
        Open Modal
      </Button>
      <Modal title="Basic Modal" open={open} onOk={() => setOpen(false)} onCancel={() => setOpen(false)} okText="OK" cancelText="Cancel">
        <Typography.Paragraph>Some contents...</Typography.Paragraph>
        <Typography.Paragraph>Some contents...</Typography.Paragraph>
        <Typography.Paragraph style={{ marginBottom: 0 }}>Some contents...</Typography.Paragraph>
      </Modal>
    </>
  )
}

export const Interactive: Story = {
  render: () => <InteractiveDemo />,
}
