import type { Meta, StoryObj } from '@storybook/react-vite'
import { Button, Space, notification, theme } from 'antd'
import { AlertCircle, CheckCircle, InfoCircle, XCircle } from '../icons'

/**
 * `notification` has no component of its own — it is a function API
 * (`notification.useNotification()` / `notification.info()`…). For an
 * always-visible preview this uses
 * `notification._InternalPanelDoNotUseOrYouWillBeFired`, the static panel
 * exported in antd 6.6.5's typings that antd's own docs use to render a
 * notice inline: same markup and styles (384px wide, close button from the
 * global icon config), minus the portal and the auto-dismiss timer.
 */
const NotificationPanel = notification._InternalPanelDoNotUseOrYouWillBeFired

type Status = 'info' | 'success' | 'warning' | 'error'

/**
 * Same circle icons as the Alert stories (Figma `info-circle-line`,
 * `check-circle-line`, `alert-circle-line`, `x-circle-line`). Unlike Message,
 * antd drops the type colour class from the icon wrapper as soon as a custom
 * icon is passed, so the colour — and antd's icon size, `fontSizeLG ×
 * lineHeightLG` — are read from the theme here.
 */
const STATUS_ICONS = { info: InfoCircle, success: CheckCircle, warning: AlertCircle, error: XCircle } as const

function StatusIcon({ status }: { status: Status }) {
  const { token } = theme.useToken()
  const colors: Record<Status, string> = {
    info: token.colorInfo,
    success: token.colorSuccess,
    warning: token.colorWarning,
    error: token.colorError,
  }
  const Icon = STATUS_ICONS[status]
  return <Icon size={token.fontSizeLG * token.lineHeightLG} style={{ color: colors[status] }} />
}

const iconFor = (type?: Status) => (type ? <StatusIcon status={type} /> : undefined)

const TITLE = 'Notification Title'
const DESCRIPTION =
  'This is the content of the notification. This is the content of the notification. This is the content of the notification.'

/**
 * Figma's `Notification` Type values. `Basic` has no antd `type` — it is the
 * plain notice with no icon, which is also what Figma's `Show Icon?` = false
 * amounts to: antd ties the icon to `type`, so hiding it means omitting
 * `type`.
 */
const TYPES: { figma: string; type?: Status }[] = [
  { figma: 'Basic' },
  { figma: 'Info', type: 'info' },
  { figma: 'Success', type: 'success' },
  { figma: 'Warning', type: 'warning' },
  { figma: 'Error', type: 'error' },
]

/**
 * Figma's `Buttons?` slot — antd's `actions` (formerly `btn`). One primary
 * action per notice; the other is a default button.
 */
const actions = (
  <Space size={8}>
    <Button size="small">Cancel</Button>
    <Button size="small" type="primary">
      Confirm
    </Button>
  </Space>
)

const meta: Meta<typeof NotificationPanel> = {
  component: NotificationPanel,
  title: 'Components/Notification',
  tags: ['ai-generated', 'needs-work'],
  args: { type: 'info', title: TITLE, description: DESCRIPTION },
  // No JSDoc on these in antd's notification PurePanel types — written from the API.
  argTypes: {
    type: { description: 'Status of the notice; sets its icon and colour. Omit for a plain notice.', control: 'select', options: [undefined, 'info', 'success', 'warning', 'error'] },
    title: { description: 'Heading of the notice (formerly `message`).', control: 'text' },
    description: { description: 'Body text under the title.', control: 'text' },
    actions: { description: 'Buttons rendered at the bottom right of the notice (formerly `btn`).', control: false },
    icon: { description: 'Custom icon; replaces the one implied by `type`. Stories pass the circle icon matching `type`.', control: false },
    closable: { description: 'Whether the notice shows a close button.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof NotificationPanel>

/** A single notice, driven by Controls. The icon follows the selected `type`. */
export const Default: Story = {
  render: (args) => <NotificationPanel {...args} icon={iconFor(args.type)} />,
}

/** Figma's five `Notification` types — Basic, Info, Success, Warning, Error — rendered statically. */
export const Types: Story = {
  render: () => (
    <Space orientation="vertical" size={16}>
      {TYPES.map(({ figma, type }) => (
        <NotificationPanel key={figma} type={type} icon={iconFor(type)} title={TITLE} description={DESCRIPTION} />
      ))}
    </Space>
  ),
}

/** Figma's `Buttons?` = true, across the five types. */
export const WithActions: Story = {
  render: () => (
    <Space orientation="vertical" size={16}>
      {TYPES.map(({ figma, type }) => (
        <NotificationPanel key={figma} type={type} icon={iconFor(type)} title={TITLE} description={DESCRIPTION} actions={actions} />
      ))}
    </Space>
  ),
}

/** Figma's `Show Icon?` = false: no `type`, so no icon — with and without actions. */
export const WithoutIcon: Story = {
  render: () => (
    <Space orientation="vertical" size={16}>
      <NotificationPanel title={TITLE} description={DESCRIPTION} />
      <NotificationPanel title={TITLE} description={DESCRIPTION} actions={actions} />
    </Space>
  ),
}

/**
 * The real thing: each button opens a live notification in the top-right
 * corner through `notification.useNotification()`. The hook (not the bare
 * `notification.info()` static) keeps notices inside the theme's
 * `ConfigProvider`.
 */
function TriggersDemo() {
  const [api, contextHolder] = notification.useNotification()
  return (
    <>
      {contextHolder}
      <Space size={8} wrap>
        {TYPES.map(({ figma, type }) => (
          <Button key={figma} onClick={() => api.open({ type, icon: iconFor(type), title: TITLE, description: DESCRIPTION })}>
            {figma}
          </Button>
        ))}
        <Button onClick={() => api.open({ type: 'info', icon: iconFor('info'), title: TITLE, description: DESCRIPTION, actions })}>
          With actions
        </Button>
      </Space>
    </>
  )
}

export const Triggers: Story = {
  render: () => <TriggersDemo />,
}
