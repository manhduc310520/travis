import type { Meta, StoryObj } from '@storybook/react-vite'
import { Pagination, Space } from 'antd'
import type { PaginationProps } from 'antd'

const meta: Meta<typeof Pagination> = {
  component: Pagination,
  title: 'Components/Pagination',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's pagination types — written from the API.
  argTypes: {
    total: { description: 'Total number of items being paginated.', control: 'number' },
    defaultCurrent: { description: 'Page selected on first render (uncontrolled).', control: 'number' },
    size: { description: 'Size of the page items.', control: 'select', options: ['small', 'medium', 'large'] },
    showSizeChanger: { description: 'Shows a control to change how many items per page.', control: 'boolean' },
    showQuickJumper: { description: 'Shows an input to jump directly to a page number.', control: 'boolean' },
    simple: { description: 'Compact layout — just prev/next and a page input.', control: 'boolean' },
    disabled: { description: 'Disables every page item and control.', control: 'boolean' },
    itemRender: { description: 'Replaces how each page / prev / next / jumper item is rendered.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Pagination>

/** Figma `Variant=Basic`: few enough pages that every page number shows. */
export const Default: Story = { args: { total: 50, defaultCurrent: 1 } }
export const WithSizeChanger: Story = { args: { total: 240, showSizeChanger: true, showQuickJumper: true } }
/** Figma `Variant=Mini` — antd's small size. */
export const Small: Story = { args: { total: 50, size: 'small' } }
/** Figma `Variant=Simple`: prev / page input / next. */
export const Simple: Story = { args: { total: 50, defaultCurrent: 2, simple: true } }

/** Figma `Variant=More`: many pages collapse into `•••` jump items on either side of the current page. */
export const More: Story = { args: { total: 500, defaultCurrent: 6 } }

/** Figma `Variant=Jumper`: "Go to" input after the page items. */
export const Jumper: Story = { args: { total: 500, defaultCurrent: 2, showQuickJumper: true } }

/** Figma `Variant=Mini Jumper`: the small size with the "Go to" input. */
export const MiniJumper: Story = { args: { total: 500, defaultCurrent: 2, size: 'small', showQuickJumper: true } }

const prevNextRender: PaginationProps['itemRender'] = (_page, type, originalElement) => {
  if (type === 'prev') return <a>Previous</a>
  if (type === 'next') return <a>Next</a>
  return originalElement
}

/** Figma `Variant=Prev and next`: text links replace the arrow buttons, via `itemRender`. */
export const PrevAndNext: Story = { args: { total: 500, itemRender: prevNextRender } }

/** Figma item `Size`: `Small` / `Default` / `Large`. */
export const Sizes: Story = {
  render: () => (
    <Space orientation="vertical" size={16}>
      <Pagination size="small" total={50} />
      <Pagination size="medium" total={50} />
      <Pagination size="large" total={50} />
    </Space>
  ),
}

/** Figma item `disabled`: every page item and control greyed out. */
export const Disabled: Story = { args: { total: 500, defaultCurrent: 2, disabled: true, showSizeChanger: true } }
