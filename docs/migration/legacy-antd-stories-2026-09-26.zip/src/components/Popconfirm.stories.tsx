import type { Meta, StoryObj } from '@storybook/react-vite'
import type { CSSProperties } from 'react'
import { Popconfirm, Button, App } from 'antd'
import type { PopconfirmProps } from 'antd'

const meta: Meta<typeof Popconfirm> = {
  component: Popconfirm,
  title: 'Components/Popconfirm',
  tags: ['ai-generated', 'needs-work'],
  // The stories use a custom `render` with no `args` — the Docs page's
  // argTypes table only renders once at least one arg exists. No JSDoc on
  // these in antd's popconfirm types — written from the API.
  args: { title: 'Are you sure to delete this task?' },
  argTypes: {
    title: { description: 'Confirmation question shown in the popup.', control: 'text' },
    description: { description: 'Secondary text under the title.', control: 'text' },
    okText: { description: 'Text of the confirm button.', control: 'text' },
    cancelText: { description: 'Text of the cancel button.', control: 'text' },
    placement: {
      description: 'Where the popup opens relative to the trigger.',
      control: 'select',
      options: ['topLeft', 'top', 'topRight', 'leftTop', 'left', 'leftBottom', 'rightTop', 'right', 'rightBottom', 'bottomLeft', 'bottom', 'bottomRight'],
    },
    onConfirm: { description: 'Called when the confirm button is clicked.', control: false },
    onCancel: { description: 'Called when the cancel button is clicked.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Popconfirm>

type Placement = NonNullable<PopconfirmProps['placement']>

/**
 * Statically-open popups render into their own wrapper rather than
 * `document.body`, so they move with the story when the Docs page reflows
 * instead of staying where they were first measured.
 */
const inCell = (trigger: HTMLElement) => trigger.closest<HTMLElement>('[data-popup-cell]') ?? document.body

export const Default: Story = {
  render: () => (
    <div data-popup-cell style={{ position: 'relative', height: 200, paddingTop: 80 }}>
      <Popconfirm title="Are you sure to delete this task?" okText="Yes" cancelText="No" open getPopupContainer={inCell}>
        <Button danger>Delete</Button>
      </Popconfirm>
    </div>
  ),
}

/** Closed by default — click to open; confirming or cancelling closes it and reports back through a message. */
function InteractiveDemo() {
  const { message } = App.useApp()
  return (
    <div style={{ minHeight: 160, paddingTop: 100 }}>
      <Popconfirm
        title="Delete the task"
        description="Are you sure to delete this task?"
        okText="Yes"
        cancelText="No"
        onConfirm={() => message.success('Task deleted')}
        onCancel={() => message.info('Cancelled')}
      >
        <Button danger>Delete</Button>
      </Popconfirm>
    </div>
  )
}

export const Interactive: Story = {
  render: () => <InteractiveDemo />,
}

// Top and bottom placements in rows of three; left/right placements side by
// side, one row per alignment — so every popup opens into its own cell.
const PLACEMENT_AREAS = `
  "topLeft topLeft top top topRight topRight"
  "leftTop leftTop leftTop rightTop rightTop rightTop"
  "left left left right right right"
  "leftBottom leftBottom leftBottom rightBottom rightBottom rightBottom"
  "bottomLeft bottomLeft bottom bottom bottomRight bottomRight"`

const PLACEMENTS: Placement[] = [
  'topLeft', 'top', 'topRight',
  'leftTop', 'left', 'leftBottom',
  'rightTop', 'right', 'rightBottom',
  'bottomLeft', 'bottom', 'bottomRight',
]

/** Parks the trigger on the side opposite the popup, so the popup has the cell's room. */
function cellStyle(placement: Placement): CSSProperties {
  const side = placement.startsWith('top') ? 'top' : placement.startsWith('bottom') ? 'bottom' : placement.startsWith('left') ? 'left' : 'right'
  const opensVertically = side === 'top' || side === 'bottom'
  const edgeAlign = (start: string, end: string) => (placement.endsWith(start) ? 'flex-start' : placement.endsWith(end) ? 'flex-end' : 'center')
  return {
    gridArea: placement,
    position: 'relative',
    display: 'flex',
    alignItems: opensVertically ? (side === 'top' ? 'flex-end' : 'flex-start') : edgeAlign('Top', 'Bottom'),
    justifyContent: opensVertically ? edgeAlign('Left', 'Right') : side === 'left' ? 'flex-end' : 'flex-start',
  }
}

/**
 * Figma `Placement`: all 12, held open. `autoAdjustOverflow={false}` stops
 * antd flipping a popup that nears the canvas edge, so each one shows exactly
 * the placement it is labelled with.
 */
export const Placements: Story = {
  render: () => (
    <div
      style={{
        display: 'grid',
        gridTemplateAreas: PLACEMENT_AREAS,
        gridTemplateColumns: 'repeat(6, minmax(0, 1fr))',
        gridTemplateRows: '200px 160px 160px 160px 200px',
        gap: 24,
        minWidth: 880,
        maxWidth: 960,
      }}
    >
      {PLACEMENTS.map((placement) => (
        <div key={placement} data-popup-cell style={cellStyle(placement)}>
          <Popconfirm
            title="Delete the task"
            description="Are you sure to delete this task?"
            okText="Yes"
            cancelText="No"
            placement={placement}
            open
            autoAdjustOverflow={false}
            getPopupContainer={inCell}
          >
            <Button>{placement}</Button>
          </Popconfirm>
        </div>
      ))}
    </div>
  ),
}
