import type { Meta, StoryObj } from '@storybook/react-vite'
import type { CSSProperties } from 'react'
import { Popover, Button, Space } from 'antd'
import type { PopoverProps } from 'antd'

const meta: Meta<typeof Popover> = {
  component: Popover,
  title: 'Components/Popover',
  tags: ['ai-generated', 'needs-work'],
  // The stories use a custom `render` with no `args` — the Docs page's
  // argTypes table only renders once at least one arg exists. No JSDoc on
  // these in antd's popover types — written from the API.
  args: { title: 'Title' },
  argTypes: {
    title: { description: 'Title shown at the top of the popup.', control: 'text' },
    content: { description: 'Body content of the popup.', control: false },
    placement: {
      description: 'Where the popup opens relative to the trigger.',
      control: 'select',
      options: ['topLeft', 'top', 'topRight', 'leftTop', 'left', 'leftBottom', 'rightTop', 'right', 'rightBottom', 'bottomLeft', 'bottom', 'bottomRight'],
    },
    arrow: { description: 'Shows the arrow pointing at the trigger; `{ pointAtCenter: true }` aims it at the trigger centre.', control: 'boolean' },
    trigger: { description: 'Which interaction opens the popup.', control: 'select', options: ['hover', 'focus', 'click', 'contextMenu'] },
    open: { description: 'Controlled open state.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Popover>

type Placement = NonNullable<PopoverProps['placement']>

const content = (
  <div>
    Content
    <br />
    Content
  </div>
)

/**
 * Statically-open popups render into their own wrapper rather than
 * `document.body`, so they move with the story when the Docs page reflows
 * instead of staying where they were first measured.
 */
const inCell = (trigger: HTMLElement) => trigger.closest<HTMLElement>('[data-popup-cell]') ?? document.body

export const Default: Story = {
  render: () => (
    <div data-popup-cell style={{ position: 'relative', height: 240, paddingTop: 100 }}>
      <Popover title="Title" content={content} open getPopupContainer={inCell}>
        <Button>Hover me</Button>
      </Popover>
    </div>
  ),
}

/** Closed by default — hover, focus (Tab to the button) or click to open. */
export const TriggerTypes: Story = {
  render: () => (
    <div style={{ minHeight: 160, paddingTop: 100 }}>
      <Space>
        <Popover title="Title" content={content} trigger="hover">
          <Button>Hover me</Button>
        </Popover>
        <Popover title="Title" content={content} trigger="focus">
          <Button>Focus me</Button>
        </Popover>
        <Popover title="Title" content={content} trigger="click">
          <Button>Click me</Button>
        </Popover>
      </Space>
    </div>
  ),
}

/** Figma `Arrow?` off. */
export const WithoutArrow: Story = {
  render: () => (
    <div data-popup-cell style={{ position: 'relative', height: 240, paddingTop: 100 }}>
      <Popover title="Title" content={content} arrow={false} open getPopupContainer={inCell}>
        <Button>Hover me</Button>
      </Popover>
    </div>
  ),
}

// Top and bottom placements in rows of three; left/right placements side by
// side, one row per alignment — so every popup opens into its own cell.
const PLACEMENT_AREAS = `
  "topLeft topLeft top top topRight topRight"
  "leftTop leftTop leftTop rightTop rightTop rightTop"
  "left left left right right right"
  "leftBottom leftBottom leftBottom rightBottom rightBottom rightBottom"
  "bottomLeft bottomLeft bottom bottom bottomRight bottomRight"`

const PLACEMENTS: Placement[] = [
  'topLeft', 'top', 'topRight',
  'leftTop', 'left', 'leftBottom',
  'rightTop', 'right', 'rightBottom',
  'bottomLeft', 'bottom', 'bottomRight',
]

/** Parks the trigger on the side opposite the popup, so the popup has the cell's room. */
function cellStyle(placement: Placement): CSSProperties {
  const side = placement.startsWith('top') ? 'top' : placement.startsWith('bottom') ? 'bottom' : placement.startsWith('left') ? 'left' : 'right'
  const opensVertically = side === 'top' || side === 'bottom'
  const edgeAlign = (start: string, end: string) => (placement.endsWith(start) ? 'flex-start' : placement.endsWith(end) ? 'flex-end' : 'center')
  return {
    gridArea: placement,
    position: 'relative',
    display: 'flex',
    alignItems: opensVertically ? (side === 'top' ? 'flex-end' : 'flex-start') : edgeAlign('Top', 'Bottom'),
    justifyContent: opensVertically ? edgeAlign('Left', 'Right') : side === 'left' ? 'flex-end' : 'flex-start',
  }
}

/**
 * Figma `Placement`: all 12, held open. `autoAdjustOverflow={false}` stops
 * antd flipping a popup that nears the canvas edge, so each one shows exactly
 * the placement it is labelled with.
 */
export const Placements: Story = {
  render: () => (
    <div
      style={{
        display: 'grid',
        gridTemplateAreas: PLACEMENT_AREAS,
        gridTemplateColumns: 'repeat(6, minmax(0, 1fr))',
        gridTemplateRows: '180px 140px 140px 140px 180px',
        gap: 24,
        minWidth: 720,
        maxWidth: 840,
      }}
    >
      {PLACEMENTS.map((placement) => (
        <div key={placement} data-popup-cell style={cellStyle(placement)}>
          <Popover
            title="Title"
            content={content}
            placement={placement}
            open
            autoAdjustOverflow={false}
            getPopupContainer={inCell}
          >
            <Button>{placement}</Button>
          </Popover>
        </div>
      ))}
    </div>
  ),
}
