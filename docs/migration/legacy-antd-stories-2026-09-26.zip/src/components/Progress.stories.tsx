import type { Meta, StoryObj } from '@storybook/react-vite'
import { Flex, Progress, Space, Typography, theme } from 'antd'

const meta: Meta<typeof Progress> = {
  component: Progress,
  title: 'Components/Progress',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's progress types — written from the API.
  argTypes: {
    percent: { description: 'Completion percentage, 0–100.', control: 'number' },
    type: { description: 'Visual shape of the progress indicator.', control: 'select', options: ['line', 'circle', 'dashboard'] },
    status: { description: 'Overrides the color/icon to reflect an outcome.', control: 'select', options: ['normal', 'active', 'success', 'exception'] },
    size: { description: "'small' / 'medium', a number (circle diameter), or [width, height] for a line.", control: false },
    steps: { description: 'Splits the bar (or ring) into this many segments. On a circle, `{ count, gap }` also sets the gap.', control: false },
    strokeLinecap: { description: 'End cap of the bar: round (default) or square.', control: 'select', options: ['round', 'square', 'butt'] },
    strokeColor: { description: 'Bar colour; an object of stops (or { from, to }) makes a gradient.', control: false },
    showInfo: { description: 'Whether to show the percentage / status icon.', control: 'boolean' },
    percentPosition: { description: "Where the value sits: { type: 'outer' | 'inner', align: 'start' | 'center' | 'end' }. Outer + center puts it below the bar.", control: false },
  },
}
export default meta
type Story = StoryObj<typeof Progress>

/** Small caption above each example, naming the Figma variant it shows. */
const Label = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ fontSize: 12 }}>
    {children}
  </Typography.Text>
)

export const Line: Story = { args: { percent: 60, 'aria-label': 'Progress', style: { maxWidth: 320 } } }
export const Circle: Story = { args: { type: 'circle', percent: 72, 'aria-label': 'Progress' } }
export const Statuses: Story = {
  render: () => (
    <Space orientation="vertical" style={{ maxWidth: 320 }}>
      <Progress percent={30} aria-label="Progress, normal" />
      <Progress percent={60} status="active" aria-label="Progress, active" />
      <Progress percent={70} status="exception" aria-label="Progress, exception" />
      <Progress percent={100} aria-label="Progress, success" />
      <Progress percent={50} showInfo={false} aria-label="Progress, without info" />
    </Space>
  ),
}

/**
 * Figma `Standard` Size = Small / Medium / Custom. `size="small"` thins the bar
 * and shrinks the text; a `[width, height]` tuple sets a custom width and
 * thickness.
 */
export const LineSizes: Story = {
  render: () => (
    <Space orientation="vertical" size={16} style={{ width: '100%', maxWidth: 400 }}>
      <Label>Small</Label>
      <Progress percent={30} size="small" aria-label="Progress, small" />
      <Label>Medium (default)</Label>
      <Progress percent={30} aria-label="Progress, medium" />
      <Label>Custom width — size={'{[320, 12]}'}</Label>
      <Progress percent={30} size={[320, 12]} aria-label="Progress, custom width" />
    </Space>
  ),
}

/** Figma `Circle` Status = Normal / Exception / Success, at the default and small sizes. */
export const CircleStatuses: Story = {
  render: () => (
    <Space orientation="vertical" size={24}>
      <Flex gap={24} wrap>
        <Progress type="circle" percent={75} aria-label="Circle progress, normal" />
        <Progress type="circle" percent={70} status="exception" aria-label="Circle progress, exception" />
        <Progress type="circle" percent={100} aria-label="Circle progress, success" />
      </Flex>
      <Flex gap={24} wrap>
        <Progress type="circle" percent={75} size="small" aria-label="Small circle progress, normal" />
        <Progress type="circle" percent={70} status="exception" size="small" aria-label="Small circle progress, exception" />
        <Progress type="circle" percent={100} size="small" aria-label="Small circle progress, success" />
      </Flex>
    </Space>
  ),
}

/** Figma `Dashboard`: a circle with a gap at the bottom (`gapDegree` 75 by default). */
export const Dashboard: Story = {
  render: () => (
    <Flex gap={24} wrap>
      <Progress type="dashboard" percent={75} aria-label="Dashboard progress, normal" />
      <Progress type="dashboard" percent={70} status="exception" aria-label="Dashboard progress, exception" />
      <Progress type="dashboard" percent={100} aria-label="Dashboard progress, success" />
    </Flex>
  ),
}

/** Figma `Steps` Status = Normal / Exception / Success: `steps` splits the bar into segments. */
export const Steps: Story = {
  render: () => (
    <Space orientation="vertical" size={16}>
      <Progress percent={50} steps={5} aria-label="Steps progress, normal" />
      <Progress percent={60} steps={5} status="exception" aria-label="Steps progress, exception" />
      <Progress percent={100} steps={5} aria-label="Steps progress, success" />
      <Progress percent={30} steps={5} size="small" aria-label="Steps progress, small" />
    </Space>
  ),
}

/**
 * Figma's "circular custom (segments)" examples — normal / success / error.
 * `steps` on a circle splits the ring; the object form sets the gap between
 * segments.
 */
export const CircleSteps: Story = {
  render: () => (
    <Flex gap={24} wrap>
      <Progress type="circle" percent={50} steps={{ count: 5, gap: 7 }} aria-label="Segmented circle progress, normal" />
      <Progress type="circle" percent={100} steps={{ count: 5, gap: 7 }} aria-label="Segmented circle progress, success" />
      <Progress type="circle" percent={60} steps={{ count: 5, gap: 7 }} status="exception" aria-label="Segmented circle progress, exception" />
    </Flex>
  ),
}

/**
 * Figma's gradient examples. The stops come from theme tokens (primary →
 * success) rather than hard-coded hex, so the gradient follows the brand.
 */
function GradientDemo() {
  const { token } = theme.useToken()
  const twoStops = { '0%': token.colorPrimary, '100%': token.colorSuccess }
  const threeStops = { '0%': token.colorPrimary, '50%': token.colorInfo, '100%': token.colorSuccess }
  return (
    <Space orientation="vertical" size={24} style={{ width: '100%', maxWidth: 400 }}>
      <Label>Line — custom (three stops), small, default</Label>
      <Progress percent={99.9} strokeColor={threeStops} aria-label="Progress, three-stop gradient" />
      <Progress percent={50} size="small" strokeColor={twoStops} aria-label="Progress, small gradient" />
      <Progress percent={70} strokeColor={{ from: token.colorPrimary, to: token.colorSuccess }} aria-label="Progress, primary-to-success gradient" />
      <Label>Circle — normal, success; dashboard</Label>
      <Flex gap={24} wrap>
        <Progress type="circle" percent={90} strokeColor={twoStops} aria-label="Circle progress, gradient" />
        <Progress type="circle" percent={100} strokeColor={twoStops} aria-label="Circle progress, gradient, success" />
        <Progress type="dashboard" percent={90} strokeColor={twoStops} aria-label="Dashboard progress, gradient" />
      </Flex>
    </Space>
  )
}

export const Gradient: Story = {
  render: () => <GradientDemo />,
}

/**
 * Figma's `strokeLinecap` = Round / Square. Round is the default; `square`
 * squares off both the rail and the bar.
 */
export const Linecap: Story = {
  render: () => (
    <Space orientation="vertical" size={24} style={{ width: '100%', maxWidth: 400 }}>
      <Label>Round (default)</Label>
      <Progress percent={75} aria-label="Progress, round cap" />
      <Label>Square</Label>
      <Progress percent={75} strokeLinecap="square" aria-label="Progress, square cap" />
      <Flex gap={24} wrap>
        <Progress type="circle" percent={75} aria-label="Circle progress, round cap" />
        <Progress type="circle" percent={75} strokeLinecap="square" aria-label="Circle progress, square cap" />
        <Progress type="dashboard" percent={75} strokeLinecap="square" aria-label="Dashboard progress, square cap" />
      </Flex>
    </Space>
  ),
}

/**
 * Figma `Value Position`: Position = Outside / Inside × Placement = Start /
 * Center / End / Bottom, via `percentPosition`. "Bottom" is antd's outer +
 * center, which drops the value under the bar. Inside placements need a bar
 * tall enough to hold the text, hence `size={[300, 20]}`.
 */
export const ValuePosition: Story = {
  render: () => (
    <Space orientation="vertical" size={16} style={{ width: '100%', maxWidth: 400 }}>
      <Label>Outside · End (default)</Label>
      <Progress percent={60} aria-label="Progress, outside end" />
      <Label>Outside · Bottom</Label>
      <Progress percent={60} percentPosition={{ align: 'center', type: 'outer' }} aria-label="Progress, outside bottom" />
      <Label>Outside · Success</Label>
      <Progress percent={100} percentPosition={{ align: 'center', type: 'outer' }} aria-label="Progress, outside success" />
      <Label>Inside · Start</Label>
      <Progress percent={50} percentPosition={{ align: 'start', type: 'inner' }} size={[300, 20]} aria-label="Progress, inside start" />
      <Label>Inside · Center</Label>
      <Progress percent={50} percentPosition={{ align: 'center', type: 'inner' }} size={[300, 20]} aria-label="Progress, inside center" />
      <Label>Inside · End</Label>
      <Progress percent={50} percentPosition={{ align: 'end', type: 'inner' }} size={[300, 20]} aria-label="Progress, inside end" />
    </Space>
  ),
}
