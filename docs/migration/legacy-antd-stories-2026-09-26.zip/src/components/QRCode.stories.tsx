import type { Meta, StoryObj } from '@storybook/react-vite'
import { fn } from 'storybook/test'
import { Button, Popover, QRCode } from 'antd'

const meta: Meta<typeof QRCode> = {
  component: QRCode,
  title: 'Components/QRCode',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's qr-code types. `bordered`'s JSDoc
  // is about a different `bordered` prop (in a describes-image comment,
  // not this one) — not copied to avoid attributing the wrong text.
  argTypes: {
    value: { description: 'The text or URL encoded into the QR code.', control: 'text' },
    size: { description: 'Width and height of the QR code, in pixels.', control: 'number' },
    bordered: { description: 'Draws a border/padding around the QR code.', control: 'boolean' },
    status: { description: 'Overlay state: `active` (plain code), `loading`, `expired` (with refresh) or `scanned`.', control: 'select', options: ['active', 'loading', 'expired', 'scanned'] },
    icon: { description: 'Image URL drawn in the centre of the code.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof QRCode>

/**
 * Centre logo as an inline SVG data URI — no network request. The fill is
 * logo artwork, not UI colour.
 */
const LOGO = `data:image/svg+xml;utf8,${encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">' +
    '<rect width="40" height="40" rx="8" fill="#1677FF"/>' +
    '<path d="M14 11h13v4h-9v4h8v4h-8v6h-4z" fill="#fff"/>' +
    '</svg>',
)}`

/**
 * The code is drawn on a `<canvas role="img">`; antd forwards `aria-*` props
 * to it, so `aria-label` is the image's alt text.
 */
const QR_LABEL = 'QR code for https://ipos.vn'

/** Figma `QR Code`, `Type: Basic`. */
export const Default: Story = { args: { value: 'https://ipos.vn', 'aria-label': QR_LABEL } }

export const WithIconSlot: Story = { args: { value: 'https://ipos.vn', 'aria-label': QR_LABEL, size: 160, bordered: true, icon: LOGO, errorLevel: 'H' } }

/**
 * Figma `Type: Popover` — the code lives in a popover off a trigger, the
 * usual "scan to open on your phone" pattern. `bordered={false}` because the
 * popover surface already frames it. Hover the button.
 */
export const InPopover: Story = {
  render: () => (
    <Popover content={<QRCode value="https://ipos.vn" aria-label={QR_LABEL} bordered={false} />}>
      <Button>Scan to open on mobile</Button>
    </Popover>
  ),
}

/** Figma `Type: Loading` — `status="loading"` covers the code with a spinner. */
export const Loading: Story = { args: { value: 'https://ipos.vn', 'aria-label': QR_LABEL, status: 'loading' } }

/**
 * Figma `Type: Expired` — `status="expired"` greys the code out; passing
 * `onRefresh` adds antd's Refresh button to the overlay (logged in Actions).
 */
export const Expired: Story = {
  args: { value: 'https://ipos.vn', 'aria-label': QR_LABEL, status: 'expired', onRefresh: fn() },
}
