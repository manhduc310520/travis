import { useState } from 'react'
import type { ReactNode } from 'react'
import type { Meta, StoryObj } from '@storybook/react-vite'
import { Flex, Rate, Typography } from 'antd'
import { Heart } from '../icons'

const meta: Meta<typeof Rate> = {
  component: Rate,
  title: 'Components/Rate',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's rate types — written from the API.
  argTypes: {
    defaultValue: { description: 'Rating shown on initial render (uncontrolled).', control: 'number' },
    allowHalf: { description: 'Allows selecting a half-star value.', control: 'boolean' },
    disabled: { description: 'Disables the rating (read-only display).', control: 'boolean' },
    size: { description: 'Star size: small, medium (default) or large.', control: 'select', options: ['small', 'medium', 'large'] },
    tooltips: { description: 'One tooltip per star, shown on hover.', control: false },
    character: { description: 'Replaces the star glyph — text, an icon, or a function of the star index.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Rate>

/** Caption beside each control, matching how the Figma docs frame labels every example. */
function Labeled({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Flex gap={16} align="center">
      <Typography.Text type="secondary" style={{ width: 64 }}>{label}</Typography.Text>
      {children}
    </Flex>
  )
}

export const Default: Story = { args: { defaultValue: 4 } }
export const HalfStar: Story = { args: { allowHalf: true, defaultValue: 3.5 } }
export const Disabled: Story = { args: { defaultValue: 4, disabled: true } }

const HALF_STEPS = Array.from({ length: 11 }, (_, i) => i / 2)

/**
 * Figma's `Rate` set has one variant per half step, 0 → 5, and the docs
 * frame shows every one of them. Rendered read-only (`disabled`) so each
 * caption keeps matching its stars — a clickable copy would drift from its
 * label the moment someone clicked it.
 */
export const AllValues: Story = {
  render: () => (
    <Flex vertical gap={8}>
      {HALF_STEPS.map((value) => (
        <Labeled key={value} label={String(value)}>
          <Rate allowHalf disabled value={value} />
        </Labeled>
      ))}
    </Flex>
  ),
}

const DESCRIPTIONS = ['Terrible', 'Bad', 'Normal', 'Good', 'Wonderful']

/**
 * Figma `Text?` boolean: a word describing the current score sits after the
 * stars. The same words are passed as `tooltips`, so hovering a star
 * previews the label before it's picked.
 */
function WithTextDemo() {
  const [value, setValue] = useState(3)
  return (
    <Flex gap={8} align="center">
      <Rate tooltips={DESCRIPTIONS} value={value} onChange={setValue} />
      {value ? <Typography.Text>{DESCRIPTIONS[value - 1]}</Typography.Text> : null}
    </Flex>
  )
}

export const WithText: Story = {
  render: () => <WithTextDemo />,
  parameters: { docs: { source: { code: '() => <WithTextDemo />' } } },
}

/** Figma's star `Size` property: small / default / large. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={8}>
      <Labeled label="Small">
        <Rate size="small" defaultValue={3} />
      </Labeled>
      <Labeled label="Medium">
        <Rate defaultValue={3} />
      </Labeled>
      <Labeled label="Large">
        <Rate size="large" defaultValue={3} />
      </Labeled>
    </Flex>
  ),
}

/**
 * `character` swaps the star for any glyph: an icon from the project set,
 * a letter, or a function of the star's index. Not a separate Figma
 * variant — shown because it's how the `Text?` idea extends to the stars
 * themselves.
 *
 * Each star is a `role="radio"` named by its content, and an icon has no
 * text — so the icon is passed through the function form and exposed as a
 * named image (Untitled UI icons ship `aria-hidden`, hence `aria-hidden={false}`).
 */
export const CustomCharacter: Story = {
  render: () => (
    <Flex vertical gap={8}>
      <Labeled label="Icon">
        <Rate
          character={({ index = 0 }) => (
            <Heart size={20} role="img" aria-hidden={false} aria-label={`${index + 1} heart${index ? 's' : ''}`} />
          )}
          allowHalf
          defaultValue={2.5}
        />
      </Labeled>
      <Labeled label="Letter">
        <Rate character="A" allowHalf defaultValue={2.5} />
      </Labeled>
      <Labeled label="Index">
        <Rate character={({ index = 0 }) => index + 1} defaultValue={3} />
      </Labeled>
    </Flex>
  ),
}
