import type { Meta, StoryObj } from '@storybook/react-vite'
import { Result, Button, Space } from 'antd'
import { componentTokens } from '../theme/componentTokens'
import { AlertCircle, CheckCircle, InfoCircle, Star01, XCircle } from '../icons'

/**
 * Same circle icons as the Alert stories (Figma `check-circle-line`,
 * `x-circle-line`, `info-circle-line`, `alert-circle-line`) instead of antd's
 * filled glyphs. Result colours its icon wrapper per status, so the svg only
 * needs its size: antd applies `Result.iconFontSize` to `.anticon` children
 * only, so it is read from the same component token and passed explicitly.
 * 403 / 404 / 500 render antd's illustrations and ignore `icon`.
 */
const ICON_SIZE = componentTokens.Result.iconFontSize
const ICONS = {
  success: <CheckCircle size={ICON_SIZE} />,
  error: <XCircle size={ICON_SIZE} />,
  info: <InfoCircle size={ICON_SIZE} />,
  warning: <AlertCircle size={ICON_SIZE} />,
} as const

const meta: Meta<typeof Result> = {
  component: Result,
  title: 'Components/Result',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's result types — written from the API.
  argTypes: {
    status: {
      description: 'Icon and color preset. HTTP-code values (403/404/500) render that code as the icon.',
      control: 'select',
      options: ['success', 'error', 'info', 'warning', '404', '403', '500'],
    },
    title: { description: 'Main heading.', control: 'text' },
    subTitle: { description: 'Supporting text under the title.', control: 'text' },
    extra: { description: 'Actions rendered below the text (e.g. buttons).', control: false },
    icon: { description: 'Custom icon; replaces the status icon (ignored for 403/404/500).', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Result>

/** Figma `Status=Success`. One primary action; the secondary one is a default button. */
export const Success: Story = {
  args: {
    status: 'success',
    icon: ICONS.success,
    title: 'Successfully Submitted!',
    subTitle: 'Your request has been processed successfully.',
    extra: (
      <Space size={8}>
        <Button type="primary">Go Back</Button>
        <Button>Buy Again</Button>
      </Space>
    ),
  },
}

/** Figma `Status=Info`. */
export const Info: Story = {
  args: {
    status: 'info',
    icon: ICONS.info,
    title: 'Your operation has been executed',
    extra: <Button type="primary">Go Console</Button>,
  },
}

/** Figma `Status=Warning`. */
export const Warning: Story = {
  args: {
    status: 'warning',
    icon: ICONS.warning,
    title: 'There are some problems with your operation.',
    extra: <Button type="primary">Go Console</Button>,
  },
}

/** Figma `Status=Error`. */
export const ErrorState: Story = {
  args: {
    status: 'error',
    icon: ICONS.error,
    title: 'Submission Failed',
    subTitle: 'Please check and modify the information before resubmitting.',
    extra: (
      <Space size={8}>
        <Button type="primary">Go Console</Button>
        <Button>Buy Again</Button>
      </Space>
    ),
  },
}

/** Figma `Status=403`. */
export const Forbidden: Story = {
  args: {
    status: '403',
    title: '403',
    subTitle: 'Sorry, you are not authorized to access this page.',
    extra: <Button type="primary">Back Home</Button>,
  },
}

/** Figma `Status=404`. */
export const NotFound: Story = {
  args: {
    status: '404',
    title: '404',
    subTitle: 'Sorry, the page you visited does not exist.',
    extra: <Button type="primary">Back Home</Button>,
  },
}

/** Figma `Status=500`. */
export const ServerError: Story = {
  args: {
    status: '500',
    title: '500',
    subTitle: 'Sorry, something went wrong.',
    extra: <Button type="primary">Back Home</Button>,
  },
}

/**
 * Figma `Status=Custom icon`: any node in `icon`. With no `status` antd falls
 * back to `info`, so the icon takes the info colour.
 */
export const CustomIcon: Story = {
  args: {
    icon: <Star01 size={ICON_SIZE} />,
    title: 'Great, we have done all the operations!',
    extra: <Button type="primary">Next</Button>,
  },
}
