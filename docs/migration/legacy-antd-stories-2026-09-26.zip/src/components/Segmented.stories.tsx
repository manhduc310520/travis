import type { ReactNode } from 'react'
import type { Meta, StoryObj } from '@storybook/react-vite'
import { Flex, Segmented, Typography } from 'antd'
import { Columns03, Grid01, Menu02 } from '../icons'

const meta: Meta<typeof Segmented> = {
  component: Segmented,
  title: 'Components/Segmented',
  tags: ['ai-generated', 'needs-work'],
  // `block`'s description is antd's own JSDoc from segmented/index.d.ts,
  // copied as-is. `options`/`disabled` have no JSDoc there; nor do `shape`,
  // `orientation` or `size` — written from the API.
  argTypes: {
    options: { description: 'The list of segments.', control: false },
    block: { description: "Option to fit width to its parent's width.", control: 'boolean' },
    disabled: { description: 'Disables the whole control.', control: 'boolean' },
    shape: { description: "'round' gives the track and the selected thumb fully rounded ends.", control: 'select', options: ['default', 'round'] },
    orientation: { description: 'Stacks the segments in a row or a column.', control: 'select', options: ['horizontal', 'vertical'] },
    size: { description: 'Control height: small, medium (default) or large.', control: 'select', options: ['small', 'medium', 'large'] },
  },
}
export default meta
type Story = StoryObj<typeof Segmented>

const options = ['Daily', 'Weekly', 'Monthly']

/** Caption above each control, matching how the Figma docs frame labels every example. */
function Labeled({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Flex vertical gap={4} align="start">
      <Typography.Text type="secondary">{label}</Typography.Text>
      {children}
    </Flex>
  )
}

export const Default: Story = { args: { options, defaultValue: 'Weekly' } }
export const Block: Story = { args: { options, block: true, style: { maxWidth: 360 } } }
export const Disabled: Story = { args: { options, disabled: true } }

/** Figma `Shape: Round` — one of the four docs examples. */
export const Round: Story = { args: { options, shape: 'round', defaultValue: 'Weekly' } }

/**
 * Figma `Vertical: True`, plain and with `Block` (the docs frame's "block
 * vertical" example — segments stretch to the column's width).
 */
export const Vertical: Story = {
  render: () => (
    <Flex gap={32} align="start">
      <Labeled label="Vertical">
        <Segmented orientation="vertical" options={options} defaultValue="Weekly" />
      </Labeled>
      <Labeled label="Vertical, block">
        <div style={{ width: 200 }}>
          <Segmented orientation="vertical" block options={options} defaultValue="Weekly" />
        </div>
      </Labeled>
    </Flex>
  ),
}

/**
 * Figma item `Icon?` / `Label?` booleans: icon + label, and icon only. An
 * icon-only segment has no visible text, so each one carries a `tooltip`
 * naming it. The tooltip doesn't name the radio inside the segment, though —
 * its `<label>` content does — so each icon is also exposed as a named image
 * (Untitled UI icons ship `aria-hidden`, hence `aria-hidden={false}`).
 */
export const WithIcons: Story = {
  render: () => (
    <Flex vertical gap={16}>
      <Labeled label="Icon + label">
        <Segmented
          defaultValue="list"
          options={[
            { value: 'list', label: 'List', icon: <Menu02 /> },
            { value: 'board', label: 'Board', icon: <Columns03 /> },
            { value: 'grid', label: 'Grid', icon: <Grid01 /> },
          ]}
        />
      </Labeled>
      <Labeled label="Icon only">
        <Segmented
          defaultValue="list"
          options={[
            { value: 'list', icon: <Menu02 role="img" aria-hidden={false} aria-label="List" />, tooltip: 'List' },
            { value: 'board', icon: <Columns03 role="img" aria-hidden={false} aria-label="Board" />, tooltip: 'Board' },
            { value: 'grid', icon: <Grid01 role="img" aria-hidden={false} aria-label="Grid" />, tooltip: 'Grid' },
          ]}
        />
      </Labeled>
    </Flex>
  ),
}

/** Figma item `Disabled`: one segment unavailable while the rest stay selectable. */
export const DisabledItem: Story = {
  args: {
    defaultValue: 'Daily',
    options: [
      { value: 'Daily', label: 'Daily' },
      { value: 'Weekly', label: 'Weekly', disabled: true },
      { value: 'Monthly', label: 'Monthly' },
    ],
  },
}

/** Figma `Size`: small / medium (default) / large. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      <Labeled label="Small">
        <Segmented size="small" options={options} defaultValue="Weekly" />
      </Labeled>
      <Labeled label="Medium (default)">
        <Segmented options={options} defaultValue="Weekly" />
      </Labeled>
      <Labeled label="Large">
        <Segmented size="large" options={options} defaultValue="Weekly" />
      </Labeled>
    </Flex>
  ),
}
