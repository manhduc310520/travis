import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState, type ReactNode } from 'react'
import { Flex, Select, Typography, theme } from 'antd'
import { ChevronDown, User01 } from '../icons'

const meta: Meta<typeof Select> = {
  component: Select,
  title: 'Components/Select',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's select/index.d.ts — written from the API
  // surface. `mode` options are the public SelectProps union ('multiple' |
  // 'tags') — the internal type also lists 'combobox' and a
  // SECRET_COMBOBOX constant, neither of which is part of the public API.
  argTypes: {
    options: { description: 'The list of selectable options.', control: false },
    mode: {
      description: 'Set to allow multiple selections; "tags" also lets the user type a value not in options.',
      control: 'select',
      options: [undefined, 'multiple', 'tags'],
    },
    showSearch: { description: 'Whether the typed input filters the option list.', control: 'boolean' },
    disabled: { description: 'Disables the select.', control: 'boolean' },
    status: {
      description: 'Validation state — colors the border and focus ring.',
      control: 'select',
      options: ['', 'warning', 'error'],
    },
    size: { description: 'Control height: small, middle (the 32px default) or large.', control: 'select', options: ['small', 'middle', 'large'] },
    variant: {
      description: 'Visual style of the field.',
      control: 'select',
      options: ['outlined', 'filled', 'borderless', 'underlined'],
    },
    prefix: { description: 'Content rendered before the value, inside the field.', control: false },
    maxCount: { description: 'Caps how many options can be picked in multiple/tags mode.', control: 'number' },
    placement: {
      description: 'Where the menu opens relative to the field.',
      control: 'select',
      options: ['bottomLeft', 'bottomRight', 'topLeft', 'topRight'],
    },
    open: { description: 'Controls whether the menu is shown.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Select>

const options = [
  { value: 'all', label: 'All' },
  { value: 'option-1', label: 'Option 1' },
  { value: 'option-2', label: 'Option 2' },
  { value: 'option-3', label: 'Option 3' },
]

const VARIANTS = ['outlined', 'filled', 'borderless', 'underlined'] as const
const SIZES = [
  { size: 'small', label: 'Small' },
  { size: 'middle', label: 'Default' },
  { size: 'large', label: 'Large' },
] as const

/** Secondary 12px caption naming the Figma variant an example stands for. */
function Caption({ children, width }: { children: ReactNode; width?: number }) {
  const { token } = theme.useToken()
  return (
    <Typography.Text type="secondary" style={{ fontSize: token.fontSizeSM, width, flexShrink: 0 }}>
      {children}
    </Typography.Text>
  )
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Flex gap={16} align="center" wrap>
      <Caption width={96}>{label}</Caption>
      {children}
    </Flex>
  )
}

/**
 * Menus shown open for display portal into this box instead of `document.body`
 * (see `inFrame`), and the box reserves room for them — so neighbouring
 * examples never overlap and the Docs page scrolls them with their field.
 * `top*` placements sit the field at the bottom of the box, `*Right` at its
 * right edge, leaving the menu room on the side it opens toward.
 */
function PopupFrame({
  label,
  placement = 'bottomLeft',
  width = 240,
  height = 240,
  children,
}: {
  label: string
  placement?: 'bottomLeft' | 'bottomRight' | 'topLeft' | 'topRight'
  width?: number
  height?: number
  children: ReactNode
}) {
  return (
    <Flex vertical gap={4} style={{ width }}>
      <Caption>{label}</Caption>
      <Flex
        data-popup-frame=""
        align={placement.startsWith('top') ? 'flex-end' : 'flex-start'}
        justify={placement.endsWith('Right') ? 'flex-end' : 'flex-start'}
        style={{ position: 'relative', height }}
      >
        {children}
      </Flex>
    </Flex>
  )
}
const inFrame = (node: HTMLElement) => node.closest<HTMLElement>('[data-popup-frame]') ?? document.body
/** Pins the placement: by default the menu flips when it would leave the viewport, so a "Top" example could open downward mid-scroll. */
const pinned = { overflow: { adjustX: false, adjustY: false } }

export const Default: Story = { args: { options, defaultValue: 'all', 'aria-label': 'Basic select', style: { width: 240 } } }
export const Multiple: Story = { args: { options, mode: 'multiple', defaultValue: ['option-1', 'option-2'], 'aria-label': 'Multiple select', style: { maxWidth: 320 } } }
export const Searchable: Story = { args: { options, showSearch: true, placeholder: 'Search to Select', 'aria-label': 'Search select', style: { width: 240 } } }
export const Disabled: Story = { args: { options, defaultValue: 'all', disabled: true, 'aria-label': 'Basic select', style: { width: 240 } } }
export const Invalid: Story = { args: { options, status: 'error', placeholder: 'Please select', 'aria-label': 'Basic select', style: { width: 240 } } }

/** Figma `Size` × `Type[Basic|Multiple|Search]`. `middle` is antd's name for the 32px default. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {SIZES.map(({ size, label }) => (
        <Row key={size} label={label}>
          <Select size={size} options={options} defaultValue="all" aria-label={`Basic select, ${label.toLowerCase()}`} style={{ width: 200 }} />
          <Select size={size} options={options} mode="multiple" defaultValue={['option-1', 'option-2']} aria-label={`Multiple select, ${label.toLowerCase()}`} style={{ width: 240 }} />
          <Select size={size} options={options} showSearch placeholder="Search to Select" aria-label={`Search select, ${label.toLowerCase()}`} style={{ width: 200 }} />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma's four input sets — Outlined / Filled / Borderless / Underlined — each with `Type[Basic|Multiple|Search]`. */
export const Variants: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {VARIANTS.map((variant) => (
        <Row key={variant} label={variant[0].toUpperCase() + variant.slice(1)}>
          <Select variant={variant} options={options} defaultValue="all" aria-label={`Basic select, ${variant}`} style={{ width: 200 }} />
          <Select variant={variant} options={options} mode="multiple" defaultValue={['option-1', 'option-2']} aria-label={`Multiple select, ${variant}`} style={{ width: 240 }} />
          <Select variant={variant} options={options} showSearch placeholder="Search to Select" aria-label={`Search select, ${variant}`} style={{ width: 200 }} />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma `Status[Error|Warning]` on every input set. */
export const Status: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {VARIANTS.map((variant) => (
        <Row key={variant} label={variant[0].toUpperCase() + variant.slice(1)}>
          <Select variant={variant} status="error" options={options} placeholder="Error" aria-label={`Basic select, ${variant}, error`} style={{ width: 200 }} />
          <Select variant={variant} status="warning" options={options} placeholder="Warning" aria-label={`Basic select, ${variant}, warning`} style={{ width: 200 }} />
          <Select variant={variant} status="error" options={options} mode="multiple" defaultValue={['option-1']} aria-label={`Multiple select, ${variant}, error`} style={{ width: 240 }} />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma's prefix slot: an icon or a short text label inside the field, before the value. */
export const WithPrefix: Story = {
  render: () => (
    <Flex gap={16} wrap>
      <Select prefix={<User01 />} options={options} defaultValue="all" aria-label="Basic select, icon prefix" style={{ width: 200 }} />
      <Select prefix="Status" options={options} defaultValue="all" aria-label="Status" style={{ width: 200 }} />
      <Select prefix={<User01 />} options={options} mode="multiple" defaultValue={['option-1', 'option-2']} aria-label="Multiple select, icon prefix" style={{ width: 280 }} />
    </Flex>
  ),
}

/**
 * Figma's `max count` input. `maxCount` disables the remaining options once
 * the cap is reached; the running count sits beside the arrow so the limit
 * is visible before the user hits it.
 */
function MaxCountDemo() {
  const MAX_COUNT = 3
  const [value, setValue] = useState<string[]>(['option-1', 'option-2'])
  return (
    <Select
      mode="multiple"
      maxCount={MAX_COUNT}
      value={value}
      onChange={setValue}
      options={options}
      placeholder="Please select"
      aria-label={`Multiple select, up to ${MAX_COUNT}`}
      suffixIcon={
        <Flex align="center" gap={4}>
          {value.length} / {MAX_COUNT}
          <ChevronDown />
        </Flex>
      }
      style={{ width: 320 }}
    />
  )
}

export const MaxCount: Story = {
  render: () => <MaxCountDemo />,
}

/** Figma examples "open bottom" and "open top" (`Placement[Bottom|Top]`), rendered statically open. */
export const Placements: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Placement: Bottom">
        <Select open placement="bottomLeft" popupAlign={pinned} getPopupContainer={inFrame} options={options} defaultValue="option-1" aria-label="Basic select, placement bottom" style={{ width: 240 }} />
      </PopupFrame>
      <PopupFrame label="Placement: Top" placement="topLeft">
        <Select open placement="topLeft" popupAlign={pinned} getPopupContainer={inFrame} options={options} defaultValue="option-1" aria-label="Basic select, placement top" style={{ width: 240 }} />
      </PopupFrame>
    </Flex>
  ),
}

/** Figma's empty menu: an open Select with nothing to choose shows the Empty placeholder. */
export const EmptyMenu: Story = {
  render: () => (
    <PopupFrame label="Menu: Empty" height={200}>
      <Select open popupAlign={pinned} getPopupContainer={inFrame} options={[]} placeholder="Please select" aria-label="Basic select, empty menu" style={{ width: 240 }} />
    </PopupFrame>
  ),
}
