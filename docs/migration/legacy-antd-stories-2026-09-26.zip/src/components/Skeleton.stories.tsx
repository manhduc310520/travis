import type { Meta, StoryObj } from '@storybook/react-vite'
import { Flex, Skeleton, Space, Typography, theme } from 'antd'
import { PieChart01 } from '../icons'

const meta: Meta<typeof Skeleton> = {
  component: Skeleton,
  title: 'Components/Skeleton',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's Skeleton.d.ts — written from the API.
  argTypes: {
    avatar: { description: 'Shows a placeholder avatar (true), or pass config to customize its shape/size.', control: 'boolean' },
    paragraph: { description: 'Shows placeholder text lines (true), or pass { rows } to set how many.', control: false },
    active: { description: 'Animates the placeholder with a shimmer effect.', control: 'boolean' },
    title: { description: 'Shows the placeholder title bar (true), or pass { width } to size it.', control: false },
    round: { description: 'Rounds the ends of the title and paragraph bars.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Skeleton>

/** Small caption naming the Figma variant each example shows. */
const Label = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ fontSize: 12 }}>
    {children}
  </Typography.Text>
)

/**
 * Figma image Type = Dot Chart, via `Skeleton.Node`. Sized like antd's own
 * `Skeleton.Image` glyph (`controlHeight × 1.5`) and tinted with the faintest
 * text token so it reads as a placeholder in both modes.
 */
function ChartPlaceholder() {
  const { token } = theme.useToken()
  return (
    <Skeleton.Node>
      <PieChart01 size={token.controlHeight * 1.5} style={{ color: token.colorTextQuaternary }} />
    </Skeleton.Node>
  )
}

/** Figma `Type=Basic`: title bar + paragraph lines. */
export const Default: Story = { args: { style: { maxWidth: 480 } } }
/** Figma `Type=Complex`: avatar beside the title and paragraph. */
export const WithAvatar: Story = { args: { avatar: true, paragraph: { rows: 3 }, style: { maxWidth: 480 } } }
export const Active: Story = { args: { active: true, style: { maxWidth: 480 } } }

/**
 * The building blocks Figma's `Input?` / `Button?` / `Images?` toggles add:
 * `Skeleton.Button` (Shape Default / Round / Circle × Size), `Skeleton.Input`
 * (Size), `Skeleton.Avatar` (Shape × Size) and `Skeleton.Image` / `Skeleton.Node`
 * (Figma image Type = Image / Dot Chart). The icon set has no dot-chart glyph,
 * so the Node uses the closest chart icon.
 */
export const Elements: Story = {
  render: () => (
    <Space orientation="vertical" size={24}>
      <Space orientation="vertical" size={8}>
        <Label>Button — Shape Default / Round / Circle × Size Small / Medium / Large</Label>
        {(['small', 'medium', 'large'] as const).map((size) => (
          <Flex key={size} gap={16} align="center">
            <Skeleton.Button size={size} />
            <Skeleton.Button size={size} shape="round" />
            <Skeleton.Button size={size} shape="circle" />
          </Flex>
        ))}
      </Space>
      <Space orientation="vertical" size={8}>
        <Label>Input — Size Small / Medium / Large</Label>
        <Skeleton.Input size="small" />
        <Skeleton.Input />
        <Skeleton.Input size="large" />
      </Space>
      <Space orientation="vertical" size={8}>
        <Label>Avatar — Shape Circle / Square × Size Small / Medium / Large</Label>
        {(['circle', 'square'] as const).map((shape) => (
          <Flex key={shape} gap={16} align="center">
            <Skeleton.Avatar shape={shape} size="small" />
            <Skeleton.Avatar shape={shape} />
            <Skeleton.Avatar shape={shape} size="large" />
          </Flex>
        ))}
      </Space>
      <Space orientation="vertical" size={8}>
        <Label>Image — Type Image / Dot Chart</Label>
        <Flex gap={16}>
          <Skeleton.Image />
          <ChartPlaceholder />
        </Flex>
      </Space>
    </Space>
  ),
}

/**
 * Figma's seven docs examples, composed from `Skeleton` (Basic = title +
 * paragraph, Complex = + avatar) and the elements above.
 */
export const Compositions: Story = {
  render: () => {
    const examples: { label: string; node: React.ReactNode }[] = [
      { label: 'Basic', node: <Skeleton /> },
      {
        label: 'Basic + Input + Image',
        node: (
          <Flex gap={16}>
            <Skeleton.Image />
            <Flex vertical gap={16} flex={1}>
              <Skeleton paragraph={{ rows: 2 }} />
              <Skeleton.Input block />
            </Flex>
          </Flex>
        ),
      },
      {
        label: 'Complex + Input',
        node: (
          <Flex vertical gap={16}>
            <Skeleton avatar paragraph={{ rows: 2 }} />
            <Skeleton.Input block />
          </Flex>
        ),
      },
      {
        label: 'Complex + Image + Input',
        node: (
          <Flex vertical gap={16}>
            <Skeleton avatar paragraph={{ rows: 2 }} />
            <Flex gap={16} align="end">
              <Skeleton.Image />
              <Skeleton.Input />
            </Flex>
          </Flex>
        ),
      },
      { label: 'Complex', node: <Skeleton avatar paragraph={{ rows: 4 }} /> },
      {
        label: 'Image + Button',
        node: (
          <Flex gap={16} align="end">
            <Skeleton.Image />
            <Skeleton.Button />
          </Flex>
        ),
      },
      {
        label: 'Complex + Input + Button',
        node: (
          <Flex vertical gap={16}>
            <Skeleton avatar paragraph={{ rows: 2 }} />
            <Flex gap={16}>
              <Skeleton.Input />
              <Skeleton.Button />
            </Flex>
          </Flex>
        ),
      },
    ]
    return (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 32 }}>
        {examples.map(({ label, node }) => (
          <Flex key={label} vertical gap={8}>
            <Label>{label}</Label>
            {node}
          </Flex>
        ))}
      </div>
    )
  },
}

/** `active` on the elements too — every placeholder shimmers. */
export const ActiveElements: Story = {
  render: () => (
    <Flex vertical gap={16} style={{ maxWidth: 480 }}>
      <Skeleton active avatar paragraph={{ rows: 2 }} />
      <Flex gap={16} align="center">
        <Skeleton.Button active />
        <Skeleton.Input active />
        <Skeleton.Avatar active />
      </Flex>
      <Skeleton.Image active />
    </Flex>
  ),
}
