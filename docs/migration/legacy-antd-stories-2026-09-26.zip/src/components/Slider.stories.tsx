import { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react-vite'
import { Flex, InputNumber, Slider, theme } from 'antd'
import { Eye, EyeOff } from '../icons'

const meta: Meta<typeof Slider> = {
  component: Slider,
  title: 'Components/Slider',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's slider types — written from the API.
  argTypes: {
    range: { description: 'Selects a span (two handles) instead of a single value.', control: 'boolean' },
    marks: { description: 'Labeled tick marks at specific values.', control: false },
    disabled: { description: 'Disables the slider.', control: 'boolean' },
    orientation: { description: 'Lays the track out left-to-right or bottom-to-top.', control: 'select', options: ['horizontal', 'vertical'] },
    reverse: { description: 'Flips the direction the track fills from.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Slider>

const MARKS = { 0: '0', 25: '25', 50: '50', 75: '75', 100: '100' }

/**
 * Handles are `role="slider"` with no visible label, so each slider names them
 * through `ariaLabelForHandle` — a string, or one per handle for a range.
 */
const RANGE_LABELS = ['Range start', 'Range end']

export const Default: Story = { args: { defaultValue: 40, ariaLabelForHandle: 'Value', style: { maxWidth: 320 } } }
export const RangeMode: Story = { args: { range: true, defaultValue: [20, 60], ariaLabelForHandle: RANGE_LABELS, style: { maxWidth: 320 } } }
export const WithMarks: Story = {
  args: { defaultValue: 50, ariaLabelForHandle: 'Value', style: { maxWidth: 320 }, marks: { 0: '0', 50: '50', 100: '100' } },
}
export const Disabled: Story = { args: { defaultValue: 40, disabled: true, ariaLabelForHandle: 'Value', style: { maxWidth: 320 } } }

/**
 * Figma `Slider / Basic`, `Vertical: True` — single, range, range with
 * marks, and `Reverse: True` on the vertical axis. A vertical slider takes
 * its parent's height, so the row has a fixed one.
 */
export const Vertical: Story = {
  render: () => (
    <Flex gap={48} style={{ height: 240 }}>
      <Slider orientation="vertical" defaultValue={30} ariaLabelForHandle="Value" />
      <Slider orientation="vertical" range defaultValue={[20, 50]} ariaLabelForHandle={RANGE_LABELS} />
      <Slider orientation="vertical" range marks={MARKS} defaultValue={[25, 75]} ariaLabelForHandle={RANGE_LABELS} />
      <Slider orientation="vertical" reverse defaultValue={30} ariaLabelForHandle="Value" />
    </Flex>
  ),
}

/** Figma `Slider / Basic`, `Reverse: True`: the track fills from the right. */
export const Reverse: Story = {
  render: () => (
    <Flex vertical gap={16} style={{ maxWidth: 320 }}>
      <Slider reverse defaultValue={30} ariaLabelForHandle="Value" />
      <Slider reverse range defaultValue={[20, 50]} ariaLabelForHandle={RANGE_LABELS} />
    </Flex>
  ),
}

/**
 * Figma's "with icons" example: an icon at each end of the track, the one
 * nearer the current value drawn at full text colour and the other faded —
 * antd's own "Slider with icon" demo. Its frown / smile icons aren't in this
 * project's Untitled UI set, so `EyeOff` / `Eye` (an opacity scale) stand in.
 * Colours come from theme tokens so they follow dark mode.
 */
function WithIconsDemo() {
  const { token } = theme.useToken()
  const [value, setValue] = useState(30)
  const nearStart = value < 50
  return (
    <Flex align="center" gap={8} style={{ maxWidth: 320 }}>
      <EyeOff color={nearStart ? token.colorText : token.colorTextQuaternary} />
      <Slider value={value} onChange={setValue} ariaLabelForHandle="Opacity" style={{ flex: 1 }} />
      <Eye color={nearStart ? token.colorTextQuaternary : token.colorText} />
    </Flex>
  )
}

export const WithIcons: Story = {
  render: () => <WithIconsDemo />,
  parameters: { docs: { source: { code: '() => <WithIconsDemo />' } } },
}

/**
 * Figma's "with InputNumber" example: slider and number field share one
 * value, so dragging updates the field and typing moves the handle. Shown
 * for an integer and a decimal (`step={0.01}`) range, as antd's own demo does.
 */
function WithInputNumberDemo() {
  const [integer, setInteger] = useState(1)
  const [decimal, setDecimal] = useState(0.5)
  return (
    <Flex vertical gap={16} style={{ maxWidth: 400 }}>
      <Flex align="center" gap={16}>
        <Slider min={1} max={20} value={integer} onChange={setInteger} ariaLabelForHandle="Integer value" style={{ flex: 1 }} />
        <InputNumber min={1} max={20} value={integer} onChange={(v) => setInteger(v ?? 1)} aria-label="Integer value" />
      </Flex>
      <Flex align="center" gap={16}>
        <Slider min={0} max={1} step={0.01} value={decimal} onChange={setDecimal} ariaLabelForHandle="Decimal value" style={{ flex: 1 }} />
        <InputNumber min={0} max={1} step={0.01} value={decimal} onChange={(v) => setDecimal(v ?? 0)} aria-label="Decimal value" />
      </Flex>
    </Flex>
  )
}

export const WithInputNumber: Story = {
  render: () => <WithInputNumberDemo />,
  parameters: { docs: { source: { code: '() => <WithInputNumberDemo />' } } },
}
