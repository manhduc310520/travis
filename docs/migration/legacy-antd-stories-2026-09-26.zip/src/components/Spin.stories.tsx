import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Alert, Flex, Spin, Space, Card, Switch, Typography, theme } from 'antd'
import { InfoCircle } from '../icons'

const meta: Meta<typeof Spin> = {
  component: Spin,
  title: 'Components/Spin',
  tags: ['ai-generated', 'needs-work'],
  // Every story uses a custom `render`, none set `args` — the Docs page's
  // argTypes table only renders once at least one arg exists. No JSDoc on
  // these in antd's spin types — written from the API. (`tip` is the
  // deprecated predecessor of `description`, already noted elsewhere in
  // this project's AntD-v6-renamed-props fixes — not re-documented here.
  // Likewise `size="default"`: antd 6.6.5 deprecates it for `"medium"`.)
  args: { size: 'medium' },
  argTypes: {
    size: { description: 'Size of the spinner.', control: 'select', options: ['small', 'medium', 'large'] },
    description: { description: 'Text shown below the spinner.', control: 'text' },
    spinning: { description: 'Whether the spinner (and, when nested, the dimming overlay) is shown.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Spin>

/** Figma `Size` = Small / Medium / Large, `Tip?` = false. Medium is antd's default size. */
export const Sizes: Story = {
  render: () => (
    <Space size="large">
      <Spin size="small" />
      <Spin />
      <Spin size="large" />
    </Space>
  ),
}

/**
 * Figma `Tip?` = true at each size. In antd 6 `description` renders under a
 * standalone spinner too (v5's `tip` only worked when nested).
 */
export const SizesWithDescription: Story = {
  render: () => (
    <Space size={48} align="start">
      <Spin size="small" description="Loading" />
      <Spin description="Loading" />
      <Spin size="large" description="Loading" />
    </Space>
  ),
}

export const WithTip: Story = {
  render: () => (
    <Spin description="Loading...">
      <Card style={{ maxWidth: 320, height: 120 }} />
    </Spin>
  ),
}

/**
 * Figma's "inside a container" example: a spinner centred in a tinted block,
 * standing in for a region whose content hasn't arrived yet. Fill and radius
 * come from theme tokens.
 */
function InsideContainerDemo() {
  const { token } = theme.useToken()
  return (
    <Flex
      align="center"
      justify="center"
      style={{ maxWidth: 480, padding: token.paddingXL, background: token.colorFillSecondary, borderRadius: token.borderRadiusLG }}
    >
      <Spin />
    </Flex>
  )
}

export const InsideContainer: Story = {
  render: () => <InsideContainerDemo />,
}

/**
 * Nested: wrapping content in `<Spin>` dims it and overlays the spinner while
 * `spinning` is true. Toggle to see the content settle.
 */
function NestedDemo() {
  const [loading, setLoading] = useState(true)
  return (
    <Flex vertical gap={16} style={{ maxWidth: 480 }}>
      <Spin spinning={loading} description="Loading...">
        <Alert
          type="info"
          showIcon
          icon={<InfoCircle />}
          title="Alert message title"
          description="Further details about the context of this alert."
        />
      </Spin>
      <Space size={8}>
        <Typography.Text>Loading state:</Typography.Text>
        <Switch checked={loading} onChange={setLoading} aria-label="Loading state" />
      </Space>
    </Flex>
  )
}

export const Nested: Story = {
  render: () => <NestedDemo />,
}
