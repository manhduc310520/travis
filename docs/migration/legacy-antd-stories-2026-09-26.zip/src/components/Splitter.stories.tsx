import type { Meta, StoryObj } from '@storybook/react-vite'
import { Flex, Splitter, Typography, theme } from 'antd'

const meta: Meta<typeof Splitter> = {
  component: Splitter,
  title: 'Components/Splitter',
  tags: ['ai-generated', 'needs-work'],
  // The story's only configured prop is `defaultSize`, which belongs to
  // `Splitter.Panel`, a different component from the one named here — not
  // listed as an argType on this meta. Adding a default `orientation` just
  // so the Docs page's argTypes table has something to key off.
  args: { orientation: 'horizontal' },
  argTypes: {
    orientation: { description: 'Direction the panes are arranged in.', control: 'select', options: ['horizontal', 'vertical'] },
    lazy: { description: 'Resize only when the drag ends, showing a preview bar while dragging.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Splitter>

/** Centred label filling a panel, so each pane's extent is visible. */
const Desc = ({ text }: { text: string }) => (
  <Flex justify="center" align="center" style={{ height: '100%' }}>
    <Typography.Text type="secondary">{text}</Typography.Text>
  </Flex>
)

/**
 * Outline for the demo splitters — a 1px ring in the theme's secondary
 * border colour, so the panes' outer edges show against the page.
 */
function useFrame(height: number): React.CSSProperties {
  const { token } = theme.useToken()
  return { height, boxShadow: `0 0 0 ${token.lineWidth}px ${token.colorBorderSecondary}` }
}

export const TwoPanes: Story = {
  render: () => (
    <Splitter style={{ height: 240, boxShadow: '0 0 0 1px rgba(0,0,0,0.06)' }}>
      <Splitter.Panel defaultSize="40%">
        <div style={{ padding: 16 }}><Typography.Text>First</Typography.Text></div>
      </Splitter.Panel>
      <Splitter.Panel>
        <div style={{ padding: 16 }}><Typography.Text>Second</Typography.Text></div>
      </Splitter.Panel>
    </Splitter>
  ),
}

/** Figma `Orientation=Horizontal`: panes side by side, dragged left/right. */
function HorizontalDemo() {
  const frame = useFrame(240)
  return (
    <Splitter style={frame}>
      <Splitter.Panel defaultSize="40%" min="20%" max="70%">
        <Desc text="First" />
      </Splitter.Panel>
      <Splitter.Panel>
        <Desc text="Second" />
      </Splitter.Panel>
    </Splitter>
  )
}

export const Horizontal: Story = {
  render: () => <HorizontalDemo />,
}

/** Figma `Orientation=Vertical`: panes stacked, dragged up/down. */
function VerticalDemo() {
  const frame = useFrame(320)
  return (
    <Splitter orientation="vertical" style={frame}>
      <Splitter.Panel>
        <Desc text="First" />
      </Splitter.Panel>
      <Splitter.Panel>
        <Desc text="Second" />
      </Splitter.Panel>
    </Splitter>
  )
}

export const Vertical: Story = {
  render: () => <VerticalDemo />,
}

/**
 * Figma "Multiple Panels": three panes and two bars. The last bar is locked
 * (`resizable={false}` on the panel after it) — the Figma bar dragger's
 * Disabled state.
 */
function MultiplePanelsDemo() {
  const frame = useFrame(240)
  return (
    <Splitter style={frame}>
      <Splitter.Panel collapsible>
        <Desc text="Panel 1" />
      </Splitter.Panel>
      <Splitter.Panel collapsible={{ start: true }}>
        <Desc text="Panel 2" />
      </Splitter.Panel>
      <Splitter.Panel resizable={false}>
        <Desc text="Panel 3 (not resizable)" />
      </Splitter.Panel>
    </Splitter>
  )
}

export const MultiplePanels: Story = {
  render: () => <MultiplePanelsDemo />,
}

/**
 * Figma `Collapsible?` = true: the bar shows collapse arrows (the Figma
 * "collapse button"). `min`/`max` bound the drag; collapsing ignores them.
 */
function CollapsibleDemo() {
  const frame = useFrame(240)
  return (
    <Flex vertical gap={24}>
      <Splitter style={frame}>
        <Splitter.Panel collapsible min="20%">
          <Desc text="First" />
        </Splitter.Panel>
        <Splitter.Panel collapsible>
          <Desc text="Second" />
        </Splitter.Panel>
      </Splitter>
      <Splitter orientation="vertical" style={frame}>
        <Splitter.Panel collapsible>
          <Desc text="First" />
        </Splitter.Panel>
        <Splitter.Panel collapsible>
          <Desc text="Second" />
        </Splitter.Panel>
      </Splitter>
    </Flex>
  )
}

export const Collapsible: Story = {
  render: () => <CollapsibleDemo />,
}

/**
 * Figma "Complex": a collapsible sidebar pane beside a pane that is itself
 * split vertically — splitters nest by placing one inside a Panel.
 */
function ComplexDemo() {
  const frame = useFrame(320)
  return (
    <Splitter style={frame}>
      <Splitter.Panel collapsible defaultSize="30%" min="15%">
        <Desc text="Left" />
      </Splitter.Panel>
      <Splitter.Panel>
        <Splitter orientation="vertical">
          <Splitter.Panel>
            <Desc text="Top" />
          </Splitter.Panel>
          <Splitter.Panel collapsible>
            <Desc text="Bottom" />
          </Splitter.Panel>
        </Splitter>
      </Splitter.Panel>
    </Splitter>
  )
}

export const Complex: Story = {
  render: () => <ComplexDemo />,
}
