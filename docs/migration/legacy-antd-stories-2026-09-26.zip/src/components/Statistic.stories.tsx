import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Statistic, Row, Col, Card, Typography, theme } from 'antd'
import { ArrowUp, Heart } from '../icons'
const meta: Meta<typeof Statistic> = {
  component: Statistic,
  title: 'Components/Statistic',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's statistic types — written from the API.
  argTypes: {
    title: { description: 'Label shown above the value.', control: 'text' },
    value: { description: 'The number (or text) to display.', control: 'text' },
    precision: { description: 'Decimal places to round the value to.', control: 'number' },
    prefix: { description: 'Content rendered before the value.', control: false },
    suffix: { description: 'Content rendered after the value.', control: 'text' },
  },
}
export default meta
type Story = StoryObj<typeof Statistic>

/**
 * The icon set has no ArrowDown, so Figma's `Type: Down` arrow is the same
 * ArrowUp glyph turned 180°.
 */
const ArrowDown = () => <ArrowUp style={{ transform: 'rotate(180deg)' }} />

const Caption = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
    {children}
  </Typography.Text>
)

export const Default: Story = { args: { title: 'Account Balance', value: 112893, prefix: '$' } }

/**
 * Figma `Statistic`, `Type: Basic` with `Show Icon` on and off — the "basic"
 * and "without icon" docs examples.
 */
export const Basic: Story = {
  render: () => (
    <Row gutter={[32, 16]}>
      <Col>
        <Caption>Show Icon: True</Caption>
        <Statistic title="Feedback" value={1128} prefix={<Heart />} />
      </Col>
      <Col>
        <Caption>Show Icon: False</Caption>
        <Statistic title="Active Users" value={112893} />
      </Col>
    </Row>
  ),
}

/**
 * Figma `Type: Up | Down`. The colour is the semantic success / error text
 * token (theme-aware), not a hex; the arrow is the icon that `Show Icon`
 * toggles.
 */
function TrendDemo() {
  const { token } = theme.useToken()
  return (
    <Row gutter={[32, 16]}>
      <Col>
        <Caption>Type: Up</Caption>
        <Statistic title="Active" value={11.28} precision={2} prefix={<ArrowUp />} suffix="%" styles={{ content: { color: token.colorSuccessText } }} />
      </Col>
      <Col>
        <Caption>Type: Down</Caption>
        <Statistic title="Idle" value={9.3} precision={2} prefix={<ArrowDown />} suffix="%" styles={{ content: { color: token.colorErrorText } }} />
      </Col>
      <Col>
        <Caption>Type: Up, Show Icon: False</Caption>
        <Statistic title="Active" value={11.28} precision={2} suffix="%" styles={{ content: { color: token.colorSuccessText } }} />
      </Col>
    </Row>
  )
}

export const WithTrend: Story = {
  render: () => <TrendDemo />,
}

/**
 * Figma `Statistic / Card`, `Type: Up | Down` — the trend statistic on a card
 * surface (outlined: the story canvas is already the container colour, so a
 * borderless card would disappear into it).
 */
function InCardsDemo() {
  const { token } = theme.useToken()
  return (
    <Row gutter={16}>
      <Col>
        <Card>
          <Statistic title="Active" value={11.28} precision={2} prefix={<ArrowUp />} suffix="%" styles={{ content: { color: token.colorSuccessText } }} />
        </Card>
      </Col>
      <Col>
        <Card>
          <Statistic title="Idle" value={9.3} precision={2} prefix={<ArrowDown />} suffix="%" styles={{ content: { color: token.colorErrorText } }} />
        </Card>
      </Col>
    </Row>
  )
}

export const InCards: Story = {
  render: () => <InCardsDemo />,
}

/**
 * Figma `Statistic / Countdown`, `Type: 1 | 2` — the same deadline in the two
 * formats: clock (`HH:mm:ss`) and day-level. Literal words sit in `[...]` so
 * their letters aren't read as time tokens. `Statistic.Countdown` is
 * deprecated in antd 6; `Statistic.Timer type="countdown"` replaces it.
 */
function CountdownDemo() {
  // Fixed once per mount so re-renders don't push the deadline back.
  const [deadline] = useState(() => Date.now() + 1000 * 60 * 60 * 24 * 2 + 1000 * 30)
  return (
    <Row gutter={[32, 16]}>
      <Col>
        <Caption>Type: 1</Caption>
        <Statistic.Timer type="countdown" title="Countdown" value={deadline} format="HH:mm:ss" />
      </Col>
      <Col>
        <Caption>Type: 2</Caption>
        <Statistic.Timer type="countdown" title="Day Level" value={deadline} format="D [days] H [hours] m [minutes] s [seconds]" />
      </Col>
    </Row>
  )
}

export const Countdown: Story = {
  render: () => <CountdownDemo />,
}
