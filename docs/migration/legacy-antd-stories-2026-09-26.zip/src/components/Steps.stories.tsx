import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Flex, Steps, theme } from 'antd'
import type { StepsProps } from 'antd'
import { CheckCircle, FileSearch02, Loading02, User01 } from '../icons'

const meta: Meta<typeof Steps> = {
  component: Steps,
  title: 'Components/Steps',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's steps types — written from the API.
  argTypes: {
    current: { description: 'Index (0-based) of the active step.', control: 'number' },
    type: {
      description: 'Visual type of the step list.',
      control: 'select',
      options: ['default', 'dot', 'navigation', 'inline', 'panel'],
    },
    orientation: { description: 'Layout direction of the steps.', control: 'select', options: ['horizontal', 'vertical'] },
    size: { description: 'Size of the step indicators.', control: 'select', options: ['medium', 'small'] },
    variant: { description: 'Filled or outlined step icons.', control: 'select', options: ['filled', 'outlined'] },
    status: {
      description: 'Status of the current step (overridden per-item by that item\'s own `status`).',
      control: 'select',
      options: ['wait', 'process', 'finish', 'error'],
    },
    percent: { description: 'Progress ring around the current step\'s icon, 0–100.', control: { type: 'range', min: 0, max: 100 } },
    items: { description: 'The steps: `title`, `subTitle`, `content`, `icon`, `status`, `disabled`.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Steps>

// Figma `Time?` is the item's `subTitle`; `Description?` is its `content`.
const items: NonNullable<StepsProps['items']> = [
  { title: 'Finished', content: 'This is a description.' },
  { title: 'In Progress', subTitle: 'Left 00:00:08', content: 'This is a description.' },
  { title: 'Waiting', content: 'This is a description.' },
]

/** Figma `Type=Basic`, `Direction=Horizontal`: item `Status` finish → process → wait follows `current`. */
export const Horizontal: Story = { args: { current: 1, items } }
/** Figma `Type=Basic`, `Direction=Vertical`. */
export const Vertical: Story = { args: { current: 1, orientation: 'vertical', items } }
/** Figma `Size=Small`. */
export const Small: Story = { args: { current: 1, size: 'small', items } }
/** Figma item `Status=Error`, set on the current step via `status`. */
export const WithError: Story = { args: { current: 1, status: 'error', items } }

/** Figma `Size=Small`, `Direction=Vertical`. */
export const SmallVertical: Story = { args: { current: 1, size: 'small', orientation: 'vertical', items } }

/** Figma `Type=Custom Icon`: each item's `icon` replaces the numbered circle. */
export const CustomIcon: Story = {
  args: {
    items: [
      { title: 'Login', status: 'finish', icon: <User01 size={24} /> },
      { title: 'Verification', status: 'finish', icon: <FileSearch02 size={24} /> },
      // Static Untitled UI glyph — antd's own demo spins `LoadingOutlined` here.
      { title: 'Pay', status: 'process', icon: <Loading02 size={24} /> },
      { title: 'Done', status: 'wait', icon: <CheckCircle size={24} /> },
    ],
  },
}

/** Figma `Type=Dot`. */
export const Dot: Story = { args: { current: 1, type: 'dot', items } }

/** Figma `Type=Dot`, `Direction=Vertical`. */
export const DotVertical: Story = { args: { current: 1, type: 'dot', orientation: 'vertical', items } }

/** Figma progress icon: `percent` draws a progress ring around the current step. */
export const WithProgress: Story = { args: { current: 1, percent: 60, items } }

/**
 * Figma `Type=Inline` (`Steps / Steps Item / Inline Step`): a compact strip
 * that sits inside a list row; titles and descriptions show on hover.
 * Rows mirror the Figma component's code — different `current`, one errored.
 */
function InlineDemo() {
  const { token } = theme.useToken()
  const rows: { title: string; current: number; status?: StepsProps['status'] }[] = [
    { title: 'Order #1024', current: 0 },
    { title: 'Order #1025', current: 1, status: 'error' },
    { title: 'Order #1026', current: 2 },
  ]
  const inlineItems = [
    { title: 'Step 1', content: 'This is Step 1.' },
    { title: 'Step 2', content: 'This is Step 2.' },
    { title: 'Step 3', content: 'This is Step 3.' },
  ]
  return (
    <Flex vertical style={{ maxWidth: 480 }}>
      {rows.map((row) => (
        <Flex
          key={row.title}
          vertical
          gap={8}
          style={{ padding: `${token.paddingSM}px 0`, borderBottom: `1px solid ${token.colorBorderSecondary}` }}
        >
          <span>{row.title}</span>
          <Steps type="inline" current={row.current} status={row.status} items={inlineItems} />
        </Flex>
      ))}
    </Flex>
  )
}

export const Inline: Story = {
  render: () => <InlineDemo />,
}

/** Figma `Type=Navigation`, `Size=Medium` / `Size=Small`: clickable tabs-like steps — click one to move to it. */
function NavigationDemo({ size }: { size: 'medium' | 'small' }) {
  const [current, setCurrent] = useState(0)
  return (
    <Steps
      type="navigation"
      size={size}
      current={current}
      onChange={setCurrent}
      items={[
        { title: 'Step 1', subTitle: '00:00:05', content: 'This is a description.' },
        { title: 'Step 2', subTitle: '00:01:02', content: 'This is a description.' },
        { title: 'Step 3', subTitle: 'Waiting for a long time', content: 'This is a description.' },
      ]}
    />
  )
}

export const Navigation: Story = {
  render: () => <NavigationDemo size="medium" />,
}

export const NavigationSmall: Story = {
  render: () => <NavigationDemo size="small" />,
}

/**
 * Figma `Panel Steps`, `Type=1` and `Type=2`. The Figma component's own code
 * defines them: Type 1 is `type="panel"` at the default size; Type 2 is the
 * same with `size="small"` and `variant="outlined"`. Click a step to move to it.
 */
function PanelDemo() {
  const [current, setCurrent] = useState(0)
  const shared: StepsProps = {
    type: 'panel',
    current,
    onChange: setCurrent,
    items: [
      { title: 'Step 1', subTitle: '00:00', content: 'This is a content.' },
      { title: 'Step 2', content: 'This is a content.', status: 'error' },
      { title: 'Step 3', content: 'This is a content.' },
    ],
  }
  return (
    <Flex vertical gap="medium">
      <Steps {...shared} />
      <Steps {...shared} size="small" variant="outlined" />
    </Flex>
  )
}

export const Panel: Story = {
  render: () => <PanelDemo />,
}
