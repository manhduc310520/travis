import type { Meta, StoryObj } from '@storybook/react-vite'
import { expect } from 'storybook/test'
import { Avatar, Badge, Button, Dropdown, Input, Progress, Rate, Space, Switch, Table, Tag, Typography } from 'antd'
import type { BadgeProps, TableColumnsType, TableColumnType } from 'antd'
import { ChevronDown, SearchMd, User01 } from '../icons'

type Row = { key: string; posId: string; name: string; city: string; status: 'active' | 'paused' }

/**
 * Ant Design doesn't stop a header title from wrapping just because the
 * column has a `width` — the two are unrelated. `onHeaderCell` sets a real
 * CSS `minWidth` + `nowrap` on that one cell; `onCell` gives the body the
 * same floor without forcing nowrap, so long content can still wrap.
 */
function withMinWidth<T>(column: T & { minWidth: number }) {
  const { minWidth, ...rest } = column
  return {
    ...rest,
    onHeaderCell: () => ({ style: { minWidth, whiteSpace: 'nowrap' as const } }),
    onCell: () => ({ style: { minWidth } }),
  }
}

const renderStatus = (s: Row['status']) => (
  <Tag color={s === 'active' ? 'success' : 'default'}>{s === 'active' ? 'Active' : 'Paused'}</Tag>
)

const columns = [
  withMinWidth({ title: 'Pos ID', dataIndex: 'posId', key: 'posId', minWidth: 100 }),
  withMinWidth({ title: 'Name', dataIndex: 'name', key: 'name', minWidth: 160 }),
  withMinWidth({ title: 'City', dataIndex: 'city', key: 'city', minWidth: 140 }),
  withMinWidth({
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
    minWidth: 140,
    render: renderStatus,
  }),
]

const data: Row[] = [
  { key: '1', posId: 'POS-1042', name: 'John Brown', city: 'New York', status: 'active' },
  { key: '2', posId: 'POS-1043', name: 'Jim Green', city: 'London', status: 'active' },
  { key: '3', posId: 'POS-1044', name: 'Joe Black', city: 'Sydney', status: 'paused' },
]

const NAMES = ['John Brown', 'Jim Green', 'Joe Black', 'Jane Doe', 'Mary White', 'Tom Lee']
const CITIES = ['New York', 'London', 'Sydney', 'Hanoi', 'Da Nang', 'Singapore']

/** Enough rows for pagination to have more than one page at `pageSize: 5`. */
const manyRows: Row[] = Array.from({ length: 12 }, (_, i) => ({
  key: String(i + 1),
  posId: `POS-${1042 + i}`,
  name: NAMES[i % NAMES.length],
  city: CITIES[(i * 5) % CITIES.length],
  status: i % 3 === 2 ? 'paused' : 'active',
}))

const Caption = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
    {children}
  </Typography.Text>
)

const meta = {
  component: Table<Row>,
  title: 'Components/Table',
  tags: ['ai-generated', 'needs-work'],
  // Without `scroll.x`, a table whose columns' combined minWidth exceeds its
  // container doesn't scroll internally — it overflows the page itself
  // (verified: .ant-table-content defaults to overflow-x: visible). This is
  // the same fix RestaurantListPage.tsx already applies below `md`.
  args: { columns, dataSource: data, pagination: false, scroll: { x: 'max-content' } },
  // No JSDoc on these in antd's InternalTable.d.ts — written from the API.
  argTypes: {
    pagination: { description: 'Pagination config, or false to disable it entirely.', control: false },
    loading: { description: 'Shows a loading spinner over the table body.', control: 'boolean' },
    // antd 6 deprecates `middle` in favour of `medium` (Figma `Size: Medium`);
    // `large` is antd's default (Figma `Size: Default`).
    size: { description: 'Row height / cell padding density.', control: 'select', options: ['large', 'medium', 'small'] },
    bordered: { description: 'Adds vertical borders between columns (off by default, per the Figma spec).', control: 'boolean' },
    title: { description: 'Renders a header bar above the table (Figma `Title?`).', control: false },
    footer: { description: 'Renders a footer bar below the rows (Figma `Footer?`).', control: false },
  },
} satisfies Meta<typeof Table<Row>>

export default meta
type Story = StoryObj<typeof meta>

/** Figma "without title / footer / pagination" example. */
export const Default: Story = {
  play: async ({ canvas }) => {
    await expect(canvas.getByText('John Brown')).toBeVisible()
    await expect(canvas.getAllByRole('row')).toHaveLength(4)
  },
}

export const Empty: Story = { args: { dataSource: [] } }

export const Loading: Story = { args: { loading: true } }

export const Compact: Story = { args: { size: 'small' } }

/** Figma "default" example: `Title?`, `Footer?` and `Pagination?` all on. */
export const WithTitleFooterPagination: Story = {
  args: {
    title: () => 'Point of sale list',
    footer: () => 'Paused POS stop syncing orders until reactivated.',
    dataSource: manyRows,
    pagination: { pageSize: 5 },
  },
}

/** Figma "bordered" example — `bordered` adds the column dividers and outer frame. */
export const Bordered: Story = {
  args: {
    bordered: true,
    title: () => 'Point of sale list',
    footer: () => 'Paused POS stop syncing orders until reactivated.',
    dataSource: manyRows,
    pagination: { pageSize: 5 },
  },
}

/**
 * Figma `Size: Default | Medium | Small`, bordered — the "medium bordered"
 * and "small bordered" docs examples next to the default density.
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
      {([
        ['Size: Default (large)', 'large'],
        ['Size: Medium', 'medium'],
        ['Size: Small', 'small'],
      ] as const).map(([label, size]) => (
        <div key={size}>
          <Caption>{label}</Caption>
          <Table<Row> columns={columns} dataSource={data} size={size} bordered pagination={false} scroll={{ x: 'max-content' }} />
        </div>
      ))}
    </div>
  ),
}

/**
 * Figma header controls `Sort?`, `Filter?` and `Search?`. Search is a custom
 * `filterDropdown` (an input plus Search / Reset) with a search glyph as its
 * trigger; filter uses antd's built-in checklist; sort cycles
 * ascending → descending → off.
 */
const nameSearch: TableColumnType<Row> = {
  filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
    <div style={{ padding: 8 }} onKeyDown={(e) => e.stopPropagation()}>
      <Input
        placeholder="Search name"
        value={selectedKeys[0] as string | undefined}
        onChange={(e) => setSelectedKeys(e.target.value ? [e.target.value] : [])}
        onPressEnter={() => confirm()}
        style={{ marginBottom: 8, display: 'block' }}
      />
      <Space>
        <Button type="primary" size="small" icon={<SearchMd />} onClick={() => confirm()}>
          Search
        </Button>
        <Button
          size="small"
          onClick={() => {
            clearFilters?.()
            confirm()
          }}
        >
          Reset
        </Button>
      </Space>
    </div>
  ),
  // The trigger is a `role="button"` named by its content, so the glyph is a
  // named image (Untitled UI icons ship `aria-hidden`, hence `aria-hidden={false}`).
  filterIcon: <SearchMd role="img" aria-hidden={false} aria-label="Search name" />,
  onFilter: (value, record) => record.name.toLowerCase().includes(String(value).toLowerCase()),
}

const headerControlColumns: TableColumnsType<Row> = [
  { title: 'Pos ID', dataIndex: 'posId', key: 'posId', sorter: (a, b) => a.posId.localeCompare(b.posId) },
  { title: 'Name', dataIndex: 'name', key: 'name', ...nameSearch },
  {
    title: 'City',
    dataIndex: 'city',
    key: 'city',
    filters: CITIES.map((c) => ({ text: c, value: c })),
    onFilter: (value, record) => record.city === value,
    sorter: (a, b) => a.city.localeCompare(b.city),
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
    filters: [
      { text: 'Active', value: 'active' },
      { text: 'Paused', value: 'paused' },
    ],
    onFilter: (value, record) => record.status === value,
    render: renderStatus,
  },
]

export const HeaderSortFilterSearch: Story = {
  render: () => (
    <Table<Row> columns={headerControlColumns} dataSource={manyRows} pagination={{ pageSize: 5 }} scroll={{ x: 'max-content' }} />
  ),
}

type Staff = {
  key: string
  name: string
  email: string
  status: NonNullable<BadgeProps['status']>
  role: 'Manager' | 'Cashier' | 'Waiter'
  rating: number
  active: boolean
  progress: number
}

const STATUS_TEXT: Record<Staff['status'], string> = {
  success: 'On shift',
  processing: 'Checking in',
  default: 'Off',
  warning: 'On break',
  error: 'Absent',
}

// Preset palette colours are allowed here: a role tag is a classification.
const ROLE_COLOR: Record<Staff['role'], string> = { Manager: 'purple', Cashier: 'cyan', Waiter: 'blue' }

const staff: Staff[] = [
  { key: '1', name: 'John Brown', email: 'john@example.com', status: 'success', role: 'Manager', rating: 5, active: true, progress: 100 },
  { key: '2', name: 'Jim Green', email: 'jim@example.com', status: 'processing', role: 'Cashier', rating: 4, active: true, progress: 60 },
  { key: '3', name: 'Joe Black', email: 'joe@example.com', status: 'warning', role: 'Waiter', rating: 3, active: false, progress: 30 },
  { key: '4', name: 'Jane Doe', email: 'jane@example.com', status: 'error', role: 'Waiter', rating: 2, active: false, progress: 0 },
]

/**
 * Figma cell types, one column each: Avatar, Text, Badge, Tag, Rate, Switch,
 * Progress, Action (links), Dropdown and Action Button. Action buttons stay
 * `default` — the one primary action belongs to the page, not every row.
 */
const cellTypeColumns: TableColumnsType<Staff> = [
  {
    title: 'Avatar',
    dataIndex: 'name',
    key: 'avatar',
    render: (name: string) => (
      <Space size={8}>
        <Avatar size="small" icon={<User01 />} />
        {name}
      </Space>
    ),
  },
  { title: 'Text', dataIndex: 'email', key: 'email' },
  {
    title: 'Badge',
    dataIndex: 'status',
    key: 'status',
    render: (status: Staff['status']) => <Badge status={status} text={STATUS_TEXT[status]} />,
  },
  {
    title: 'Tag',
    dataIndex: 'role',
    key: 'role',
    render: (role: Staff['role']) => <Tag color={ROLE_COLOR[role]}>{role}</Tag>,
  },
  {
    title: 'Rate',
    dataIndex: 'rating',
    key: 'rating',
    render: (rating: number) => <Rate disabled size="small" defaultValue={rating} />,
  },
  {
    title: 'Switch',
    dataIndex: 'active',
    key: 'active',
    render: (active: boolean, record) => <Switch size="small" defaultChecked={active} aria-label={`${record.name} active`} />,
  },
  {
    title: 'Progress',
    dataIndex: 'progress',
    key: 'progress',
    render: (progress: number, record) => (
      <Progress percent={progress} size="small" aria-label={`${record.name} progress`} style={{ minWidth: 120 }} />
    ),
  },
  {
    title: 'Action',
    key: 'action',
    render: () => (
      <Space size={16}>
        <Typography.Link>Edit</Typography.Link>
        <Typography.Link type="danger">Delete</Typography.Link>
      </Space>
    ),
  },
  {
    title: 'Dropdown',
    key: 'dropdown',
    render: () => (
      <Dropdown
        menu={{
          items: [
            { key: 'view', label: 'View profile' },
            { key: 'shift', label: 'Change shift' },
            { key: 'remove', label: 'Remove', danger: true },
          ],
        }}
      >
        <Typography.Link>
          <Space size={4}>
            More
            <ChevronDown />
          </Space>
        </Typography.Link>
      </Dropdown>
    ),
  },
  {
    title: 'Action Button',
    key: 'button',
    render: () => <Button size="small">View</Button>,
  },
]

export const CellTypes: Story = {
  render: () => (
    <Table<Staff> columns={cellTypeColumns} dataSource={staff} pagination={false} scroll={{ x: 'max-content' }} />
  ),
}

/** Figma row control `checkbox` and `radio` — `rowSelection.type`. */
export const RowSelection: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
      <div>
        <Caption>Checkbox</Caption>
        <Table<Row>
          rowSelection={{ type: 'checkbox', defaultSelectedRowKeys: ['1'] }}
          columns={columns}
          dataSource={data}
          pagination={false}
          scroll={{ x: 'max-content' }}
        />
      </div>
      <div>
        <Caption>Radio</Caption>
        <Table<Row>
          rowSelection={{ type: 'radio', defaultSelectedRowKeys: ['2'] }}
          columns={columns}
          dataSource={data}
          pagination={false}
          scroll={{ x: 'max-content' }}
        />
      </div>
    </div>
  ),
}

/** Figma row control `expand` — `expandable.expandedRowRender`; paused rows have nothing to expand. */
export const ExpandableRows: Story = {
  render: () => (
    <Table<Row>
      columns={columns}
      dataSource={data}
      pagination={false}
      scroll={{ x: 'max-content' }}
      expandable={{
        expandedRowRender: (record) => (
          <p style={{ margin: 0 }}>
            {record.name} runs {record.posId} in {record.city}; it synced its last order 5 minutes ago.
          </p>
        ),
        rowExpandable: (record) => record.status === 'active',
        defaultExpandedRowKeys: ['1'],
      }}
    />
  ),
}
