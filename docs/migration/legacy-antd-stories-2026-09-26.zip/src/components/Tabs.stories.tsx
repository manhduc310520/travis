import type { Meta, StoryObj } from '@storybook/react-vite'
import { useRef, useState, type ReactNode } from 'react'
import { Badge, Flex, Space, Tabs, theme } from 'antd'
import type { TabsProps } from 'antd'
import { Bell01, Home01, Settings01 } from '../icons'

const meta: Meta<typeof Tabs> = {
  component: Tabs,
  title: 'Components/Tabs',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's tabs types — written from the API.
  argTypes: {
    items: { description: 'The list of tabs.', control: false },
    type: { description: 'Visual style of the tab strip.', control: 'select', options: ['line', 'card', 'editable-card'] },
    tabPlacement: {
      description: 'Which side the tab strip sits on (`start`/`end` are left/right in LTR).',
      control: 'select',
      options: ['top', 'bottom', 'start', 'end'],
    },
    centered: { description: 'Centers the tab strip instead of left-aligning it.', control: 'boolean' },
    size: { description: 'Size of the tab strip.', control: 'select', options: ['large', 'medium', 'small'] },
    hideAdd: { description: 'Hides the "+" button of an editable-card strip.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Tabs>

type TabItem = NonNullable<TabsProps['items']>[number]
type Size = 'small' | 'medium' | 'large'

const items: TabItem[] = [
  { key: '1', label: 'Tab 1', children: 'Content of Tab Pane 1' },
  { key: '2', label: 'Tab 2', children: 'Content of Tab Pane 2' },
  { key: '3', label: 'Tab 3', children: 'Content of Tab Pane 3' },
]

/** Small caption naming the variant shown under it. */
function Caption({ children }: { children: ReactNode }) {
  const { token } = theme.useToken()
  return <div style={{ fontSize: token.fontSizeSM, color: token.colorTextDescription, marginBottom: token.marginXXS }}>{children}</div>
}

/** Figma `Tabs / Basic`, `Placement=Top`, `Size=Default`. */
export const Line: Story = { args: { items, defaultActiveKey: '1' } }
/** Figma `Tabs / Card`, `Size=Default`. */
export const Card: Story = { args: { items, type: 'card' } }
export const Centered: Story = { args: { items, centered: true } }
/** Figma `Tabs / Basic`, `Size=Small`. */
export const Small: Story = { args: { items, size: 'small' } }

/**
 * Figma `Tabs / Basic` `Placement`: Top, Bottom, Left, Right. antd v6 names
 * the sides `start`/`end` (`tabPosition` left/right is deprecated), which
 * resolve to left/right in a left-to-right layout.
 */
export const Placements: Story = {
  render: () => (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 32 }}>
      {([
        ['top', 'Top'],
        ['bottom', 'Bottom'],
        ['start', 'Left (start)'],
        ['end', 'Right (end)'],
      ] as const).map(([placement, label]) => (
        <div key={placement}>
          <Caption>{label}</Caption>
          <Tabs tabPlacement={placement} items={items} />
        </div>
      ))}
    </div>
  ),
}

const SIZES: [Size, string][] = [
  ['medium', 'Default'],
  ['large', 'Large'],
  ['small', 'Small'],
]

/** Figma `Tabs / Basic` `Size`: Default, Large, Small. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={24}>
      {SIZES.map(([size, label]) => (
        <div key={size}>
          <Caption>{label}</Caption>
          <Tabs size={size} items={items} />
        </div>
      ))}
    </Flex>
  ),
}

/** Figma `Tabs / Card` `Size`: Default, Large, Small. */
export const CardSizes: Story = {
  render: () => (
    <Flex vertical gap={24}>
      {SIZES.map(([size, label]) => (
        <div key={size}>
          <Caption>{label}</Caption>
          <Tabs type="card" size={size} items={items} />
        </div>
      ))}
    </Flex>
  ),
}

/**
 * One editable strip: "+" appends a tab, the × on a tab removes it. Tab 3 sets
 * `closable: false`, so both Figma item states (`Closeable?` on/off) show.
 */
function EditableCardDemo({ size }: { size: Size }) {
  const [tabs, setTabs] = useState<TabItem[]>([
    { key: '1', label: 'Tab 1', children: 'Content of Tab Pane 1' },
    { key: '2', label: 'Tab 2', children: 'Content of Tab Pane 2' },
    { key: '3', label: 'Tab 3', children: 'Content of Tab Pane 3', closable: false },
  ])
  const [activeKey, setActiveKey] = useState('1')
  const nextKey = useRef(4)

  const onEdit: TabsProps['onEdit'] = (target, action) => {
    if (action === 'add') {
      const key = String(nextKey.current++)
      setTabs([...tabs, { key, label: `Tab ${key}`, children: `Content of Tab Pane ${key}` }])
      setActiveKey(key)
      return
    }
    const remaining = tabs.filter((tab) => tab.key !== target)
    setTabs(remaining)
    if (target === activeKey && remaining.length > 0) setActiveKey(remaining[remaining.length - 1].key)
  }

  return <Tabs type="editable-card" size={size} items={tabs} activeKey={activeKey} onChange={setActiveKey} onEdit={onEdit} />
}

/** Figma `Tabs / Container` (antd's `editable-card`) `Size`: Default, Large, Small — with the add button and closable tabs. */
export const EditableCard: Story = {
  render: () => (
    <Flex vertical gap={24}>
      {SIZES.map(([size, label]) => (
        <div key={size}>
          <Caption>{label}</Caption>
          <EditableCardDemo size={size} />
        </div>
      ))}
    </Flex>
  ),
}

/**
 * Figma tab-item `Icon?` and `Badge?`: `icon` renders before the label; the
 * badge has no Tabs prop, so it is an antd `Badge` composed into `label`.
 */
export const WithIconAndBadge: Story = {
  args: {
    defaultActiveKey: 'overview',
    items: [
      { key: 'overview', icon: <Home01 />, label: 'Overview', children: 'Overview content' },
      {
        key: 'notifications',
        icon: <Bell01 />,
        label: (
          <Space size={4}>
            Notifications
            <Badge count={5} size="small" />
          </Space>
        ),
        children: 'Notifications content',
      },
      { key: 'settings', icon: <Settings01 />, label: 'Settings', children: 'Settings content' },
    ],
  },
}
