import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ReactNode } from 'react'
import { Flex, TimePicker, Typography, theme } from 'antd'
import dayjs from 'dayjs'
import { Bell01 } from '../icons'

const meta: Meta<typeof TimePicker> = {
  component: TimePicker,
  title: 'Components/TimePicker',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc found on these in antd's time-picker types — written from the API.
  argTypes: {
    use12Hours: { description: 'Shows a 12-hour clock with an AM/PM column instead of 24-hour.', control: 'boolean' },
    format: { description: 'dayjs format string controlling how the time is displayed/parsed.', control: 'text' },
    disabled: { description: 'Disables the input.', control: 'boolean' },
    status: { description: 'Validation state — colors the border and focus ring.', control: 'select', options: ['', 'warning', 'error'] },
    size: { description: 'Control height: small, middle (the 32px default) or large.', control: 'select', options: ['small', 'middle', 'large'] },
    variant: {
      description: 'Visual style of the field.',
      control: 'select',
      options: ['outlined', 'filled', 'borderless', 'underlined'],
    },
    prefix: { description: 'Content rendered before the value, inside the field.', control: false },
    open: { description: 'Controls whether the time panel is shown.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof TimePicker>

const { RangePicker } = TimePicker

// Fixed times, not `dayjs()`: an open panel on "now" would change the visual
// snapshot on every run. Only the time part is shown.
const TIME = dayjs('2026-03-12T13:30:56')
const TIME_END = dayjs('2026-03-12T17:45:00')

const VARIANTS = ['outlined', 'filled', 'borderless', 'underlined'] as const
const SIZES = [
  { size: 'small', label: 'Small' },
  { size: 'middle', label: 'Default' },
  { size: 'large', label: 'Large' },
] as const
const title = (s: string) => s[0].toUpperCase() + s.slice(1)

/** Secondary 12px caption naming the Figma variant an example stands for. */
function Caption({ children, width }: { children: ReactNode; width?: number }) {
  const { token } = theme.useToken()
  return (
    <Typography.Text type="secondary" style={{ fontSize: token.fontSizeSM, width, flexShrink: 0 }}>
      {children}
    </Typography.Text>
  )
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Flex gap={16} align="center" wrap>
      <Caption width={96}>{label}</Caption>
      {children}
    </Flex>
  )
}

/**
 * Panels shown open for display portal into this box instead of
 * `document.body` (see `inFrame`), and the box reserves room for them — so
 * neighbouring examples never overlap and the Docs page scrolls them with
 * their field.
 */
function PopupFrame({ label, width, height = 340, children }: { label: string; width: number; height?: number; children: ReactNode }) {
  return (
    <Flex vertical gap={4} style={{ width }}>
      <Caption>{label}</Caption>
      <div data-popup-frame="" style={{ position: 'relative', height }}>
        {children}
      </div>
    </Flex>
  )
}
const inFrame = (node: HTMLElement) => node.closest<HTMLElement>('[data-popup-frame]') ?? document.body
/** Pins the placement: by default the panel flips when it would leave the viewport mid-scroll. */
const pinned = { overflow: { adjustX: false, adjustY: false } }

export const Default: Story = { args: { placeholder: 'Select time' } }
export const Range: Story = { render: () => <RangePicker /> }
export const TwelveHour: Story = { args: { use12Hours: true, format: 'h:mm a' } }
export const Disabled: Story = { args: { disabled: true } }

/** Figma `Size[Small|Default|Large]` × `Range`. `middle` is antd's name for the 32px default. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {SIZES.map(({ size, label }) => (
        <Row key={size} label={label}>
          <TimePicker size={size} />
          <RangePicker size={size} />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma's four input sets — Outlined / Filled / Borderless / Underlined — single and range. */
export const Variants: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {VARIANTS.map((variant) => (
        <Row key={variant} label={title(variant)}>
          <TimePicker variant={variant} />
          <RangePicker variant={variant} />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma `Status[Warning|Error]` on every input set, single and range. */
export const Status: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {VARIANTS.map((variant) => (
        <Row key={variant} label={title(variant)}>
          <TimePicker variant={variant} status="error" placeholder="Error" />
          <TimePicker variant={variant} status="warning" placeholder="Warning" />
          <RangePicker variant={variant} status="error" />
          <RangePicker variant={variant} status="warning" />
        </Row>
      ))}
    </Flex>
  ),
}

/** Figma's prefix slot: an icon or a short text label inside the field, before the value. */
export const WithPrefix: Story = {
  render: () => (
    <Flex gap={16} wrap>
      <TimePicker prefix={<Bell01 />} placeholder="Reminder time" />
      <RangePicker prefix="Shift" />
    </Flex>
  ),
}

/** Figma "open" example (`Active: Yes`), single and range, rendered statically open on a fixed time. */
export const Open: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Active" width={200}>
        <TimePicker open popupAlign={pinned} getPopupContainer={inFrame} defaultValue={TIME} />
      </PopupFrame>
      <PopupFrame label="Active, Range" width={280}>
        <RangePicker open popupAlign={pinned} getPopupContainer={inFrame} defaultValue={[TIME, TIME_END]} />
      </PopupFrame>
    </Flex>
  ),
}
