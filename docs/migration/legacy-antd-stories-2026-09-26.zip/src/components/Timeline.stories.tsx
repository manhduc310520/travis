import type { Meta, StoryObj } from '@storybook/react-vite'
import { Timeline, Typography } from 'antd'
import type { TimelineProps } from 'antd'
import { Clock } from '../icons'

const meta: Meta<typeof Timeline> = {
  component: Timeline,
  title: 'Components/Timeline',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc on these in antd's timeline types — written from the API.
  // antd 6 deprecates `mode="left" | "right"` in favour of logical
  // `start` / `end` (Figma `Text Placement: Left | Right`).
  argTypes: {
    items: { description: 'The list of timeline entries.', control: false },
    mode: { description: 'Placement of entries relative to the line: start (Figma Left), end (Right) or alternate.', control: 'select', options: ['start', 'alternate', 'end'] },
    orientation: { description: 'Vertical list, or a horizontal track (Figma `Timeline / Horizontal`).', control: 'select', options: ['vertical', 'horizontal'] },
    reverse: { description: 'Renders the items in reverse order.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Timeline>

const items: TimelineProps['items'] = [
  { content: 'Create a services site 2015-09-01' },
  { content: 'Solve initial network problems 2015-09-01', color: 'green' },
  { content: 'Technical testing 2015-09-01', color: 'red' },
  { content: 'Network problems being solved 2015-09-01' },
]

const Caption = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 8 }}>
    {children}
  </Typography.Text>
)

/** Figma `Text Placement: Left` — antd's default `mode="start"`. */
export const Default: Story = { args: { items } }

/** Figma `Text Placement: Alternate`. */
export const Alternate: Story = { args: { items, mode: 'alternate' } }

/** Figma `Text Placement: Right` — `mode="end"`. */
export const Right: Story = { args: { items, mode: 'end' } }

/** Figma item `Color: Blue | Gray | Green | Red` — antd's four built-in dot colours. */
export const ItemColors: Story = {
  args: {
    items: [
      { content: 'Blue — in progress or default', color: 'blue' },
      { content: 'Gray — not started or inactive', color: 'gray' },
      { content: 'Green — completed', color: 'green' },
      { content: 'Red — failed or needs attention', color: 'red' },
    ],
  },
}

/** Figma "custom" item — `icon` replaces the dot with any node. */
export const CustomDot: Story = {
  args: {
    items: [
      { content: 'Create a services site 2015-09-01' },
      { content: 'Solve initial network problems 2015-09-01' },
      { content: 'Technical testing 2015-09-01', icon: <Clock />, color: 'red' },
      { content: 'Network problems being solved 2015-09-01' },
    ],
  },
}

const horizontalItems: TimelineProps['items'] = [
  { content: 'Init' },
  { content: 'Start', color: 'green' },
  { content: 'Pending', color: 'red' },
  { content: 'Complete', color: 'gray' },
]

/**
 * Figma `Timeline / Horizontal`, `Text Placement: Top | Center | Bottom` —
 * antd 6 `orientation="horizontal"`. Top = `mode="end"` (labels above the
 * track), Bottom = `mode="start"` (below, the default), Center =
 * `mode="alternate"` (track in the middle, labels alternating above/below).
 */
export const Horizontal: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32, maxWidth: 640 }}>
      {([
        ['Text Placement: Top', 'end'],
        ['Text Placement: Center', 'alternate'],
        ['Text Placement: Bottom', 'start'],
      ] as const).map(([label, mode]) => (
        <div key={mode}>
          <Caption>{label}</Caption>
          <Timeline orientation="horizontal" mode={mode} items={horizontalItems} />
        </div>
      ))}
    </div>
  ),
}
