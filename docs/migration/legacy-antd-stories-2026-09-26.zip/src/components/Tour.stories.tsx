import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState, type CSSProperties, type ReactNode } from 'react'
import { Button, Divider, Flex, Space, Tour, theme } from 'antd'
import type { TourProps, TourStepProps } from 'antd'
import { DotsHorizontal, Upload01 } from '../icons'

type Placement = NonNullable<TourProps['placement']>

const PLACEMENT_OPTIONS: Placement[] = [
  'topLeft', 'top', 'topRight',
  'leftTop', 'left', 'leftBottom',
  'rightTop', 'right', 'rightBottom',
  'bottomLeft', 'bottom', 'bottomRight',
]

const meta: Meta<typeof Tour> = {
  component: Tour,
  title: 'Components/Tour',
  tags: ['ai-generated', 'needs-work'],
  // `Placements` reads `placement`/`type`/`mask`/`arrow` from args, so the
  // Controls are live there. No JSDoc on these in antd's tour types —
  // written from the API.
  args: { placement: 'bottom', type: 'primary', mask: false, arrow: true },
  argTypes: {
    steps: {
      description: 'The steps: `title`, `description`, `cover` (image slot), `target`, plus per-step `placement` / `type` / `mask`.',
      control: false,
    },
    open: { description: 'Controlled open state.', control: 'boolean' },
    current: { description: 'Controlled index of the visible step.', control: 'number' },
    placement: { description: 'Where the panel opens relative to the step target.', control: 'select', options: PLACEMENT_OPTIONS },
    type: { description: "`primary` fills the panel with the brand colour — antd's recommended look for a non-modal tour.", control: 'select', options: ['default', 'primary'] },
    mask: { description: 'Dims everything except the target. `false` makes the tour non-modal.', control: 'boolean' },
    arrow: { description: 'Shows the arrow pointing at the target.', control: 'boolean' },
    indicatorsRender: { description: 'Replaces the step indicators, e.g. with a "1 / 3" counter.', control: false },
    getPopupContainer: { description: 'Where mask and panel render; `false` renders them in place instead of on document.body.', control: false },
    onClose: { description: 'Called when the close button or Finish is clicked.', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Tour>

// Step copy from the Figma component's own code (antd's basic Tour demo).
const STEP_TEXT = [
  { title: 'Upload File', description: 'Put your files here.' },
  { title: 'Save', description: 'Save your changes.' },
  { title: 'Other Actions', description: 'Click to see other actions.' },
]

/** Figma `Image?`: the `cover` slot, shown with a neutral placeholder instead of a remote image. */
function Cover() {
  const { token } = theme.useToken()
  return <div style={{ height: 120, borderRadius: token.borderRadius, background: token.colorFillSecondary }} />
}

/** Small caption naming the variant shown under it. */
function Caption({ children }: { children: ReactNode }) {
  const { token } = theme.useToken()
  return <div style={{ fontSize: token.fontSizeSM, color: token.colorTextDescription, marginBottom: token.marginXXS }}>{children}</div>
}

/**
 * Figma `Type=Basic` with `Image?` on, as the Figma component's code builds
 * it: three targets, a cover image on the first step, the page masked
 * around the highlighted target. Closed by default — click "Begin Tour".
 * "Begin Tour" is a default button so "Save" stays the one primary action.
 */
function BasicDemo() {
  const [open, setOpen] = useState(false)
  const [upload, setUpload] = useState<HTMLElement | null>(null)
  const [save, setSave] = useState<HTMLElement | null>(null)
  const [more, setMore] = useState<HTMLElement | null>(null)
  const steps: TourStepProps[] = [
    { ...STEP_TEXT[0], cover: <Cover />, target: upload },
    { ...STEP_TEXT[1], target: save },
    { ...STEP_TEXT[2], target: more },
  ]
  return (
    <>
      <Button onClick={() => setOpen(true)}>Begin Tour</Button>
      <Divider />
      <Space>
        <Button ref={setUpload} icon={<Upload01 />}>Upload</Button>
        <Button ref={setSave} type="primary">Save</Button>
        <Button ref={setMore} icon={<DotsHorizontal />} aria-label="More actions" />
      </Space>
      <Tour open={open} onClose={() => setOpen(false)} steps={steps} />
    </>
  )
}

export const Basic: Story = {
  render: () => <BasicDemo />,
}

/** Parks the target on the side opposite the panel, so the panel opens into the frame's free space. */
function targetAlign(placement: Placement): CSSProperties {
  const side = placement.startsWith('top') ? 'top' : placement.startsWith('bottom') ? 'bottom' : placement.startsWith('left') ? 'left' : placement.startsWith('right') ? 'right' : 'center'
  const edgeAlign = (start: string, end: string) => (placement.endsWith(start) ? 'flex-start' : placement.endsWith(end) ? 'flex-end' : 'center')
  if (side === 'center') return { alignItems: 'center', justifyContent: 'center' }
  const opensVertically = side === 'top' || side === 'bottom'
  return {
    alignItems: opensVertically ? (side === 'top' ? 'flex-end' : 'flex-start') : edgeAlign('Top', 'Bottom'),
    justifyContent: opensVertically ? edgeAlign('Left', 'Right') : side === 'left' ? 'flex-end' : 'flex-start',
  }
}

type InlineTourProps = Pick<TourProps, 'type' | 'mask' | 'arrow' | 'indicatorsRender'> & {
  placement?: Placement
  withCover?: boolean
  height?: number
}

/**
 * Holds a tour open inside the story instead of over the whole Docs page.
 * `getPopupContainer={false}` is rc-tour's inline mode: mask, highlight and
 * panel render in place, positioned against this `position: relative`
 * frame, with no body scroll-lock and no scroll-into-view. `keyboard={false}`
 * stops arrow keys on the Docs page from paging every open tour at once.
 * All three steps point at the one target so the indicators have a total.
 */
function InlineTour({ placement = 'bottom', withCover = false, height = 280, ...tourProps }: InlineTourProps) {
  const [target, setTarget] = useState<HTMLElement | null>(null)
  const steps: TourStepProps[] = STEP_TEXT.map((text, index) => ({
    ...text,
    target,
    cover: withCover && index === 0 ? <Cover /> : undefined,
  }))
  return (
    <div style={{ position: 'relative', height, padding: 24, display: 'flex', ...targetAlign(placement) }}>
      <Button ref={setTarget} icon={<Upload01 />}>Upload</Button>
      {target && (
        <Tour open getPopupContainer={false} keyboard={false} placement={placement} steps={steps} {...tourProps} />
      )}
    </div>
  )
}

/** Figma `Type=Basic` with `Image?` off, held open: the mask dims the frame around the target. */
export const WithoutImage: Story = {
  render: () => <InlineTour />,
}

/**
 * Figma `Type=Non-modal`, held open: `mask={false}` leaves the page usable
 * around the tour, and `type="primary"` — antd's recommendation for a
 * non-modal tour — fills the panel with the brand colour so it still stands out.
 */
export const NonModal: Story = {
  render: () => <InlineTour type="primary" mask={false} />,
}

/** Figma's non-modal examples at `Bottom Right`, `Left Bottom` and `Top`, held open. */
export const NonModalPlacements: Story = {
  render: () => (
    <Flex vertical gap={24}>
      {(['bottomRight', 'leftBottom', 'top'] as const).map((placement) => (
        <div key={placement}>
          <Caption>{placement}</Caption>
          <InlineTour type="primary" mask={false} placement={placement} />
        </div>
      ))}
    </Flex>
  ),
}

/**
 * Figma `Placement`: pick any of the 12 in the Controls panel (along with
 * `type`, `mask` and `arrow`). One panel at a time — at up to 520px wide,
 * twelve held open at once don't fit a canvas without overlapping.
 */
export const Placements: Story = {
  render: (args) => (
    <InlineTour placement={args.placement ?? 'bottom'} type={args.type} mask={args.mask} arrow={args.arrow} height={320} />
  ),
}

/**
 * Figma indicator `Slider` / `Number`. The default indicators are antd's
 * dots; `indicatorsRender` swaps them for a "1 / 3" counter.
 */
export const Indicators: Story = {
  render: () => (
    <Flex vertical gap={24}>
      <div>
        <Caption>Slider (default)</Caption>
        <InlineTour mask={false} />
      </div>
      <div>
        <Caption>Number</Caption>
        <InlineTour
          mask={false}
          indicatorsRender={(current, total) => (
            <span>
              {current + 1} / {total}
            </span>
          )}
        />
      </div>
    </Flex>
  ),
}
