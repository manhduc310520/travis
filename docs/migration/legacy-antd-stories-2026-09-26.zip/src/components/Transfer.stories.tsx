import { useState } from 'react'
import type { ReactNode } from 'react'
import type { Meta, StoryObj } from '@storybook/react-vite'
import { Button, Flex, Transfer, Typography } from 'antd'
import type { TransferProps } from 'antd'

/**
 * `targetKeys` is controlled-only on antd's Transfer (there is no
 * `defaultTargetKeys`), so passing it straight through `args` froze the
 * lists — the move buttons did nothing. This wrapper takes the story's
 * `targetKeys` as the starting state and owns the live value, so every
 * story is interactive while the rest of its args still flow through.
 */
function TransferDemo({ targetKeys: initialTargetKeys = [], ...props }: TransferProps) {
  const [targetKeys, setTargetKeys] = useState(initialTargetKeys)
  return <Transfer {...props} targetKeys={targetKeys} onChange={(keys) => setTargetKeys(keys)} />
}

const meta: Meta<typeof Transfer> = {
  component: Transfer,
  title: 'Components/Transfer',
  tags: ['ai-generated', 'needs-work'],
  render: (args) => <TransferDemo {...args} />,
  // No JSDoc on these in antd's transfer types — written from the API.
  argTypes: {
    dataSource: { description: 'The full list of items to move between the two lists.', control: false },
    targetKeys: { description: 'Keys currently on the right (target) side.', control: false },
    titles: { description: 'Header text for the [left, right] lists.', control: false },
    showSearch: { description: 'Adds a search field above each list.', control: 'boolean' },
    footer: { description: 'Renders a footer under each list; receives the list direction.', control: false },
    status: { description: 'Validation state — colors both list borders.', control: 'select', options: ['', 'warning', 'error'] },
    disabled: { description: 'Disables both lists and the move buttons.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Transfer>

const dataSource = Array.from({ length: 8 }, (_, i) => ({
  key: String(i), title: `Item ${i + 1}`,
}))

const baseArgs = {
  dataSource,
  targetKeys: ['1', '3'],
  render: (item: { title?: string }) => item.title ?? '',
  titles: ['Source', 'Target'],
}

/** Caption above each control, matching how the Figma docs frame labels every example. */
function Labeled({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Flex vertical gap={4}>
      <Typography.Text type="secondary">{label}</Typography.Text>
      {children}
    </Flex>
  )
}

export const Default: Story = { args: baseArgs }

/** Figma `Transfer`, `Search: Yes` — a filter field above each list. */
export const WithSearch: Story = {
  args: {
    ...baseArgs,
    showSearch: true,
    filterOption: (input, item) => (item.title ?? '').toLowerCase().includes(input.toLowerCase()),
  },
}

/** Figma panel `Footer?` boolean: an action row under each list. */
export const WithFooter: Story = {
  args: {
    ...baseArgs,
    footer: (_, info) => (
      <Flex style={{ padding: 8 }}>
        <Button size="small">{info?.direction === 'left' ? 'Reload source' : 'Reload target'}</Button>
      </Flex>
    ),
  },
}

/** Figma panel `Status`: error / warning. */
export const Status: Story = {
  args: baseArgs,
  render: (args) => (
    <Flex vertical gap={16}>
      <Labeled label="Error">
        <TransferDemo {...args} status="error" />
      </Labeled>
      <Labeled label="Warning">
        <TransferDemo {...args} status="warning" />
      </Labeled>
    </Flex>
  ),
}

/** Figma panel `Disabled` — both lists and the move buttons. */
export const Disabled: Story = { args: { ...baseArgs, disabled: true } }
