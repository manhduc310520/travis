import type { Meta, StoryObj } from '@storybook/react-vite'
import { useState } from 'react'
import { Tree, Typography } from 'antd'
import type { TreeDataNode, TreeProps } from 'antd'
import { Building02, File06, PieChart01, Settings01, Users01 } from '../icons'

const meta: Meta<typeof Tree> = {
  component: Tree,
  title: 'Components/Tree',
  tags: ['ai-generated', 'needs-work'],
  // `defaultExpandAll`'s description is antd's own JSDoc from Tree.d.ts,
  // copied as-is. The others have no JSDoc there — written from the API.
  argTypes: {
    treeData: { description: 'The nested list of nodes.', control: false },
    defaultExpandAll: { description: 'Expand all tree nodes by default.', control: 'boolean' },
    checkable: { description: 'Shows a checkbox on every node.', control: 'boolean' },
    showLine: { description: 'Draws connector lines between nodes; `{ showLeafIcon }` also sets the leaf icon.', control: 'boolean' },
    showIcon: { description: "Shows each node's `icon` before its title.", control: 'boolean' },
    draggable: { description: 'Lets nodes be dragged to reorder or re-parent them (handle `onDrop`).', control: 'boolean' },
    blockNode: { description: 'Makes each node fill the row width, so the whole row is the drag / click target.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Tree>

const treeData: TreeDataNode[] = [
  {
    title: 'Parent 1',
    key: 'parent-1',
    children: [
      { title: 'Child 1-1', key: 'child-1-1' },
      { title: 'Child 1-2', key: 'child-1-2' },
    ],
  },
  { title: 'Parent 2', key: 'parent-2', children: [{ title: 'Child 2-1', key: 'child-2-1' }] },
]

const Caption = ({ children }: { children: React.ReactNode }) => (
  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>
    {children}
  </Typography.Text>
)

/** Figma `Type: Basic`. */
export const Default: Story = { args: { treeData, defaultExpandAll: true } }

/** Figma `Type: Checkbox` — the component's default variant. */
export const Checkable: Story = { args: { treeData, checkable: true, defaultExpandAll: true } }

/** Figma `Type: Icon` — `showIcon` plus a per-node `icon`. */
export const WithIcon: Story = {
  args: {
    showIcon: true,
    defaultExpandAll: true,
    treeData: [
      {
        title: 'Headquarters',
        key: 'hq',
        icon: <Building02 />,
        children: [
          { title: 'Staff', key: 'staff', icon: <Users01 /> },
          { title: 'Reports', key: 'reports', icon: <PieChart01 /> },
          { title: 'Settings', key: 'settings', icon: <Settings01 /> },
        ],
      },
    ],
  },
}

/**
 * Figma `Line: True` on its own, and `Type: Leaf` — connector lines plus a
 * leaf icon on end nodes (`showLine={{ showLeafIcon }}`).
 */
export const ShowLine: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 48, flexWrap: 'wrap' }}>
      <div>
        <Caption>Line: True</Caption>
        <Tree showLine defaultExpandAll treeData={treeData} />
      </div>
      <div>
        <Caption>Type: Leaf (line + leaf icon)</Caption>
        <Tree showLine={{ showLeafIcon: <File06 /> }} defaultExpandAll treeData={treeData} />
      </div>
    </div>
  ),
}

const dragTreeData: TreeDataNode[] = [
  {
    title: 'Parent 1',
    key: 'parent-1',
    children: [
      { title: 'Child 1-1', key: 'child-1-1' },
      { title: 'Child 1-2', key: 'child-1-2' },
      { title: 'Child 1-3', key: 'child-1-3' },
    ],
  },
  {
    title: 'Parent 2',
    key: 'parent-2',
    children: [
      { title: 'Child 2-1', key: 'child-2-1' },
      { title: 'Child 2-2', key: 'child-2-2' },
    ],
  },
]

const cloneTree = (nodes: TreeDataNode[]): TreeDataNode[] =>
  nodes.map((node) => ({ ...node, children: node.children ? cloneTree(node.children) : undefined }))

/**
 * Calls `callback` once with the node matching `key`, its index and its
 * sibling array, then stops — the callback splices that array, so iteration
 * must not continue over it.
 */
function findNode(
  nodes: TreeDataNode[],
  key: React.Key,
  callback: (node: TreeDataNode, index: number, siblings: TreeDataNode[]) => void,
): boolean {
  for (let i = 0; i < nodes.length; i++) {
    if (nodes[i].key === key) {
      callback(nodes[i], i, nodes)
      return true
    }
    const children = nodes[i].children
    if (children && findNode(children, key, callback)) return true
  }
  return false
}

/**
 * Figma `Type: Draggable`. Tree only reports the drop — the data move is the
 * caller's job — so this keeps the tree in state and applies antd's own
 * reorder recipe: drop onto a node = become its first child; drop into a gap
 * = insert before/after it.
 */
function DraggableDemo() {
  const [data, setData] = useState(dragTreeData)

  const onDrop: TreeProps['onDrop'] = (info) => {
    const dropKey = info.node.key
    const dragKey = info.dragNode.key
    const dropPos = info.node.pos.split('-')
    const relativePosition = info.dropPosition - Number(dropPos[dropPos.length - 1])

    const next = cloneTree(data)
    const dragged: { node?: TreeDataNode } = {}
    findNode(next, dragKey, (node, index, siblings) => {
      siblings.splice(index, 1)
      dragged.node = node
    })
    const moved = dragged.node
    if (!moved) return

    if (!info.dropToGap) {
      findNode(next, dropKey, (node) => {
        node.children = [moved, ...(node.children ?? [])]
      })
    } else {
      findNode(next, dropKey, (_node, index, siblings) => {
        siblings.splice(relativePosition === -1 ? index : index + 1, 0, moved)
      })
    }
    setData(next)
  }

  return <Tree draggable blockNode defaultExpandAll treeData={data} onDrop={onDrop} />
}

export const Draggable: Story = {
  render: () => <DraggableDemo />,
}
