import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ReactNode } from 'react'
import { Flex, TreeSelect, Typography, theme } from 'antd'

const meta: Meta<typeof TreeSelect> = {
  component: TreeSelect,
  title: 'Components/TreeSelect',
  tags: ['ai-generated', 'needs-work'],
  // No JSDoc found on these in antd's tree-select types — written from the API.
  argTypes: {
    treeData: { description: 'The nested list of selectable nodes.', control: false },
    treeCheckable: { description: 'Shows checkboxes and allows selecting multiple nodes.', control: 'boolean' },
    size: { description: 'Control height: small, middle (the 32px default) or large.', control: 'select', options: ['small', 'middle', 'large'] },
    placement: {
      description: 'Where the tree menu opens relative to the field.',
      control: 'select',
      options: ['bottomLeft', 'bottomRight', 'topLeft', 'topRight'],
    },
    open: { description: 'Controls whether the tree menu is shown.', control: 'boolean' },
    treeDefaultExpandAll: { description: 'Expands every node when the menu first renders.', control: 'boolean' },
    disabled: { description: 'Disables the field.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof TreeSelect>

const treeData = [
  {
    title: 'Parent 1', value: 'parent-1',
    children: [{ title: 'Child 1-1', value: 'child-1-1' }, { title: 'Child 1-2', value: 'child-1-2' }],
  },
  { title: 'Parent 2', value: 'parent-2', children: [{ title: 'Child 2-1', value: 'child-2-1' }] },
]

/** Secondary 12px caption naming the Figma variant an example stands for. */
function Caption({ children, width }: { children: ReactNode; width?: number }) {
  const { token } = theme.useToken()
  return (
    <Typography.Text type="secondary" style={{ fontSize: token.fontSizeSM, width, flexShrink: 0 }}>
      {children}
    </Typography.Text>
  )
}

/**
 * Menus shown open for display portal into this box instead of `document.body`
 * (see `inFrame`), and the box reserves room for them — so neighbouring
 * examples never overlap and the Docs page scrolls them with their field.
 * `top*` placements sit the field at the bottom of the box, `*Right` at its
 * right edge, leaving the menu room on the side it opens toward.
 */
function PopupFrame({
  label,
  placement = 'bottomLeft',
  width = 280,
  height = 260,
  children,
}: {
  label: string
  placement?: 'bottomLeft' | 'bottomRight' | 'topLeft' | 'topRight'
  width?: number
  height?: number
  children: ReactNode
}) {
  return (
    <Flex vertical gap={4} style={{ width }}>
      <Caption>{label}</Caption>
      <Flex
        data-popup-frame=""
        align={placement.startsWith('top') ? 'flex-end' : 'flex-start'}
        justify={placement.endsWith('Right') ? 'flex-end' : 'flex-start'}
        style={{ position: 'relative', height }}
      >
        {children}
      </Flex>
    </Flex>
  )
}
const inFrame = (node: HTMLElement) => node.closest<HTMLElement>('[data-popup-frame]') ?? document.body
/** Pins the placement: by default the menu flips when it would leave the viewport, so a "Top" example could open downward mid-scroll. */
const pinned = { overflow: { adjustX: false, adjustY: false } }

export const Default: Story = { args: { treeData, placeholder: 'Please select', 'aria-label': 'Tree select', style: { width: 280 } } }
export const Checkable: Story = { args: { treeData, treeCheckable: true, placeholder: 'Please select', 'aria-label': 'Checkable tree select', style: { maxWidth: 320 } } }

/** Figma `Size[Small|Default|Large]`, basic and checkable. `middle` is antd's name for the 32px default. */
export const Sizes: Story = {
  render: () => (
    <Flex vertical gap={16}>
      {(
        [
          ['small', 'Small'],
          ['middle', 'Default'],
          ['large', 'Large'],
        ] as const
      ).map(([size, label]) => (
        <Flex key={size} gap={16} align="center" wrap>
          <Caption width={96}>{label}</Caption>
          <TreeSelect size={size} treeData={treeData} placeholder="Please select" aria-label={`Tree select, ${label.toLowerCase()}`} style={{ width: 240 }} />
          <TreeSelect size={size} treeData={treeData} treeCheckable defaultValue={['child-1-1', 'child-2-1']} placeholder="Please select" aria-label={`Checkable tree select, ${label.toLowerCase()}`} style={{ width: 280 }} />
        </Flex>
      ))}
    </Flex>
  ),
}

/** Figma "open" example with the menu `Type[Basic|Checkable]`, rendered statically open and fully expanded. */
export const Open: Story = {
  render: () => (
    <Flex gap={48} wrap>
      <PopupFrame label="Menu: Basic">
        <TreeSelect
          open
          treeDefaultExpandAll
          popupAlign={pinned}
          getPopupContainer={inFrame}
          treeData={treeData}
          defaultValue="child-1-1"
          aria-label="Tree select, basic menu"
          style={{ width: 240 }}
        />
      </PopupFrame>
      <PopupFrame label="Menu: Checkable" width={320}>
        <TreeSelect
          open
          treeCheckable
          treeDefaultExpandAll
          popupAlign={pinned}
          getPopupContainer={inFrame}
          treeData={treeData}
          defaultValue={['child-1-1']}
          aria-label="Tree select, checkable menu"
          style={{ width: 280 }}
        />
      </PopupFrame>
    </Flex>
  ),
}

/** Figma `Placement` on the open menu. The menu matches the field width, so Left/Right differ only in which edge anchors it. */
export const Placements: Story = {
  render: () => (
    <Flex vertical gap={24}>
      <Flex gap={48} wrap>
        <PopupFrame label="Placement: Top Left" placement="topLeft">
          <TreeSelect open treeDefaultExpandAll placement="topLeft" popupAlign={pinned} getPopupContainer={inFrame} treeData={treeData} style={{ width: 240 }} placeholder="Please select" aria-label="Tree select, placement top left" />
        </PopupFrame>
        <PopupFrame label="Placement: Top Right" placement="topRight">
          <TreeSelect open treeDefaultExpandAll placement="topRight" popupAlign={pinned} getPopupContainer={inFrame} treeData={treeData} style={{ width: 240 }} placeholder="Please select" aria-label="Tree select, placement top right" />
        </PopupFrame>
      </Flex>
      <Flex gap={48} wrap>
        <PopupFrame label="Placement: Bottom Left">
          <TreeSelect open treeDefaultExpandAll placement="bottomLeft" popupAlign={pinned} getPopupContainer={inFrame} treeData={treeData} style={{ width: 240 }} placeholder="Please select" aria-label="Tree select, placement bottom left" />
        </PopupFrame>
        <PopupFrame label="Placement: Bottom Right" placement="bottomRight">
          <TreeSelect open treeDefaultExpandAll placement="bottomRight" popupAlign={pinned} getPopupContainer={inFrame} treeData={treeData} style={{ width: 240 }} placeholder="Please select" aria-label="Tree select, placement bottom right" />
        </PopupFrame>
      </Flex>
    </Flex>
  ),
}
