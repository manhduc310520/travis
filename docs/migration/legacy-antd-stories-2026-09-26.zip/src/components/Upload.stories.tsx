import type { ReactNode } from 'react'
import type { Meta, StoryObj } from '@storybook/react-vite'
import { Upload, Button, Flex, Typography } from 'antd'
import type { UploadFile } from 'antd'
import { Plus, Upload01, UploadCloud01 } from '../icons'
const meta: Meta<typeof Upload> = {
  component: Upload,
  title: 'Components/Upload',
  tags: ['ai-generated', 'needs-work'],
  // Every story uses a custom `render`, none set `args` — the Docs page's
  // argTypes table only renders once at least one arg exists. No JSDoc on
  // these in antd's upload types — written from the API.
  args: { listType: 'text' },
  argTypes: {
    listType: { description: 'Visual style of the file list.', control: 'select', options: ['text', 'picture', 'picture-card', 'picture-circle'] },
    beforeUpload: { description: 'Runs before upload; returning false stops the real upload (used here to keep stories offline).', control: false },
    defaultFileList: { description: 'Files already in the list on first render (uncontrolled).', control: false },
    disabled: { description: 'Disables the trigger and the list actions.', control: 'boolean' },
  },
}
export default meta
type Story = StoryObj<typeof Upload>

/** Caption above each control, matching how the Figma docs frame labels every example. */
function Labeled({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Flex vertical gap={4}>
      <Typography.Text type="secondary">{label}</Typography.Text>
      {children}
    </Flex>
  )
}

/**
 * Thumbnails are inline SVG data URIs, never network URLs — stories must
 * render offline (CI, Chromatic), and a `data:image/` URL is exactly what
 * antd's own `isImageUrl` check keys on to draw a thumbnail instead of a
 * file icon. The fills are antd's green / blue presets: image content
 * standing in for a photo, not UI chrome.
 */
const thumb = (sky: string, hill: string) =>
  `data:image/svg+xml;charset=utf-8,${encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><rect width="96" height="96" fill="${sky}"/><circle cx="68" cy="28" r="10" fill="#ffffff"/><path d="M0 96 34 52l22 26 12-14 28 32z" fill="${hill}"/></svg>`,
  )}`
const THUMB_GREEN = thumb('#D9F7BE', '#52C41A')
const THUMB_BLUE = thumb('#BAE0FF', '#1677FF')

/**
 * Figma's three picture statuses — `Uploaded`, `Upload` (in progress) and
 * `Error`. A factory rather than a shared constant: Upload keeps its own
 * copy of `defaultFileList` per instance, and a fresh array per story keeps
 * one story's edits (removing a file) from leaking into another.
 */
const pictureFiles = (): UploadFile[] => [
  { uid: '-1', name: 'storefront.png', status: 'done', url: THUMB_GREEN },
  { uid: '-2', name: 'menu-cover.png', status: 'done', url: THUMB_BLUE },
  { uid: '-3', name: 'dish-photo.png', status: 'uploading', percent: 50 },
  { uid: '-4', name: 'banner.png', status: 'error', response: 'Server error 500' },
]

/** The `+ Upload` tile at the end of picture-card / picture-circle lists. */
const uploadTile = (
  <Flex vertical align="center" gap={8}>
    <Plus />
    <span>Upload</span>
  </Flex>
)

export const Button_: Story = {
  name: 'With button',
  render: () => (
    <Upload beforeUpload={() => false}>
      <Button icon={<Upload01 />}>Click to Upload</Button>
    </Upload>
  ),
}

/**
 * Figma's upload button set: `Size` × `State` (default / loading /
 * disabled). `Upload disabled` blocks the file dialog but doesn't grey out
 * a Button child on its own (antd's Upload reads `DisabledContext`, it
 * doesn't provide one), so the Button takes `disabled` too.
 */
export const ButtonStates: Story = {
  render: () => (
    <Flex vertical gap={16}>
      <Labeled label="Sizes">
        <Flex gap={8} align="center">
          <Upload beforeUpload={() => false} showUploadList={false}>
            <Button size="small" icon={<Upload01 />}>Upload</Button>
          </Upload>
          <Upload beforeUpload={() => false} showUploadList={false}>
            <Button icon={<Upload01 />}>Upload</Button>
          </Upload>
          <Upload beforeUpload={() => false} showUploadList={false}>
            <Button size="large" icon={<Upload01 />}>Upload</Button>
          </Upload>
        </Flex>
      </Labeled>
      <Labeled label="Loading">
        <Upload beforeUpload={() => false} showUploadList={false}>
          <Button loading>Uploading</Button>
        </Upload>
      </Labeled>
      <Labeled label="Disabled">
        <Upload beforeUpload={() => false} disabled>
          <Button disabled icon={<Upload01 />}>Upload</Button>
        </Upload>
      </Labeled>
    </Flex>
  ),
}

/**
 * Figma's drag-and-drop example. `ant-upload-text` / `ant-upload-hint` are
 * antd's own class names for the Dragger's title and secondary hint line —
 * they carry the theme's heading and secondary text colours.
 */
export const Dragger: Story = {
  render: () => (
    <Upload.Dragger beforeUpload={() => false} style={{ maxWidth: 420 }}>
      <p><UploadCloud01 size={32} /></p>
      <p className="ant-upload-text">Click or drag file to this area to upload</p>
      <p className="ant-upload-hint">Support for a single or bulk upload.</p>
    </Upload.Dragger>
  ),
}

/**
 * Figma's `Basic` list item, including its `Error` state: a finished file,
 * one mid-upload and one that failed (hover it for the error message).
 */
export const TextList: Story = {
  render: () => (
    <Upload
      beforeUpload={() => false}
      defaultFileList={[
        { uid: '-1', name: 'menu-spring-2026.pdf', status: 'done' },
        { uid: '-2', name: 'price-list.xlsx', status: 'uploading', percent: 60 },
        { uid: '-3', name: 'supplier-contract.pdf', status: 'error', response: 'Server error 500' },
      ]}
      style={{ maxWidth: 420 }}
    >
      <Button icon={<Upload01 />}>Upload</Button>
    </Upload>
  ),
}

/** Figma `Picture` list items (square thumbnail): uploaded, uploading, error. */
export const PictureList: Story = {
  render: () => (
    <div style={{ maxWidth: 420 }}>
      <Upload listType="picture" beforeUpload={() => false} defaultFileList={pictureFiles()}>
        <Button icon={<Upload01 />}>Upload</Button>
      </Upload>
    </div>
  ),
}

/** Figma `Picture`, `Type: Circle`: the same three statuses in round tiles, plus the upload tile. */
export const PictureCircle: Story = {
  render: () => (
    <Upload listType="picture-circle" beforeUpload={() => false} defaultFileList={pictureFiles()}>
      {uploadTile}
    </Upload>
  ),
}

/** Figma `Picture card`: uploaded, uploading (`Loading`), error, and the upload tile. */
export const PictureCard: Story = {
  render: () => (
    <Upload listType="picture-card" beforeUpload={() => false} defaultFileList={pictureFiles()}>
      {uploadTile}
    </Upload>
  ),
}
