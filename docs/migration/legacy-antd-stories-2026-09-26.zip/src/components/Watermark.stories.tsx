import type { Meta, StoryObj } from '@storybook/react-vite'
import { Watermark, Card, Typography } from 'antd'

const meta: Meta<typeof Watermark> = {
  component: Watermark,
  title: 'Components/Watermark',
  tags: ['ai-generated', 'needs-work'],
  // The story uses a custom `render` with no `args` — the Docs page's
  // argTypes table only renders once at least one arg exists. No JSDoc on
  // `content` in antd's watermark types — written from the API.
  args: { content: 'iPOS.vn' },
  argTypes: {
    content: { description: 'Text (or array of lines) repeated across the watermark.', control: 'text' },
    image: { description: 'Image URL drawn instead of text; takes priority over `content`. Set `width`/`height` with it.', control: false },
    rotate: { description: 'Rotation of each tile, in degrees (default -22).', control: 'number' },
    gap: { description: 'Horizontal and vertical spacing between tiles, [x, y].', control: false },
  },
}
export default meta
type Story = StoryObj<typeof Watermark>

export const Default: Story = {
  render: () => (
    <Watermark content="iPOS.vn">
      <Card style={{ maxWidth: 480, height: 200 }}>Card content</Card>
    </Watermark>
  ),
}

/** `content` also takes an array — each entry becomes its own line within a tile. */
export const MultiLine: Story = {
  render: () => (
    <Watermark content={['iPOS.vn', 'Confidential']}>
      <Card style={{ maxWidth: 480, height: 200 }}>Card content</Card>
    </Watermark>
  ),
}

/**
 * Image watermark: `image` replaces the text. The watermark is painted on a
 * canvas, so CSS variables can't reach it — the mark below is a self-contained
 * inline SVG (no network request) with its own low-opacity grey fill.
 */
const MARK = `data:image/svg+xml;utf8,${encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="32" viewBox="0 0 120 32">' +
    '<g fill="#000" fill-opacity="0.15">' +
    '<circle cx="16" cy="16" r="12"/>' +
    '<rect x="36" y="8" width="76" height="6" rx="3"/>' +
    '<rect x="36" y="20" width="52" height="6" rx="3"/>' +
    '</g></svg>',
)}`

export const ImageWatermark: Story = {
  render: () => (
    <Watermark image={MARK} width={120} height={32}>
      <Card style={{ maxWidth: 480 }}>
        <Typography.Paragraph>
          Watermarks mark content as belonging to the organisation. The image tile repeats across the whole wrapped area,
          rotated like the text version.
        </Typography.Paragraph>
        <Typography.Paragraph style={{ marginBottom: 0 }}>
          The mark sits above the content but lets pointer events through, so the content underneath stays usable.
        </Typography.Paragraph>
      </Card>
    </Watermark>
  ),
}
